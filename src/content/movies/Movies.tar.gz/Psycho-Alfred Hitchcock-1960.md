---
type: movie
country: US
title: "Psycho"
year: 1960
director: Alfred Hitchcock
actors: [Anthony Perkins, Janet Leigh, Vera Miles, John Gavin, Martin Balsam]
genre: [Horror, Thriller, Mystery]
length: "1h 49m"
shelf: watched
owned: false
rating: 
watched: 1960-06-22
poster: "https://image.tmdb.org/t/p/w500/yz4QVqPx3h1hD1DfqqQkCq3rmxW.jpg"
---

# Psycho (1960)

![](https://image.tmdb.org/t/p/w500/yz4QVqPx3h1hD1DfqqQkCq3rmxW.jpg)

When larcenous real estate clerk Marion Crane goes on the lam with a wad of cash and hopes of starting a new life, she ends up at the notorious Bates Motel, where manager Norman Bates cares for his housebound mother.