---
type: movie
country: US
title: "Zootopia"
year: 2016
director: Byron Howard, Rich Moore
actors: [Ginnifer Goodwin, Jason Bateman, Idris Elba, Jenny Slate, Nate Torrence]
genre: [Animation, Adventure, Family, Comedy]
length: "1h 49m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/hlK0e0wAQ3VLuJcsfIYPvb4JVud.jpg"
---

# Zootopia (2016)

![](https://image.tmdb.org/t/p/w500/hlK0e0wAQ3VLuJcsfIYPvb4JVud.jpg)

Determined to prove herself, Officer Judy Hopps, the first bunny on Zootopia's police force, jumps at the chance to crack her first case - even if it means partnering with scam-artist fox Nick Wilde to solve the mystery.