---
type: movie
country: US
title: "Carrie"
year: 2013
director: Kimberly Peirce
actors: [Chloë Grace Moretz, Julianne Moore, Gabriella Wilde, Ansel Elgort, Alex Russell]
genre: [Drama, Horror]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 2013-10-18
poster: "https://image.tmdb.org/t/p/w500/kloXz9qwO23z9Kbt3z3MgnjF4xO.jpg"
---

# Carrie (2013)

![](https://image.tmdb.org/t/p/w500/kloXz9qwO23z9Kbt3z3MgnjF4xO.jpg)

An awkward, telekinetic teenage girl is the object of relentless bullying at school and an oppressively religious mother at home.