---
type: movie
country: US
title: "The Secret Life of Pets"
year: 2016
director: Chris Renaud
actors: [Louis C.K., Eric Stonestreet, Kevin Hart, Jenny Slate, Ellie Kemper]
genre: [Family, Comedy, Adventure, Animation]
length: "1h 26m"
shelf: watched
owned: false
rating: 
watched: 2016-07-08
poster: "https://image.tmdb.org/t/p/w500/bc3rCMgP4bbxNqGQCRlpJyU8otF.jpg"
---

# The Secret Life of Pets (2016)

![](https://image.tmdb.org/t/p/w500/bc3rCMgP4bbxNqGQCRlpJyU8otF.jpg)

The quiet life of a terrier named Max is upended when his owner takes in Duke, a stray whom Max instantly dislikes.