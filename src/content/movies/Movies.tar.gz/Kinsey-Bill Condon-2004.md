---
type: movie
country: US
title: "Kinsey"
year: 2004
director: Bill Condon
actors: [Liam Neeson, Laura Linney, Chris O'Donnell, Peter Sarsgaard, Timothy Hutton]
genre: [Drama]
length: "1h 58m"
shelf: watched
owned: false
rating: 
watched: 2004-09-04
poster: "https://image.tmdb.org/t/p/w500/cODCjWNRcZkwe4ONQs1GzRqYtRb.jpg"
---

# Kinsey (2004)

![](https://image.tmdb.org/t/p/w500/cODCjWNRcZkwe4ONQs1GzRqYtRb.jpg)

Kinsey is a portrait of researcher Alfred Kinsey, driven to uncover the most private secrets of a nation. What begins for Kinsey as a scientific endeavor soon takes on an intensely personal relevance, ultimately becoming an unexpected journey into the mystery of human behavior.