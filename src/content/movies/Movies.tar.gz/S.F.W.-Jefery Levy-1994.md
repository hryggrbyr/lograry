---
type: movie
country: United States
title: "S.F.W."
year: 1994
director: Jefery Levy
actors: [Stephen Dorff, Reese Witherspoon, Jake Busey]
genre: [Comedy, Drama]
length: 96
shelf: watched
owned: false
rating: 
watched: 1994-12-31
poster: "https://m.media-amazon.com/images/M/MV5BYTBlNjc2NjUtY2RjMS00MDFlLWE1NjUtNjc0ZjA5YzBiZDI1XkEyXkFqcGc@._V1_SX300.jpg"
---

# S.F.W. (1994)

![](https://m.media-amazon.com/images/M/MV5BYTBlNjc2NjUtY2RjMS00MDFlLWE1NjUtNjc0ZjA5YzBiZDI1XkEyXkFqcGc@._V1_SX300.jpg)

An alienated and misanthropic teenager gains sudden and unwanted celebrity status after he's taken hostage by terrorists where his indifference to their threats to kill him makes news headlines.