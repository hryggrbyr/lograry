---
type: movie
country: US
title: "Equilibrium"
year: 2002
director: Kurt Wimmer
actors: [Christian Bale, Taye Diggs, Angus Macfadyen, Matthew Harbour, Sean Bean]
genre: [Action, Science Fiction, Thriller]
length: "1h 47m"
shelf: watched
owned: false
rating: 
watched: 2002-12-06
poster: "https://image.tmdb.org/t/p/w500/eW3YrxOh3rd6PnRgMSftYoflvfe.jpg"
---

# Equilibrium (2002)

![](https://image.tmdb.org/t/p/w500/eW3YrxOh3rd6PnRgMSftYoflvfe.jpg)

In a dystopian future, a totalitarian regime maintains peace by subduing the populace with a drug, and displays of emotion are punishable by death. A man in charge of enforcing the law rises to overthrow the system.