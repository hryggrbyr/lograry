---
type: movie
country: US
title: "Saw VI"
year: 2009
director: Kevin Greutert
actors: [Tobin Bell, Costas Mandylor, Mark Rolston, Betsy Russell, Shawnee Smith]
genre: [Horror, Thriller]
length: "1h 30m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/cT7ufx1x6OKoi3bpUCWf2eV446G.jpg"
---

# Saw VI (2009)

![](https://image.tmdb.org/t/p/w500/cT7ufx1x6OKoi3bpUCWf2eV446G.jpg)

Special Agent Strahm is dead, and Detective Hoffman has emerged as the unchallenged successor to Jigsaw's legacy. However, when the FBI draws closer to Hoffman, he is forced to set a game into motion, and Jigsaw's grand scheme is finally understood.