---
type: movie
country: US
title: "The Lord of the Rings: The Return of the King"
year: 2003
director: Peter Jackson
actors: [Elijah Wood, Ian McKellen, Viggo Mortensen, Sean Astin, Andy Serkis]
genre: [Adventure, Fantasy, Action]
length: "3h 21m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/rCzpDGLbOoPwLjy3OAm5NUPOTrC.jpg"
---

# The Lord of the Rings: The Return of the King (2003)

![](https://image.tmdb.org/t/p/w500/rCzpDGLbOoPwLjy3OAm5NUPOTrC.jpg)

As armies mass for a final battle that will decide the fate of the world--and powerful, ancient forces of Light and Dark compete to determine the outcome--one member of the Fellowship of the Ring is revealed as the noble heir to the throne of the Kings of Men. Yet, the sole hope for triumph over evil lies with a brave hobbit, Frodo, who, accompanied by his loyal friend Sam and the hideous, wretched Gollum, ventures deep into the very dark heart of Mordor on his seemingly impossible quest to destroy the Ring of Power.​