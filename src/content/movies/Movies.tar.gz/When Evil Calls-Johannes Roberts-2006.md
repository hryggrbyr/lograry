---
type: movie
country: GB, US
title: "When Evil Calls"
year: 2006
director: Johannes Roberts
actors: [Sean Pertwee, Dominique Pinon, Lois Winstone, Jennifer Lim, Rick Warden]
genre: [Horror]
length: "1h 16m"
shelf: watched
owned: false
rating: 
watched: 2008-01-22
poster: "https://image.tmdb.org/t/p/w500/zbFBEOUmSFEINF1qZhURasRbCQb.jpg"
---

# When Evil Calls (2006)

![](https://image.tmdb.org/t/p/w500/zbFBEOUmSFEINF1qZhURasRbCQb.jpg)

When Evil Calls centers around the mysterious appearance of a text message that grants the students of Wilburn High School their wildest desires.