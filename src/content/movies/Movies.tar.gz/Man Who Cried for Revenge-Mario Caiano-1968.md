---
type: movie
country: Italy
title: "Man Who Cried for Revenge"
year: 1968
director: Mario Caiano
actors: [Anthony Steffen, William Berger, Ida Galli]
genre: [Western]
length: 94
shelf: watched
owned: false
rating: 3
watched: 2025-09-16
poster: "https://m.media-amazon.com/images/M/MV5BNmVkYWRmOTMtY2E1MS00OWNmLThiODktMzc2NWEwMjNhYTM0XkEyXkFqcGdeQXVyMTQ3Njg3MQ@@._V1_SX300.jpg"
---

# Man Who Cried for Revenge (1968)

![](https://m.media-amazon.com/images/M/MV5BNmVkYWRmOTMtY2E1MS00OWNmLThiODktMzc2NWEwMjNhYTM0XkEyXkFqcGdeQXVyMTQ3Njg3MQ@@._V1_SX300.jpg)

A Civil War veteran is amnesic after being shot in the head. When he rerurns to his hometown, he finds out that he has been declared a deserter. The local judge offers him a chance to clear his name, but he only wants to send him ...

---
Watched this dubbed into Spanish with no subtitles so was hard to follow but still bonkers!