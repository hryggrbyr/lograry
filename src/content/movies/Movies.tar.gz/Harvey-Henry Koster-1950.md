---
type: movie
country: US
title: "Harvey"
year: 1950
director: Henry Koster
actors: [James Stewart, Josephine Hull, Peggy Dow, Charles Drake, Cecil Kellaway]
genre: [Comedy, Fantasy]
length: "1h 44m"
shelf: watched
owned: false
rating: 
watched: 1950-12-21
poster: "https://image.tmdb.org/t/p/w500/dgd82hYmpiXDM1G867HqNaWe8wj.jpg"
---

# Harvey (1950)

![](https://image.tmdb.org/t/p/w500/dgd82hYmpiXDM1G867HqNaWe8wj.jpg)

The story of Elwood P. Dowd who makes friends with a spirit taking the form of a human-sized rabbit named Harvey that only he sees (and a few privileged others on occasion also.) After his sister tries to commit him to a mental institution, a comedy of errors ensues. Elwood and Harvey become the catalysts for a family mending its wounds and for romance blossoming in unexpected places.