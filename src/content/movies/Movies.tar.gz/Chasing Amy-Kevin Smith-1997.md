---
type: movie
country: United States
title: Chasing Amy
year: 1997
director: Kevin Smith
actors: [Ben Affleck, Joey Lauren Adams, Ethan Suplee]
genre: [Comedy, Drama, Romance]
length: 113
shelf: watched
owned: false
rating: 
watched: 2002-12-31
poster: "https://m.media-amazon.com/images/M/MV5BZWQ5OWQ4NWEtZGJlYy00MzI3LTg5YzItZjVhYjJhYmNkZjM4XkEyXkFqcGc@._V1_SX300.jpg"
---

# Chasing Amy (1997)

![](https://m.media-amazon.com/images/M/MV5BZWQ5OWQ4NWEtZGJlYy00MzI3LTg5YzItZjVhYjJhYmNkZjM4XkEyXkFqcGc@._V1_SX300.jpg)

Holden and Banky are comic book artists. Everything's going good for them until they meet Alyssa, also a comic book artist. Holden falls for her, but his hopes are crushed when he finds out she's a lesbian.