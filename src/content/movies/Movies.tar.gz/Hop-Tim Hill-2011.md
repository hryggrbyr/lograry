---
type: movie
country: United States, Japan, United Kingdom, Canada
title: "Hop"
year: 2011
director: Tim Hill
actors: [Russell Brand, James Marsden, Elizabeth Perkins]
genre: [Animation, Adventure, Comedy]
length: 95
shelf: watched
owned: false
rating: 2
watched: 2025-09-28
poster: "https://m.media-amazon.com/images/M/MV5BMTY4MDcxNTkzNV5BMl5BanBnXkFtZTcwMTg2MDY2NA@@._V1_SX300.jpg"
---

# Hop (2011)

![](https://m.media-amazon.com/images/M/MV5BMTY4MDcxNTkzNV5BMl5BanBnXkFtZTcwMTg2MDY2NA@@._V1_SX300.jpg)

E.B., the Easter Bunny's teenage son, heads to Hollywood, determined to become a drummer in a rock 'n' roll band. In LA, he's taken in by Fred after the out-of-work slacker hits E.B. with his car.