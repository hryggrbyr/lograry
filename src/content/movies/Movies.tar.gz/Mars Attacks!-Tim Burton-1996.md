---
type: movie
country: US
title: "Mars Attacks!"
year: 1996
director: Tim Burton
actors: [Jack Nicholson, Glenn Close, Annette Bening, Pierce Brosnan, Danny DeVito]
genre: [Comedy, Fantasy, Science Fiction]
length: "1h 46m"
shelf: watched
owned: false
rating: 
watched: 1996-12-12
poster: "https://image.tmdb.org/t/p/w500/iCifw8aBSVd1UykIj0NMSehp8CB.jpg"
---

# Mars Attacks! (1996)

![](https://image.tmdb.org/t/p/w500/iCifw8aBSVd1UykIj0NMSehp8CB.jpg)

A fleet of Martian spacecraft surrounds the world's major cities and all of humanity waits to see if the extraterrestrial visitors have, as they claim, "come in peace." U.S. President James Dale receives assurance from science professor Donald Kessler that the Martians' mission is a friendly one. But when a peaceful exchange ends in the total annihilation of the U.S. Congress, military men call for a full-scale nuclear retaliation.