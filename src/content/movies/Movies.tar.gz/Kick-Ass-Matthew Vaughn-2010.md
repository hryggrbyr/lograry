---
type: movie
country: US
title: "Kick-Ass"
year: 2010
director: Matthew Vaughn
actors: [Aaron Taylor-Johnson, Chloë Grace Moretz, Nicolas Cage, Lyndsy Fonseca, Mark Strong]
genre: [Action, Crime]
length: "1h 58m"
shelf: watched
owned: false
rating: 
watched: 2010-04-16
poster: "https://image.tmdb.org/t/p/w500/iHMbrTHJwocsNvo5murCBw0CwTo.jpg"
---

# Kick-Ass (2010)

![](https://image.tmdb.org/t/p/w500/iHMbrTHJwocsNvo5murCBw0CwTo.jpg)

Dave Lizewski is an unnoticed high school student and comic book fan who one day decides to become a super-hero, even though he has no powers, training or meaningful reason to do so.