---
type: movie
country: US, GB
title: "Legend"
year: 1985
director: Ridley Scott
actors: [Tom Cruise, Mia Sara, Tim Curry, David Bennent, Alice Playten]
genre: [Adventure, Fantasy]
length: "1h 34m"
shelf: watched
owned: false
rating: 
watched: 1986-04-18
poster: "https://image.tmdb.org/t/p/w500/6n3PQSYpZRK5YPk2w8JEwED7AZk.jpg"
---

# Legend (1985)

![](https://image.tmdb.org/t/p/w500/6n3PQSYpZRK5YPk2w8JEwED7AZk.jpg)

Set in a timeless mythical forest inhabited by fairies, goblins, unicorns and mortals, this fantastic story follows a mystical forest dweller, chosen by fate, to undertake a heroic quest. He must save the beautiful Princess  Lili and defeat the demonic Lord of Darkness, or the world will be plunged into a never-ending ice age.