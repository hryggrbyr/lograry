---
type: movie
country: US
title: "Shrek 2"
year: 2004
director: Conrad Vernon, Kelly Asbury, Andrew Adamson
actors: [Mike Myers, Eddie Murphy, Cameron Diaz, Julie Andrews, Antonio Banderas]
genre: [Animation, Family, Comedy, Fantasy, Adventure]
length: "1h 32m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/2yYP0PQjG8zVqturh1BAqu2Tixl.jpg"
---

# Shrek 2 (2004)

![](https://image.tmdb.org/t/p/w500/2yYP0PQjG8zVqturh1BAqu2Tixl.jpg)

Shrek, Fiona, and Donkey set off to Far, Far Away to meet Fiona's mother and father, the Queen and King. But not everyone is happily ever after. Shrek and the King find it difficult to get along, and there's tension in the marriage. The Fairy Godmother discovers that Fiona has married Shrek instead of her son Prince Charming and plots to destroy their marriage.