---
type: movie
country: US, JP
title: "Orgazmo"
year: 1998
director: Trey Parker
actors: [Trey Parker, Dian Bachar, Matt Stone, Michael Dean Jacobs, Robyn Lynne Raab]
genre: [Comedy]
length: "1h 34m"
shelf: watched
owned: false
rating: 
watched: 1997-09-06
poster: "https://image.tmdb.org/t/p/w500/irvFBOc33CHsioU6hqcu8ExymEa.jpg"
---

# Orgazmo (1998)

![](https://image.tmdb.org/t/p/w500/irvFBOc33CHsioU6hqcu8ExymEa.jpg)

A devout Mormon living in L.A. becomes a pornographic actor after his martial arts moves impress a big-time director.