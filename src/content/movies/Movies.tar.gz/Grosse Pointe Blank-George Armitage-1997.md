---
type: movie
country: US
title: "Grosse Pointe Blank"
year: 1997
director: George Armitage
actors: [John Cusack, Minnie Driver, Dan Aykroyd, Joan Cusack, Alan Arkin]
genre: [Action, Comedy, Thriller, Romance]
length: "1h 47m"
shelf: watched
owned: false
rating: 
watched: 1997-04-11
poster: "https://image.tmdb.org/t/p/w500/7lQ0MSNQqBTYpXTTZL82u1n95Z3.jpg"
---

# Grosse Pointe Blank (1997)

![](https://image.tmdb.org/t/p/w500/7lQ0MSNQqBTYpXTTZL82u1n95Z3.jpg)

Hitman Martin Blank becomes a moving target after he rebuffs a fellow assassin's invitation to form a union. On the advice of his quirky assistant and neurotic psychiatrist, Martin begrudgingly heads out to Grosse Pointe, Michigan for his ten-year high school reunion, where he soon comes across the woman he jilted on prom night.