---
type: movie
country: United States
title: "Our Brand Is Crisis"
year: 2015
director: David Gordon Green
actors: [Sandra Bullock, Billy Bob Thornton, Anthony Mackie]
genre: [Comedy, Drama]
length: 107
shelf: watchlist
owned: false
rating: 
watched:
poster: "https://m.media-amazon.com/images/M/MV5BMTg5MDUwMDQwM15BMl5BanBnXkFtZTgwNTczMjU3NjE@._V1_SX300.jpg"
---

# Our Brand Is Crisis (2015)

![](https://m.media-amazon.com/images/M/MV5BMTg5MDUwMDQwM15BMl5BanBnXkFtZTgwNTczMjU3NjE@._V1_SX300.jpg)

A battle-hardened American political consultant is sent to help re-elect a controversial president in Bolivia, where she must compete with a long-term rival working for another candidate.