---
type: movie
country: US
title: "Veronika Decides to Die"
year: 2009
director: Emily Young
actors: [Sarah Michelle Gellar, David Thewlis, Jonathan Tucker, Erika Christensen, Melissa Leo]
genre: [Drama, Romance]
length: "1h 43m"
shelf: watched
owned: false
rating: 
watched: 2009-08-21
poster: "https://image.tmdb.org/t/p/w500/oUo9CNSKz4ELnxAh4l3BPcXcxKq.jpg"
---

# Veronika Decides to Die (2009)

![](https://image.tmdb.org/t/p/w500/oUo9CNSKz4ELnxAh4l3BPcXcxKq.jpg)

After a frantic suicide attempt, Veronika awakens inside a mysterious mental asylum. Under the supervision of an unorthodox psychiatrist who specializes in controversial treatment, Veronika learns that she has only weeks to live.