---
type: movie
country: US
title: "Runaway Bride"
year: 1999
director: Garry Marshall
actors: [Julia Roberts, Richard Gere, Joan Cusack, Héctor Elizondo, Rita Wilson]
genre: [Comedy, Romance]
length: "1h 56m"
shelf: watched
owned: false
rating: 
watched: 1999-07-30
poster: "https://image.tmdb.org/t/p/w500/wzivR0yWJStVdhcl0A5rQvVdTQ7.jpg"
---

# Runaway Bride (1999)

![](https://image.tmdb.org/t/p/w500/wzivR0yWJStVdhcl0A5rQvVdTQ7.jpg)

Having already left three grooms at the altar, Maggie Carpenter is branded "the runaway bride" by jaded New York journalist Ike Graham. But, after his facts are called into question, Ike races to Maggie's hometown to save his reputation and report on her upcoming fourth trip down the aisle – during which he's convinced she'll run again. Though he's there on a muckraking mission, Ike can't help but fall for this breathtaking heartbreaker.