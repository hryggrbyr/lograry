---
type: movie
country: US, GB
title: "Outpost"
year: 2008
director: Steve Barker
actors: [Ray Stevenson, Julian Wadham, Richard Brake, Paul Blair, Brett Fancy]
genre: [Action, Adventure, Horror]
length: "1h 30m"
shelf: watched
owned: false
rating: 
watched: 2008-05-16
poster: "https://image.tmdb.org/t/p/w500/rwWEsWV1DNCqZudEiHvk1NPeUla.jpg"
---

# Outpost (2008)

![](https://image.tmdb.org/t/p/w500/rwWEsWV1DNCqZudEiHvk1NPeUla.jpg)

In a seedy bar in a town ravaged by war, scientist and businessman Hunt hires mercenary and former Royal Marine D.C. to assemble a crack team of ex-soldiers to protect him on a dangerous journey into no-man's land. Their mission is to scope out an old military bunker in Eastern Europe. It should be easy – 48 hours at the most. Lots of cash for little risk. Or so he says...