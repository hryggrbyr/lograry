---
type: movie
country: US, GB
title: "The Jungle Book"
year: 2016
director: Jon Favreau
actors: [Neel Sethi, Bill Murray, Ben Kingsley, Idris Elba, Scarlett Johansson]
genre: [Family, Adventure, Drama, Fantasy, Animation]
length: "1h 46m"
shelf: watched
owned: false
rating: 
watched: 2016-04-15
poster: "https://image.tmdb.org/t/p/w500/2Epx7F9X7DrFptn4seqn4mzBVks.jpg"
---

# The Jungle Book (2016)

![](https://image.tmdb.org/t/p/w500/2Epx7F9X7DrFptn4seqn4mzBVks.jpg)

A man-cub named Mowgli fostered by wolves. After a threat from the tiger Shere Khan, Mowgli is forced to flee the jungle, by which he embarks on a journey of self discovery with the help of the panther, Bagheera and the free-spirited bear, Baloo.