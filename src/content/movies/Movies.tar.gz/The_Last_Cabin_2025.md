---
type: movie
country: US
title: "The Last Cabin"
year: 2025
director: Brendan Rudnicki
actors: [Isabella Bobadilla, Brendan Goshay, Tanner Kongdara, Benjamin L Newmark, Austin J. Rhodes]
genre: [Horror, Thriller]
length: "1h 20m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/845wyTrzPL8gXx1hHbtH2a5YVPq.jpg"
---

# The Last Cabin (2025)

![](https://image.tmdb.org/t/p/w500/845wyTrzPL8gXx1hHbtH2a5YVPq.jpg)

Trapped in a remote cabin, a film crew finds themselves stalked by three masked men who know the isolated forest and their every move.
