---
type: movie
country: US
title: "Nightbreed"
year: 1990
director: Clive Barker
actors: [Craig Sheffer, Anne Bobby, David Cronenberg, Charles Haid, Hugh Quarshie]
genre: [Horror, Fantasy, Action]
length: "2h 1m"
shelf: watched
owned: false
rating: 
watched: 1990-02-16
poster: "https://image.tmdb.org/t/p/w500/1ChluYH0BEvJo3gtYoFHnMZI660.jpg"
---

# Nightbreed (1990)

![](https://image.tmdb.org/t/p/w500/1ChluYH0BEvJo3gtYoFHnMZI660.jpg)

A troubled young man is drawn to a mythical place called Midian where a variety of friendly monsters are hiding from humanity. Meanwhile, a sadistic serial killer is looking for a patsy.