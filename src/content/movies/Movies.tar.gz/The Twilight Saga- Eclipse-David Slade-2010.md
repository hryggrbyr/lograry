---
type: movie
country: US
title: "The Twilight Saga: Eclipse"
year: 2010
director: David Slade
actors: [Kristen Stewart, Robert Pattinson, Taylor Lautner, Bryce Dallas Howard, Dakota Fanning]
genre: [Adventure, Fantasy, Drama, Romance]
length: "2h 4m"
shelf: watched
owned: false
rating: 
watched: 2010-06-23
poster: "https://image.tmdb.org/t/p/w500/dK4Gi1UdMiHzHc7r7CZQG4IQ9Sr.jpg"
---

# The Twilight Saga: Eclipse (2010)

![](https://image.tmdb.org/t/p/w500/dK4Gi1UdMiHzHc7r7CZQG4IQ9Sr.jpg)

Bella once again finds herself surrounded by danger as Seattle is ravaged by a string of mysterious killings and a malicious vampire continues her quest for revenge. In the midst of it all, she is forced to choose between her love for Edward and her friendship with Jacob, knowing that her decision has the potential to ignite the ageless struggle between vampire and werewolf. With her graduation quickly approaching, Bella is confronted with the most important decision of her life.