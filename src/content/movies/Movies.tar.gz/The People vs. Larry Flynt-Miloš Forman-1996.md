---
type: movie
country: US
title: "The People vs. Larry Flynt"
year: 1996
director: Miloš Forman
actors: [Woody Harrelson, Courtney Love, Edward Norton, Brett Harrelson, Donna Hanover]
genre: [Drama]
length: "2h 10m"
shelf: watched
owned: false
rating: 
watched: 1996-12-25
poster: "https://image.tmdb.org/t/p/w500/sAgHn7ys6TiVXBDTZ0UBEjinIUk.jpg"
---

# The People vs. Larry Flynt (1996)

![](https://image.tmdb.org/t/p/w500/sAgHn7ys6TiVXBDTZ0UBEjinIUk.jpg)

Larry Flynt is the hedonistically obnoxious, but indomitable, publisher of Hustler magazine. The film recounts his struggle to make an honest living publishing his girlie magazine and how it changes into a battle to protect the freedom of speech for all people.