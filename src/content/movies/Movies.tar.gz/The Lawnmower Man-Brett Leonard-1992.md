---
type: movie
country: US, JP, GB
title: "The Lawnmower Man"
year: 1992
director: Brett Leonard
actors: [Jeff Fahey, Pierce Brosnan, Jenny Wright, Mark Bringelson, Geoffrey Lewis]
genre: [Science Fiction, Horror]
length: "1h 48m"
shelf: watched
owned: false
rating: 
watched: 1992-03-05
poster: "https://image.tmdb.org/t/p/w500/aDACpFww9vkeyYOj5xrfJuxoQdK.jpg"
---

# The Lawnmower Man (1992)

![](https://image.tmdb.org/t/p/w500/aDACpFww9vkeyYOj5xrfJuxoQdK.jpg)

A simple man is turned into a genius through the application of computer science.