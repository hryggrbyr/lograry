---
type: movie
country: United States, United Kingdom
title: Candyman
year: 1992
director: Bernard Rose
actors: [Virginia Madsen, Xander Berkeley, Tony Todd]
genre: [Horror, Thriller]
length: 99
shelf: watched
owned: false
rating: 
watched: 1992-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMmZhN2NhOTEtMmVhZC00NWM5LWE4ODgtZGUwMDQxOGViNjY4XkEyXkFqcGc@._V1_SX300.jpg"
---

# Candyman (1992)

![](https://m.media-amazon.com/images/M/MV5BMmZhN2NhOTEtMmVhZC00NWM5LWE4ODgtZGUwMDQxOGViNjY4XkEyXkFqcGc@._V1_SX300.jpg)

The Candyman, a murderous soul with a hook for a hand, is accidentally summoned to reality by a skeptic grad student researching the monster's myth.