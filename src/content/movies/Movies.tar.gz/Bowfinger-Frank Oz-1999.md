---
type: movie
country: US
title: "Bowfinger"
year: 1999
director: Frank Oz
actors: [Steve Martin, Eddie Murphy, Heather Graham, Christine Baranski, Jamie Kennedy]
genre: [Comedy]
length: "1h 37m"
shelf: watched
owned: false
rating: 
watched: 1999-08-12
poster: "https://image.tmdb.org/t/p/w500/iGuiFYEYwFkaRPl3FgLJYEm6dWq.jpg"
---

# Bowfinger (1999)

![](https://image.tmdb.org/t/p/w500/iGuiFYEYwFkaRPl3FgLJYEm6dWq.jpg)

On the verge of bankruptcy and desperate for his big break, aspiring filmmaker Bobby Bowfinger concocts a crazy plan to make his ultimate dream movie. Rallying a ragtag team that includes a starry-eyed ingenue, a has-been diva and a film studio gofer, he sets out to shoot a blockbuster featuring the biggest star in Hollywood, Kit Ramsey -- only without letting Ramsey know he's in the picture.