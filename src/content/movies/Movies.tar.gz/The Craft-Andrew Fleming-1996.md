---
type: movie
country: US
title: "The Craft"
year: 1996
director: Andrew Fleming
actors: [Robin Tunney, Fairuza Balk, Neve Campbell, Rachel True, Skeet Ulrich]
genre: [Horror, Drama, Fantasy]
length: "1h 41m"
shelf: watched
owned: false
rating: 
watched: 1996-05-03
poster: "https://image.tmdb.org/t/p/w500/8bW2RdRkloYtEPhbQZN4wcdmJP4.jpg"
---

# The Craft (1996)

![](https://image.tmdb.org/t/p/w500/8bW2RdRkloYtEPhbQZN4wcdmJP4.jpg)

A Catholic school newcomer falls in with a clique of teen witches who wield their powers against all who dare to cross them -- be they teachers, rivals or meddlesome parents.