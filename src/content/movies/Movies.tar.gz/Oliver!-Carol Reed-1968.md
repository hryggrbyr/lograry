---
type: movie
country: GB
title: "Oliver!"
year: 1968
director: Carol Reed
actors: [Ron Moody, Shani Wallis, Oliver Reed, Harry Secombe, Mark Lester]
genre: [Drama, Family]
length: "2h 33m"
shelf: watched
owned: false
rating: 
watched: 2023-12-16
poster: "https://image.tmdb.org/t/p/w500/1XJgoaOWKrqxkKeBKWLKSigqG8c.jpg"
---

# Oliver! (1968)

![](https://image.tmdb.org/t/p/w500/1XJgoaOWKrqxkKeBKWLKSigqG8c.jpg)

Musical adaptation of Charles Dickens' Oliver Twist, a classic tale of an orphan who runs away from the workhouse and joins up with a group of boys headed by the Artful Dodger and trained to be pickpockets by master thief Fagin.