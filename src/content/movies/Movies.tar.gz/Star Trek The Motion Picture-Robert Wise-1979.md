---
type: movie
country: United States
title: "Star Trek The Motion Picture"
year: 1979
director: Robert Wise
actors: [William Shatner, Leonard Nimoy, DeForest Kelley]
genre: [Adventure, Mystery, Sci-Fi]
length: 143
shelf: watched
owned: false
rating: 
watched: 1979-12-31
poster: "https://m.media-amazon.com/images/M/MV5BNjcyMmVmMTItNTA3Yy00NGJjLTlmYjQtZWQ3ZjcyNmU5NDQ2XkEyXkFqcGc@._V1_SX300.jpg"
---

# Star Trek The Motion Picture (1979)

![](https://m.media-amazon.com/images/M/MV5BNjcyMmVmMTItNTA3Yy00NGJjLTlmYjQtZWQ3ZjcyNmU5NDQ2XkEyXkFqcGc@._V1_SX300.jpg)

When an alien spacecraft of enormous power is spotted approaching Earth, Admiral James T. Kirk resumes command of the overhauled USS Enterprise in order to intercept it.