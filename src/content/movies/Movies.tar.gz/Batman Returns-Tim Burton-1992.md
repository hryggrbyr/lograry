---
type: movie
country: US
title: "Batman Returns"
year: 1992
director: Tim Burton
actors: [Michael Keaton, Danny DeVito, Michelle Pfeiffer, Christopher Walken, Michael Gough]
genre: [Action, Fantasy]
length: "2h 6m"
shelf: watched
owned: false
rating: 
watched: 1992-06-19
poster: "https://image.tmdb.org/t/p/w500/jKBjeXM7iBBV9UkUcOXx3m7FSHY.jpg"
---

# Batman Returns (1992)

![](https://image.tmdb.org/t/p/w500/jKBjeXM7iBBV9UkUcOXx3m7FSHY.jpg)

The monstrous Penguin, who dwells in the sewers beneath Gotham, joins up with corrupt mayoral candidate Max Shreck to topple the Batman once and for all. But when Shreck's timid assistant Selina Kyle finds out, and Shreck tries to kill her, she's transformed into the sexy Catwoman. She teams up with the Penguin and Shreck to destroy Batman, but sparks fly unexpectedly when she confronts the caped crusader.