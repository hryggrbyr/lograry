---
type: movie
country: GB, US
title: "Sense and Sensibility"
year: 1995
director: Ang Lee
actors: [Emma Thompson, Kate Winslet, Alan Rickman, Hugh Grant, Gemma Jones]
genre: [Drama, Romance]
length: "2h 16m"
shelf: watched
owned: false
rating: 
watched: 1996-02-23
poster: "https://image.tmdb.org/t/p/w500/cBK2yL3HqhFvIVd7lLtazWlRZPR.jpg"
---

# Sense and Sensibility (1995)

![](https://image.tmdb.org/t/p/w500/cBK2yL3HqhFvIVd7lLtazWlRZPR.jpg)

The Dashwood sisters, sensible Elinor and passionate Marianne, whose chances at marriage seem doomed by their family's sudden loss of fortune.  When Henry Dashwood dies unexpectedly, his estate must pass on by law to his son from his first marriage, John and wife Fanny. But these circumstances leave Mr. Dashwood's current wife, and daughters Elinor, Marianne and Margaret, without a home and with barely enough money to live on. As Elinor and Marianne struggle to find romantic fulfillment in a society obsessed with financial and social status, they must learn to mix sense with sensibility in their dealings with both money and men.