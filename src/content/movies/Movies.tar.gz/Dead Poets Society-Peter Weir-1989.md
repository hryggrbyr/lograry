---
type: movie
country: US
title: "Dead Poets Society"
year: 1989
director: Peter Weir
actors: [Robin Williams, Robert Sean Leonard, Ethan Hawke, Josh Charles, Gale Hansen]
genre: [Drama]
length: "2h 9m"
shelf: watched
owned: false
rating: 
watched: 1989-06-02
poster: "https://image.tmdb.org/t/p/w500/erzbMlcNHOdx24AXOcn2ZKA7R1q.jpg"
---

# Dead Poets Society (1989)

![](https://image.tmdb.org/t/p/w500/erzbMlcNHOdx24AXOcn2ZKA7R1q.jpg)

At an elite, old-fashioned boarding school in New England, a passionate English teacher inspires his students to rebel against convention and seize the potential of every day, courting the disdain of the stern headmaster.