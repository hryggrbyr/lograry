---
type: movie
country: CA, US
title: "Left Behind"
year: 2014
director: Vic Armstrong
actors: [Nicolas Cage, Chad Michael Murray, Lea Thompson, Nicky Whelan, Martin Klebba]
genre: [Thriller, Action, Science Fiction]
length: "1h 50m"
shelf: watched
owned: false
rating: 
watched: 2014-10-03
poster: "https://image.tmdb.org/t/p/w500/b9Q2WR62yB5Aq0hd6kyRFS9cc3Y.jpg"
---

# Left Behind (2014)

![](https://image.tmdb.org/t/p/w500/b9Q2WR62yB5Aq0hd6kyRFS9cc3Y.jpg)

A small group of survivors are left behind after millions of people suddenly vanish during the rapture and the world is plunged into chaos and destruction.