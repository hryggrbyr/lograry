---
type: movie
country: US
title: "Eternal Sunshine of the Spotless Mind"
year: 2004
director: Michel Gondry
actors: [Jim Carrey, Kate Winslet, Kirsten Dunst, Mark Ruffalo, Elijah Wood]
genre: [Science Fiction, Drama, Romance]
length: "1h 48m"
shelf: watched
owned: false
rating: 
watched: 2004-03-19
poster: "https://image.tmdb.org/t/p/w500/5MwkWH9tYHv3mV9OdYTMR5qreIz.jpg"
---

# Eternal Sunshine of the Spotless Mind (2004)

![](https://image.tmdb.org/t/p/w500/5MwkWH9tYHv3mV9OdYTMR5qreIz.jpg)

Joel Barish, heartbroken that his girlfriend underwent a procedure to erase him from her memory, decides to do the same. However, as he watches his memories of her fade away, he realises that he still loves her, and may be too late to correct his mistake.