---
type: movie
country: US
title: "The Wedding Singer"
year: 1998
director: Frank Coraci
actors: [Adam Sandler, Drew Barrymore, Christine Taylor, Allen Covert, Matthew Glave]
genre: [Romance, Comedy]
length: "1h 37m"
shelf: watched
owned: false
rating: 
watched: 1998-02-13
poster: "https://image.tmdb.org/t/p/w500/zVvyTrcZQb7kC2DPDzyo25WcxXp.jpg"
---

# The Wedding Singer (1998)

![](https://image.tmdb.org/t/p/w500/zVvyTrcZQb7kC2DPDzyo25WcxXp.jpg)

Robbie, a local rock star turned wedding singer, is dumped on the day of his wedding. Meanwhile, waitress Julia finally sets a wedding date with her fiancée Glenn. When Julia and Robbie meet and hit it off, they find that things are more complicated than anybody thought.