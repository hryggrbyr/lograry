---
type: movie
country: US
title: "Charlie's Angels"
year: 2000
director: McG
actors: [Cameron Diaz, Drew Barrymore, Lucy Liu, Bill Murray, Sam Rockwell]
genre: [Action, Adventure, Comedy, Crime, Thriller]
length: "1h 38m"
shelf: watched
owned: false
rating: 
watched: 2000-11-02
poster: "https://image.tmdb.org/t/p/w500/paDTaHGLxhacythNZCT86VPanm6.jpg"
---

# Charlie's Angels (2000)

![](https://image.tmdb.org/t/p/w500/paDTaHGLxhacythNZCT86VPanm6.jpg)

The captivating crime-fighting trio who are masters of disguise, espionage and martial arts are back! When a devious mastermind embroils them in a plot to destroy individual privacy, the Angels, aided by their loyal sidekick Bosley, set out to bring down the bad guys. But when a terrible secret is revealed, it makes the Angels targets for assassination.