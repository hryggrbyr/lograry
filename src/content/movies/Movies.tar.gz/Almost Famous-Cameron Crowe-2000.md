---
type: movie
country: US
title: "Almost Famous"
year: 2000
director: Cameron Crowe
actors: [Billy Crudup, Frances McDormand, Kate Hudson, Jason Lee, Patrick Fugit]
genre: [Drama, Music]
length: "2h 4m"
shelf: watched
owned: false
rating: 
watched: 2000-09-15
poster: "https://image.tmdb.org/t/p/w500/3rrkyLYbgLj84AYvjhdcJot4JPx.jpg"
---

# Almost Famous (2000)

![](https://image.tmdb.org/t/p/w500/3rrkyLYbgLj84AYvjhdcJot4JPx.jpg)

In 1973, 15-year-old William Miller's unabashed love of music and aspiration to become a rock journalist lands him an assignment from Rolling Stone magazine to interview and tour with the up-and-coming band, Stillwater.