---
type: movie
country: US
title: "Where the Crawdads Sing"
year: 2022
director: Olivia Newman
actors: [Daisy Edgar-Jones, Taylor John Smith, Harris Dickinson, David Strathairn, Michael Hyatt]
genre: [Drama, Mystery, Romance]
length: "2h 6m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/n1el846gLDXfhOvrRCsyvaAOQWv.jpg"
---

# Where the Crawdads Sing (2022)

![](https://image.tmdb.org/t/p/w500/n1el846gLDXfhOvrRCsyvaAOQWv.jpg)

Abandoned by her family, Kya raises herself all alone in the marshes outside of her small town. When her former boyfriend is found dead, Kya is instantly branded by the local townspeople and law enforcement as the prime suspect for his murder.
