---
type: movie
country: US
title: "Alien³"
year: 1992
director: David Fincher
actors: [Sigourney Weaver, Charles S. Dutton, Charles Dance, Paul McGann, Brian Glover]
genre: [Science Fiction, Action, Horror]
length: "1h 54m"
shelf: watched
owned: false
rating: 
watched: 1992-05-22
poster: "https://image.tmdb.org/t/p/w500/xh5wI0UoW7DfS1IyLy3d2CgrCEP.jpg"
---

# Alien³ (1992)

![](https://image.tmdb.org/t/p/w500/xh5wI0UoW7DfS1IyLy3d2CgrCEP.jpg)

After escaping with Newt and Hicks from the alien planet, Ripley crash lands on Fiorina 161, a prison planet and host to a correctional facility. Unfortunately, although Newt and Hicks do not survive the crash, a more unwelcome visitor does. The prison does not allow weapons of any kind, and with aid being a long time away, the prisoners must simply survive in any way they can.