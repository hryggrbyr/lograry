---
type: movie
country: US
title: "Erin Brockovich"
year: 2000
director: Steven Soderbergh
actors: [Julia Roberts, Albert Finney, Aaron Eckhart, Marg Helgenberger, Cherry Jones]
genre: [Drama]
length: "2h 11m"
shelf: watched
owned: false
rating: 
watched: 2000-03-17
poster: "https://image.tmdb.org/t/p/w500/jEMvWBWVjndZT0vJnLrRWi9ajea.jpg"
---

# Erin Brockovich (2000)

![](https://image.tmdb.org/t/p/w500/jEMvWBWVjndZT0vJnLrRWi9ajea.jpg)

A twice-divorced mother of three who sees an injustice, takes on the bad guy and wins -- with a little help from her push-up bra. Erin goes to work for an attorney and comes across medical records describing illnesses clustered in one nearby town. She starts investigating and soon exposes a monumental cover-up.