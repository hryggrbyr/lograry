---
type: movie
country: US
title: "Big"
year: 1988
director: Penny Marshall
actors: [Tom Hanks, Elizabeth Perkins, Robert Loggia, John Heard, Jared Rushton]
genre: [Fantasy, Drama, Comedy, Romance, Family]
length: "1h 44m"
shelf: watched
owned: false
rating: 
watched: 1988-06-03
poster: "https://image.tmdb.org/t/p/w500/eWhCDJiwxvx3YXkAFRiHjimnF0j.jpg"
---

# Big (1988)

![](https://image.tmdb.org/t/p/w500/eWhCDJiwxvx3YXkAFRiHjimnF0j.jpg)

When a young boy makes a wish at a carnival machine to be big—he wakes up the following morning to find that it has been granted and his body has grown older overnight. But he is still the same 13-year-old boy inside. Now he must learn how to cope with the unfamiliar world of grown-ups including getting a job and having his first romantic encounter with a woman.