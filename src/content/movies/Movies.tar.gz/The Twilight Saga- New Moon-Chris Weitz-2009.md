---
type: movie
country: US
title: "The Twilight Saga: New Moon"
year: 2009
director: Chris Weitz
actors: [Kristen Stewart, Robert Pattinson, Taylor Lautner, Dakota Fanning, Michael Sheen]
genre: [Adventure, Fantasy, Drama, Romance]
length: "2h 11m"
shelf: watched
owned: false
rating: 
watched: 2009-11-20
poster: "https://image.tmdb.org/t/p/w500/k2qTooPlHffgNABNWxeJdGMglPK.jpg"
---

# The Twilight Saga: New Moon (2009)

![](https://image.tmdb.org/t/p/w500/k2qTooPlHffgNABNWxeJdGMglPK.jpg)

Forks, Washington resident Bella Swan is reeling from the departure of her vampire love, Edward Cullen, and finds comfort in her friendship with Jacob Black, a werewolf. But before she knows it, she's thrust into a centuries-old conflict, and her desire to be with Edward at any cost leads her to take greater and greater risks.