---
type: movie
country: France, United States
title: "Killing Zoe"
year: 1993
director: Roger Avary
actors: [Eric Stoltz, Julie Delpy, Martin Raymond]
genre: [Crime, Drama, Thriller]
length: 96
shelf: watched
owned: false
rating: 
watched: 1993-12-31
poster: "https://m.media-amazon.com/images/M/MV5BOGU1MmI3MzUtNzM5OC00MGZjLWJiNjktNTg0MjYxMjlhNmIxXkEyXkFqcGc@._V1_SX300.jpg"
---

# Killing Zoe (1993)

![](https://m.media-amazon.com/images/M/MV5BOGU1MmI3MzUtNzM5OC00MGZjLWJiNjktNTg0MjYxMjlhNmIxXkEyXkFqcGc@._V1_SX300.jpg)

The cab driver sets American Zed up with Zoe in his Paris hotel. Despite FFR1000 charged, she's an art student with day jobs e.g. bank. Safecracker Zed meets his junkie friend after 11 years to rob a bank.