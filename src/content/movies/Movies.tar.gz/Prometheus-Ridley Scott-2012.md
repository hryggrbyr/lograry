---
type: movie
country: US
title: "Prometheus"
year: 2012
director: Ridley Scott
actors: [Noomi Rapace, Michael Fassbender, Charlize Theron, Idris Elba, Guy Pearce]
genre: [Science Fiction, Adventure, Mystery]
length: "2h 4m"
shelf: watched
owned: false
rating: 
watched: 2012-06-08
poster: "https://image.tmdb.org/t/p/w500/m7nZCtHJyDLncBUarfM5h5mrppx.jpg"
---

# Prometheus (2012)

![](https://image.tmdb.org/t/p/w500/m7nZCtHJyDLncBUarfM5h5mrppx.jpg)

A team of explorers discover a clue to the origins of mankind on Earth, leading them on a journey to the darkest corners of the universe. There, they must fight a terrifying battle to save the future of the human race.