---
type: movie
country: France, United States
title: "Léon The Professional"
year: 1994
director: Luc Besson
actors: [Jean Reno, Gary Oldman, Natalie Portman]
genre: [Action, Crime, Drama]
length: 110
shelf: watched
owned: true
rating: 
watched: 1994-12-31
poster: "https://m.media-amazon.com/images/M/MV5BNGRkYTNhOWQtYmI0Ni00MjZhLWJmMzAtMTA2Mjg4NGNiNDU0XkEyXkFqcGc@._V1_SX300.jpg"
---

# Léon The Professional (1994)

![](https://m.media-amazon.com/images/M/MV5BNGRkYTNhOWQtYmI0Ni00MjZhLWJmMzAtMTA2Mjg4NGNiNDU0XkEyXkFqcGc@._V1_SX300.jpg)

An Italian hit man protects a New York orphan.