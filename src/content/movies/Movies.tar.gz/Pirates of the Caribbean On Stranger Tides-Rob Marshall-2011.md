---
type: movie
country: United States, United Kingdom
title: Pirates of the Caribbean On Stranger Tides
year: 2011
director: Rob Marshall
actors: [Johnny Depp, Penélope Cruz, Ian McShane]
genre: [Action, Adventure, Fantasy]
length: 136
shelf: watched
owned: false
rating: 
watched: 2011-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMjE5MjkwODI3Nl5BMl5BanBnXkFtZTcwNjcwMDk4NA@@._V1_SX300.jpg"
---

# Pirates of the Caribbean On Stranger Tides (2011)

![](https://m.media-amazon.com/images/M/MV5BMjE5MjkwODI3Nl5BMl5BanBnXkFtZTcwNjcwMDk4NA@@._V1_SX300.jpg)

Jack Sparrow and Barbossa embark on a quest to find the elusive fountain of youth, only to discover that Blackbeard and his daughter are after it too.