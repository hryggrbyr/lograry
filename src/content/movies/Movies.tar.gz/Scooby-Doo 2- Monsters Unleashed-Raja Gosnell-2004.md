---
type: movie
country: US
title: "Scooby-Doo 2: Monsters Unleashed"
year: 2004
director: Raja Gosnell
actors: [Freddie Prinze Jr., Sarah Michelle Gellar, Matthew Lillard, Linda Cardellini, Neil Fanning]
genre: [Mystery, Fantasy, Adventure, Comedy]
length: "1h 33m"
shelf: watched
owned: false
rating: 
watched: 2004-03-26
poster: "https://image.tmdb.org/t/p/w500/5BrXCJrs22bR5KR6mLHluYo6y4m.jpg"
---

# Scooby-Doo 2: Monsters Unleashed (2004)

![](https://image.tmdb.org/t/p/w500/5BrXCJrs22bR5KR6mLHluYo6y4m.jpg)

After solving their last mystery at Spooky Island, the Mystery Inc. gang is back in Coolsville, where they are being honored with their very own exhibit at the Coolsonian Criminology Museum. However, when a masked villain steals costumes of classic monsters on display and brings them to life, the gang must come out of retirement to solve the case.