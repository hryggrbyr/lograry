---
type: movie
country: US
title: "The Lion King"
year: 1994
director: Roger Allers, Rob Minkoff
actors: [Matthew Broderick, Moira Kelly, Nathan Lane, Ernie Sabella, James Earl Jones]
genre: [Family, Animation, Drama, Fantasy, Adventure]
length: "1h 29m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/sKCr78MXSLixwmZ8DyJLrpMsd15.jpg"
---

# The Lion King (1994)

![](https://image.tmdb.org/t/p/w500/sKCr78MXSLixwmZ8DyJLrpMsd15.jpg)

Young lion prince Simba, eager to one day become king of the Pride Lands, grows up under the watchful eye of his father Mufasa; all the while his villainous uncle Scar conspires to take the throne for himself. Amid betrayal and tragedy, Simba must confront his past and find his rightful place in the Circle of Life.