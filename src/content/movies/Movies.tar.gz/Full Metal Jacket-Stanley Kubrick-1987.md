---
type: movie
country: US
title: "Full Metal Jacket"
year: 1987
director: Stanley Kubrick
actors: [Matthew Modine, Adam Baldwin, Vincent D'Onofrio, R. Lee Ermey, Dorian Harewood]
genre: [Drama, War]
length: "1h 57m"
shelf: watched
owned: false
rating: 
watched: 1987-06-26
poster: "https://image.tmdb.org/t/p/w500/kMKyx1k8hWWscYFnPbnxxN4Eqo4.jpg"
---

# Full Metal Jacket (1987)

![](https://image.tmdb.org/t/p/w500/kMKyx1k8hWWscYFnPbnxxN4Eqo4.jpg)

A pragmatic U.S. Marine observes the dehumanizing effects the U.S.-Vietnam War has on his fellow recruits from their brutal boot camp training to the bloody street fighting in Hue.