---
type: movie
country: US
title: "Animal House"
year: 1978
director: John Landis
actors: [John Belushi, Karen Allen, Tom Hulce, Stephen Furst, Mark Metcalf]
genre: [Comedy]
length: "1h 49m"
shelf: watched
owned: false
rating: 
watched: 1978-07-28
poster: "https://image.tmdb.org/t/p/w500/fWooBbipMRIKeSRhEzmeaDV0T8H.jpg"
---

# Animal House (1978)

![](https://image.tmdb.org/t/p/w500/fWooBbipMRIKeSRhEzmeaDV0T8H.jpg)

At a 1962 College, Dean Vernon Wormer is determined to expel the entire Delta Tau Chi Fraternity, but those troublemakers have other plans for him.