---
type: movie
country: US
title: "The Exorcist"
year: 1973
director: William Friedkin
actors: [Ellen Burstyn, Linda Blair, Jason Miller, Max von Sydow, Lee J. Cobb]
genre: [Horror]
length: "2h 2m"
shelf: watched
owned: false
rating: 
watched: 1973-12-26
poster: "https://image.tmdb.org/t/p/w500/5x0CeVHJI8tcDx8tUUwYHQSNILq.jpg"
---

# The Exorcist (1973)

![](https://image.tmdb.org/t/p/w500/5x0CeVHJI8tcDx8tUUwYHQSNILq.jpg)

When a charming 12-year-old girl takes on the characteristics and voices of others, doctors say there is nothing they can do. As people begin to die, the girl's mother realizes her daughter has been possessed by the Devil. Her daughter's only possible hope lies with two priests and the ancient rite of demonic exorcism.