---
type: movie
country: US
title: "High Fidelity"
year: 2000
director: Stephen Frears
actors: [John Cusack, Iben Hjejle, Todd Louiso, Jack Black, Lisa Bonet]
genre: [Drama, Comedy, Romance, Music]
length: "1h 53m"
shelf: watched
owned: false
rating: 
watched: 2000-03-17
poster: "https://image.tmdb.org/t/p/w500/e2LZGB62GMhv3Fo8tDZjY87I81a.jpg"
---

# High Fidelity (2000)

![](https://image.tmdb.org/t/p/w500/e2LZGB62GMhv3Fo8tDZjY87I81a.jpg)

After his long-time girlfriend dumps him, a thirty-year-old record store owner seeks to understand why he is unlucky in love while recounting his "top five breakups of all time".