---
type: movie
country: US
title: "Madagascar"
year: 2005
director: Eric Darnell, Tom McGrath
actors: [Ben Stiller, Chris Rock, David Schwimmer, Jada Pinkett Smith, Sacha Baron Cohen]
genre: [Family, Animation, Adventure, Comedy]
length: "1h 26m"
shelf: watched
owned: false
rating: 
watched: 2024-12-01
poster: "https://image.tmdb.org/t/p/w500/zMpJY5CJKUufG9OTw0In4eAFqPX.jpg"
---

# Madagascar (2005)

![](https://image.tmdb.org/t/p/w500/zMpJY5CJKUufG9OTw0In4eAFqPX.jpg)

Four animal friends get a taste of the wild life when they break out of captivity at the Central Park Zoo and wash ashore on the island of Madagascar.