---
type: movie
country: GB, US
title: "The Man Who Fell to Earth"
year: 1976
director: Nicolas Roeg
actors: [David Bowie, Rip Torn, Candy Clark, Tony Mascia, Buck Henry]
genre: [Science Fiction, Drama]
length: "2h 19m"
shelf: watched
owned: false
rating: 
watched: 1976-03-18
poster: "https://image.tmdb.org/t/p/w500/gwmPVphE5DMFFGXGMhfEFyxOOYj.jpg"
---

# The Man Who Fell to Earth (1976)

![](https://image.tmdb.org/t/p/w500/gwmPVphE5DMFFGXGMhfEFyxOOYj.jpg)

Thomas Jerome Newton is an alien who has come to Earth in search of water to save his home planet. Aided by lawyer Oliver Farnsworth, Thomas uses his knowledge of advanced technology to create profitable inventions. While developing a method to transport water, Thomas meets Mary-Lou, a quiet hotel clerk, and begins to fall in love with her. Just as he is ready to leave Earth, Thomas is intercepted by the U.S. government, and his entire plan is threatened.