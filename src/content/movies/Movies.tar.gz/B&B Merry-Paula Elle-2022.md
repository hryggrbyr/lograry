---
type: movie
country: US
title: "B&B Merry"
year: 2022
director: Paula Elle
actors: [Jen Lilley, Jesse Hutch, Nick Preston, Shelly Williams, Peter Louis Chouinard]
genre: [Romance, Comedy, Drama, TV Movie, Christmas]
length: "1h 25m"
shelf: watched
owned: false
rating: 
watched: 2023-12-08
poster: "https://image.tmdb.org/t/p/w500/7WSMNERoqgtOwV1Q5xDmAiLvMeE.jpg"
---

# B&B Merry (2022)

![](https://image.tmdb.org/t/p/w500/7WSMNERoqgtOwV1Q5xDmAiLvMeE.jpg)

Tracey Wise is a renowned luxury travel blogger who is invited by Graham Cooper to a Christmas getaway in exchange for her review of his family’s small bed & breakfast, Silver Peak. Unfortunately, the humble B&B is facing tough competition from an upscale hotel resort nearby that has been stealing guests and threatening the survival of the family business.