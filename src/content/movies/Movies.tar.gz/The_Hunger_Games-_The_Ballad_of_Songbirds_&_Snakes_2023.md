---
type: movie
country: US
title: "The Hunger Games: The Ballad of Songbirds & Snakes"
year: 2023
director: Francis Lawrence
actors: [Tom Blyth, Rachel Zegler, Peter Dinklage, Jason Schwartzman, Hunter Schafer]
genre: [Drama, Science Fiction, Adventure, Action]
length: "2h 37m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/lrkOYL5GBTFW9cgs9RlojxAcZZF.jpg"
---

# The Hunger Games: The Ballad of Songbirds & Snakes (2023)

![](https://image.tmdb.org/t/p/w500/lrkOYL5GBTFW9cgs9RlojxAcZZF.jpg)

64 years before he becomes the tyrannical president of Panem, Coriolanus Snow sees a chance for a change in fortunes when he mentors Lucy Gray Baird, the female tribute from District 12.
