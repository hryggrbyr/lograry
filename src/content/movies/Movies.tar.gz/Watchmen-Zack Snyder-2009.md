---
type: movie
country: US
title: "Watchmen"
year: 2009
director: Zack Snyder
actors: [Malin Åkerman, Patrick Wilson, Billy Crudup, Matthew Goode, Jackie Earle Haley]
genre: [Mystery, Action, Science Fiction]
length: "2h 43m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/aVURelN3pM56lFM7Dgfs5TixcIf.jpg"
---

# Watchmen (2009)

![](https://image.tmdb.org/t/p/w500/aVURelN3pM56lFM7Dgfs5TixcIf.jpg)

In a gritty and alternate 1985, the glory days of costumed vigilantes have been brought to a close by a government crackdown. But after one of the masked veterans is brutally murdered, an investigation into the killer is initiated. The reunited heroes set out to prevent their own destruction, but in doing so they uncover a sinister plot that puts all of humanity in grave danger.