---
type: movie
country: US
title: "Benny & Joon"
year: 1993
director: Jeremiah S. Chechik
actors: [Johnny Depp, Mary Stuart Masterson, Aidan Quinn, Julianne Moore, Oliver Platt]
genre: [Comedy, Drama]
length: "1h 38m"
shelf: watched
owned: false
rating: 
watched: 1993-04-16
poster: "https://image.tmdb.org/t/p/w500/t1IVTmj0TrVt5zxps7VRSdvLKSo.jpg"
---

# Benny & Joon (1993)

![](https://image.tmdb.org/t/p/w500/t1IVTmj0TrVt5zxps7VRSdvLKSo.jpg)

A mentally ill young woman finds her love in an eccentric man who models himself after Buster Keaton.