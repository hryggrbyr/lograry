---
type: movie
country: US
title: "GoodFellas"
year: 1990
director: Martin Scorsese
actors: [Robert De Niro, Ray Liotta, Joe Pesci, Lorraine Bracco, Paul Sorvino]
genre: [Drama, Crime]
length: "2h 25m"
shelf: watched
owned: false
rating: 
watched: 1990-09-19
poster: "https://image.tmdb.org/t/p/w500/aKuFiU82s5ISJpGZp7YkIr3kCUd.jpg"
---

# GoodFellas (1990)

![](https://image.tmdb.org/t/p/w500/aKuFiU82s5ISJpGZp7YkIr3kCUd.jpg)

The true story of Henry Hill, a half-Irish, half-Sicilian Brooklyn kid who is adopted by neighbourhood gangsters at an early age and climbs the ranks of a Mafia family under the guidance of Jimmy Conway.