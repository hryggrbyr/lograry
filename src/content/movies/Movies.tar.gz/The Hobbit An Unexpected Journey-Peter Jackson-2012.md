---
type: movie
country: New Zealand, United States
title: "The Hobbit An Unexpected Journey"
year: 2012
director: Peter Jackson
actors: [Martin Freeman, Ian McKellen, Richard Armitage]
genre: [Adventure, Fantasy]
length: 169
shelf: watched
owned: false
rating: 
watched: 2012-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMTcwNTE4MTUxMl5BMl5BanBnXkFtZTcwMDIyODM4OA@@._V1_SX300.jpg"
---

# The Hobbit An Unexpected Journey (2012)

![](https://m.media-amazon.com/images/M/MV5BMTcwNTE4MTUxMl5BMl5BanBnXkFtZTcwMDIyODM4OA@@._V1_SX300.jpg)

A reluctant Hobbit, Bilbo Baggins, sets out to the Lonely Mountain with a spirited group of dwarves to reclaim their mountain home and the gold within it from the dragon Smaug.