---
type: movie
country: US
title: "mother!"
year: 2017
director: Darren Aronofsky
actors: [Jennifer Lawrence, Javier Bardem, Ed Harris, Michelle Pfeiffer, Brian Gleeson]
genre: [Horror, Drama]
length: "2h 1m"
shelf: watched
owned: false
rating: 
watched: 2017-09-15
poster: "https://image.tmdb.org/t/p/w500/fjny9chXPx69ln1LMJxbwi5yHMt.jpg"
---

# mother! (2017)

![](https://image.tmdb.org/t/p/w500/fjny9chXPx69ln1LMJxbwi5yHMt.jpg)

A couple's relationship is tested when uninvited guests arrive at their home, disrupting their tranquil existence.