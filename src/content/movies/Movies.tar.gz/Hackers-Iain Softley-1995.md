---
type: movie
country: US
title: "Hackers"
year: 1995
director: Iain Softley
actors: [Jonny Lee Miller, Angelina Jolie, Matthew Lillard, Jesse Bradford, Renoly Santiago]
genre: [Action, Crime, Thriller, Drama]
length: "1h 47m"
shelf: watched
owned: false
rating: 
watched: 1995-09-14
poster: "https://image.tmdb.org/t/p/w500/qfx2EENW1sOpKNVKLzr7VOhlxkt.jpg"
---

# Hackers (1995)

![](https://image.tmdb.org/t/p/w500/qfx2EENW1sOpKNVKLzr7VOhlxkt.jpg)

Along with his new friends, a teenager who was arrested by the US Secret Service and banned from using a computer for writing a computer virus discovers a plot by a nefarious hacker, but they must use their computer skills to find the evidence while being pursued by the Secret Service and the evil computer genius behind the virus.