---
type: movie
country: US
title: "The Maltese Falcon"
year: 1941
director: John Huston
actors: [Humphrey Bogart, Mary Astor, Gladys George, Peter Lorre, Barton MacLane]
genre: [Mystery, Crime, Thriller]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 1941-10-18
poster: "https://image.tmdb.org/t/p/w500/bf4o6Uzw5wqLjdKwRuiDrN1xyvl.jpg"
---

# The Maltese Falcon (1941)

![](https://image.tmdb.org/t/p/w500/bf4o6Uzw5wqLjdKwRuiDrN1xyvl.jpg)

A private detective takes on a case that involves him with three eccentric criminals, a beautiful liar, and their quest for a priceless statuette.