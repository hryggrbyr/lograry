---
type: movie
country: US
title: "Planes, Trains and Automobiles"
year: 1987
director: John Hughes
actors: [Steve Martin, John Candy, Laila Robins, Michael McKean, Dylan Baker]
genre: [Comedy]
length: "1h 33m"
shelf: watched
owned: false
rating: 
watched: 1987-11-26
poster: "https://image.tmdb.org/t/p/w500/3RSucVsX96Ste8WDJfZP1hbNGqQ.jpg"
---

# Planes, Trains and Automobiles (1987)

![](https://image.tmdb.org/t/p/w500/3RSucVsX96Ste8WDJfZP1hbNGqQ.jpg)

An irritable marketing executive, Neal Page, is heading home to Chicago for Thanksgiving when a number of delays force him to travel with a well meaning but overbearing shower curtain ring salesman, Del Griffith.