---
type: movie
country: US
title: "House of 1000 Corpses"
year: 2003
director: Rob Zombie
actors: [Sid Haig, Bill Moseley, Sheri Moon Zombie, Karen Black, Erin Daniels]
genre: [Horror]
length: "1h 29m"
shelf: watched
owned: false
rating: 
watched: 2003-04-11
poster: "https://image.tmdb.org/t/p/w500/29c2qgXmSREosLBevOILEuMWzQC.jpg"
---

# House of 1000 Corpses (2003)

![](https://image.tmdb.org/t/p/w500/29c2qgXmSREosLBevOILEuMWzQC.jpg)

Two teenage couples traveling across the backwoods of Texas searching for urban legends of serial killers end up as prisoners of a bizarre and sadistic backwater family of serial killers.