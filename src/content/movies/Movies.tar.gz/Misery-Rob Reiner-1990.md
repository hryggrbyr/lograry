---
type: movie
country: US
title: "Misery"
year: 1990
director: Rob Reiner
actors: [Kathy Bates, James Caan, Richard Farnsworth, Lauren Bacall, Frances Sternhagen]
genre: [Drama, Thriller]
length: "1h 47m"
shelf: watched
owned: false
rating: 
watched: 1990-11-30
poster: "https://image.tmdb.org/t/p/w500/23Y65uWaVMpqfbZTN3CT0aei4D5.jpg"
---

# Misery (1990)

![](https://image.tmdb.org/t/p/w500/23Y65uWaVMpqfbZTN3CT0aei4D5.jpg)

After an accident, acclaimed novelist Paul Sheldon is rescued by a nurse who claims to be his biggest fan.  Her obsession takes a dark turn when she holds him captive in her remote Colorado home and forces him to write back to life the popular literary character he killed off.