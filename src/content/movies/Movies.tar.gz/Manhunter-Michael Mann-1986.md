---
type: movie
country: US
title: "Manhunter"
year: 1986
director: Michael Mann
actors: [William Petersen, Tom Noonan, Dennis Farina, Brian Cox, Kim Greist]
genre: [Crime, Horror, Thriller]
length: "2h 0m"
shelf: watched
owned: false
rating: 
watched: 1986-08-14
poster: "https://image.tmdb.org/t/p/w500/6rb24x39vV8n5301IelC8rCPJTH.jpg"
---

# Manhunter (1986)

![](https://image.tmdb.org/t/p/w500/6rb24x39vV8n5301IelC8rCPJTH.jpg)

FBI Agent Will Graham, who retired after catching Hannibal Lecter, returns to duty to engage in a risky cat-and-mouse game with Lecter to capture a new killer.