---
type: movie
country: GB
title: "Shaun of the Dead"
year: 2004
director: Edgar Wright
actors: [Simon Pegg, Nick Frost, Kate Ashfield, Lucy Davis, Dylan Moran]
genre: [Horror, Comedy]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 2004-09-24
poster: "https://image.tmdb.org/t/p/w500/dgXPhzNJH8HFTBjXPB177yNx6RI.jpg"
---

# Shaun of the Dead (2004)

![](https://image.tmdb.org/t/p/w500/dgXPhzNJH8HFTBjXPB177yNx6RI.jpg)

Shaun lives a supremely uneventful life, which revolves around his girlfriend, his mother, and, above all, his local pub. This gentle routine is threatened when the dead return to life and make strenuous attempts to snack on ordinary Londoners.