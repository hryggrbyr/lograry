---
type: movie
country: US
title: "Boogie Nights"
year: 1997
director: Paul Thomas Anderson
actors: [Mark Wahlberg, Burt Reynolds, Julianne Moore, John C. Reilly, Heather Graham]
genre: [Drama]
length: "2h 36m"
shelf: watched
owned: false
rating: 
watched: 1997-10-10
poster: "https://image.tmdb.org/t/p/w500/6fzz3HkAGJxhGcwRZwpbEZxgZMu.jpg"
---

# Boogie Nights (1997)

![](https://image.tmdb.org/t/p/w500/6fzz3HkAGJxhGcwRZwpbEZxgZMu.jpg)

Set in 1977, back when sex was safe, pleasure was a business and business was booming, idealistic porn producer Jack Horner aspires to elevate his craft to an art form. Horner discovers Eddie Adams, a hot young talent working as a busboy in a nightclub, and welcomes him into the extended family of movie-makers, misfits and hangers-on that are always around. Adams' rise from nobody to a celebrity adult entertainer is meteoric, and soon the whole world seems to know his porn alter ego, "Dirk Diggler". Now, when disco and drugs are in vogue, fashion is in flux and the party never seems to stop, Adams' dreams of turning sex into stardom are about to collide with cold, hard reality.