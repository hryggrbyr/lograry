---
type: movie
country: United States
title: Winter's Bone
year: 2010
director: Debra Granik
actors: [Jennifer Lawrence, John Hawkes, Garret Dillahunt]
genre: [Crime, Drama, Mystery]
length: 100
shelf: watchlist
owned: false
rating: 
poster: "https://m.media-amazon.com/images/M/MV5BMjA0OTM3MDMxNF5BMl5BanBnXkFtZTcwMDY1MjI0Mw@@._V1_SX300.jpg"
url: N/A
---

# Winter's Bone (2010)

![](https://m.media-amazon.com/images/M/MV5BMjA0OTM3MDMxNF5BMl5BanBnXkFtZTcwMDY1MjI0Mw@@._V1_SX300.jpg)

An unflinching Ozark Mountain girl hacks through dangerous social terrain as she hunts down her drug-dealing father while trying to keep her family intact.