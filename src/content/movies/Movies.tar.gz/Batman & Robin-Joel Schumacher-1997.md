---
type: movie
country: United States, United Kingdom
title: Batman & Robin
year: 1997
director: Joel Schumacher
actors: [Arnold Schwarzenegger, George Clooney, Chris O'Donnell]
genre: [Action, Sci-Fi]
length: 125
shelf: watched
owned: false
rating: 
watched: 1997-12-31
poster: "https://m.media-amazon.com/images/M/MV5BYzU3ZjE3M2UtM2E4Ni00MDI5LTkyZGUtOTFkMGIyYjNjZGU3XkEyXkFqcGc@._V1_SX300.jpg"
---

# Batman & Robin (1997)

![](https://m.media-amazon.com/images/M/MV5BYzU3ZjE3M2UtM2E4Ni00MDI5LTkyZGUtOTFkMGIyYjNjZGU3XkEyXkFqcGc@._V1_SX300.jpg)

Batman and Robin try to keep their relationship together even as they must stop Mr. Freeze and Poison Ivy from freezing Gotham City.