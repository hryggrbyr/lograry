---
type: movie
country: GB
title: "The Railway Children"
year: 1970
director: Lionel Jeffries
actors: [Dinah Sheridan, Bernard Cribbins, William Mervyn, Iain Cuthbertson, Jenny Agutter]
genre: [Drama, Family]
length: "1h 49m"
shelf: watched
owned: false
rating: 
watched: 1970-12-21
poster: "https://image.tmdb.org/t/p/w500/kusEIHfdngzcypY36yjWJVWMShj.jpg"
---

# The Railway Children (1970)

![](https://image.tmdb.org/t/p/w500/kusEIHfdngzcypY36yjWJVWMShj.jpg)

After the enforced absence of their father, the three Waterbury children move with their mother to Yorkshire, where they find themselves involved in several unexpected dramas along the railway by their new home.