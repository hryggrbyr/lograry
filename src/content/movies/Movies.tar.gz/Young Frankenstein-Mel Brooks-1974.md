---
type: movie
country: US
title: "Young Frankenstein"
year: 1974
director: Mel Brooks
actors: [Gene Wilder, Peter Boyle, Marty Feldman, Madeline Kahn, Cloris Leachman]
genre: [Comedy]
length: "1h 46m"
shelf: watched
owned: false
rating: 
watched: 1974-12-15
poster: "https://image.tmdb.org/t/p/w500/c6335WJCZO8NK5wehHk5sA9Cypv.jpg"
---

# Young Frankenstein (1974)

![](https://image.tmdb.org/t/p/w500/c6335WJCZO8NK5wehHk5sA9Cypv.jpg)

A young neurosurgeon inherits the castle of his grandfather, the famous Dr. Victor von Frankenstein. In the castle he finds a funny hunchback, a pretty lab assistant and the elderly housekeeper. Young Frankenstein believes that the work of his grandfather was delusional, but when he discovers the book where the mad doctor described his reanimation experiment, he suddenly changes his mind.