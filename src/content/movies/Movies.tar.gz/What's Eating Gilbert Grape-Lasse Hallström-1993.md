---
type: movie
country: US
title: "What's Eating Gilbert Grape"
year: 1993
director: Lasse Hallström
actors: [Johnny Depp, Juliette Lewis, Leonardo DiCaprio, Mary Steenburgen, Darlene Cates]
genre: [Romance, Drama]
length: "1h 58m"
shelf: watched
owned: false
rating: 
watched: 1993-12-17
poster: "https://image.tmdb.org/t/p/w500/8r9yts6XHbB1xNLaPC6ExNAK1Qu.jpg"
---

# What's Eating Gilbert Grape (1993)

![](https://image.tmdb.org/t/p/w500/8r9yts6XHbB1xNLaPC6ExNAK1Qu.jpg)

Gilbert Grape is a small-town young man with a lot of responsibility. Chief among his concerns are his mother, who is so overweight that she can't leave the house, and his mentally impaired younger brother, Arnie, who has a knack for finding trouble. Settled into a job at a grocery store and an ongoing affair with local woman Betty Carver, Gilbert finally has his life shaken up by the free-spirited Becky.