---
type: movie
country: US
title: "Practical Magic"
year: 1998
director: Griffin Dunne
actors: [Sandra Bullock, Nicole Kidman, Stockard Channing, Dianne Wiest, Goran Višnjić]
genre: [Romance, Comedy, Fantasy]
length: "1h 44m"
shelf: watched
owned: false
rating: 
watched: 1998-10-16
poster: "https://image.tmdb.org/t/p/w500/AwmToSgf2IL3aHv0QRVsR5KvChv.jpg"
---

# Practical Magic (1998)

![](https://image.tmdb.org/t/p/w500/AwmToSgf2IL3aHv0QRVsR5KvChv.jpg)

Sally and Gillian Owens, born into a magical family, have mostly avoided witchcraft themselves. But when Gillian's vicious boyfriend, Jimmy Angelov, dies unexpectedly, the Owens sisters give themselves a crash course in hard magic. With policeman Gary Hallet growing suspicious, the girls struggle to resurrect Angelov -- and unwittingly inject his corpse with an evil spirit that threatens to end their family line.