---
type: movie
country: United Kingdom, United States
title: "Thirteen"
year: 2003
director: Catherine Hardwicke
actors: [Evan Rachel Wood, Holly Hunter, Nikki Reed]
genre: [Drama]
length: 100
shelf: watched
owned: false
rating: 
watched: 2003-12-31
poster: "https://m.media-amazon.com/images/M/MV5BOWVlOWU0NjgtOGY3Yi00MTI2LWEyNDgtNmJlNDRiM2Y2MzFhXkEyXkFqcGc@._V1_SX300.jpg"
---

# Thirteen (2003)

![](https://m.media-amazon.com/images/M/MV5BOWVlOWU0NjgtOGY3Yi00MTI2LWEyNDgtNmJlNDRiM2Y2MzFhXkEyXkFqcGc@._V1_SX300.jpg)

A thirteen-year-old girl's relationship with her mother is put to the test as she discovers drugs, sex, and petty crime in the company of her cool but troubled best friend.