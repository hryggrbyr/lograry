---
type: movie
country: US
title: "Walk the Line"
year: 2005
director: James Mangold
actors: [Joaquin Phoenix, Reese Witherspoon, Ginnifer Goodwin, Robert Patrick, Dallas Roberts]
genre: [Drama, Music, Romance]
length: "2h 16m"
shelf: watched
owned: false
rating: 
watched: 2005-11-18
poster: "https://image.tmdb.org/t/p/w500/p8lPTjvjOjTfvC1E9pmMwcF9vkn.jpg"
---

# Walk the Line (2005)

![](https://image.tmdb.org/t/p/w500/p8lPTjvjOjTfvC1E9pmMwcF9vkn.jpg)

A chronicle of country music legend Johnny Cash's life, from his early days on an Arkansas cotton farm to his rise to fame with Sun Records in Memphis, where he recorded alongside Elvis Presley, Jerry Lee Lewis and Carl Perkins.