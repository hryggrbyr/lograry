---
type: movie
country: US
title: "It's a Wonderful Life"
year: 1946
director: Frank Capra
actors: [James Stewart, Donna Reed, Lionel Barrymore, Thomas Mitchell, Henry Travers]
genre: [Drama, Family, Fantasy, Christmas]
length: "2h 10m"
shelf: watched
owned: false
rating: 
watched: 1947-01-07
poster: "https://image.tmdb.org/t/p/w500/bSqt9rhDZx1Q7UZ86dBPKdNomp2.jpg"
---

# It's a Wonderful Life (1946)

![](https://image.tmdb.org/t/p/w500/bSqt9rhDZx1Q7UZ86dBPKdNomp2.jpg)

A holiday favourite for generations...  George Bailey has spent his entire life giving to the people of Bedford Falls.  All that prevents rich skinflint Mr. Potter from taking over the entire town is George's modest building and loan company.  But on Christmas Eve the business's $8,000 is lost and George's troubles begin.