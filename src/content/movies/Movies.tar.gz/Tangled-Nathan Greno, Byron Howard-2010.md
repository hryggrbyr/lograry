---
type: movie
country: US
title: "Tangled"
year: 2010
director: Nathan Greno, Byron Howard
actors: [Mandy Moore, Zachary Levi, Donna Murphy, Ron Perlman, M.C. Gainey]
genre: [Animation, Family, Adventure]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 2010-11-24
poster: "https://image.tmdb.org/t/p/w500/ym7Kst6a4uodryxqbGOxmewF235.jpg"
---

# Tangled (2010)

![](https://image.tmdb.org/t/p/w500/ym7Kst6a4uodryxqbGOxmewF235.jpg)

Feisty teenager Rapunzel, who has long and magical hair, wants to go and see sky lanterns on her eighteenth birthday, but she's bound to a tower by her overprotective mother. She strikes a deal with Flynn Rider, a charming wanted thief, and the duo set off on an action-packed escapade.