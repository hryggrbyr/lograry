---
type: movie
country: US
title: "Vertigo"
year: 1958
director: Alfred Hitchcock
actors: [James Stewart, Kim Novak, Barbara Bel Geddes, Tom Helmore, Henry Jones]
genre: [Mystery, Romance, Thriller]
length: "2h 8m"
shelf: watched
owned: false
rating: 
watched: 1958-05-28
poster: "https://image.tmdb.org/t/p/w500/15uOEfqBNTVtDUT7hGBVCka0rZz.jpg"
---

# Vertigo (1958)

![](https://image.tmdb.org/t/p/w500/15uOEfqBNTVtDUT7hGBVCka0rZz.jpg)

A retired San Francisco detective suffering from acrophobia investigates the strange activities of an old friend's wife, all the while becoming dangerously obsessed with her.