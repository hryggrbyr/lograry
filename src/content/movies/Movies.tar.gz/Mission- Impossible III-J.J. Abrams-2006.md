---
type: movie
country: US
title: "Mission: Impossible III"
year: 2006
director: J.J. Abrams
actors: [Tom Cruise, Philip Seymour Hoffman, Ving Rhames, Billy Crudup, Michelle Monaghan]
genre: [Adventure, Action, Thriller]
length: "2h 6m"
shelf: watched
owned: false
rating: 
watched: 2006-05-05
poster: "https://image.tmdb.org/t/p/w500/vKGYCpmQyV9uHybWDzXuII8Los5.jpg"
---

# Mission: Impossible III (2006)

![](https://image.tmdb.org/t/p/w500/vKGYCpmQyV9uHybWDzXuII8Los5.jpg)

Retired from active duty, and training recruits for the Impossible Mission Force, agent Ethan Hunt faces the toughest foe of his career: Owen Davian, an international broker of arms and information, who's as cunning as he is ruthless. Davian emerges to threaten Hunt and all that he holds dear – including the woman Hunt loves.