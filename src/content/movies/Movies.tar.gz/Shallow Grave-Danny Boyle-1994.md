---
type: movie
country: GB
title: "Shallow Grave"
year: 1994
director: Danny Boyle
actors: [Kerry Fox, Christopher Eccleston, Ewan McGregor, Ken Stott, Keith Allen]
genre: [Crime, Thriller]
length: "1h 33m"
shelf: watched
owned: false
rating: 
watched: 1995-01-06
poster: "https://image.tmdb.org/t/p/w500/gqvSKLbfIg1mja1ulVkVcLhdwWF.jpg"
---

# Shallow Grave (1994)

![](https://image.tmdb.org/t/p/w500/gqvSKLbfIg1mja1ulVkVcLhdwWF.jpg)

When David, Juliet, and Alex find their new roommate dead with a large sum of money, they agree to hide the body and keep the cash. However, this newfound fortune gradually corrodes their friendship.