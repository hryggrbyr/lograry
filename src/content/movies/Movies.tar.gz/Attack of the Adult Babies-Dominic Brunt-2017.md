---
type: movie
country: GB, US
title: "Attack of the Adult Babies"
year: 2017
director: Dominic Brunt
actors: [Andrew Dunn, Kate Coogan, Sally Dexter, Joanne Mitchell, Mica Proctor]
genre: [Horror, Comedy]
length: "1h 24m"
shelf: watched
owned: false
rating: 
watched: 2017-08-26
poster: "https://image.tmdb.org/t/p/w500/vg3EQp0ZvUNMXgSRrNynZMAsBmz.jpg"
---

# Attack of the Adult Babies (2017)

![](https://image.tmdb.org/t/p/w500/vg3EQp0ZvUNMXgSRrNynZMAsBmz.jpg)

A group of high-powered, middle-aged white men go to this place to take refuge from the stresses of their daily lives and spend time relaxing and regressing as “adult babies.” It’s set in a beautiful, secret location but this is not their only function. As adult babies, they are there to refuel the world’s economy by sinister and unusual means.