---
type: movie
country: US
title: "Trick 'r Treat"
year: 2007
director: Michael Dougherty
actors: [Brian Cox, Quinn Lord, Anna Paquin, Dylan Baker, Leslie Bibb]
genre: [Horror, Comedy]
length: "1h 22m"
shelf: watched
owned: false
rating: 
watched: 2007-12-09
poster: "https://image.tmdb.org/t/p/w500/w0nmol4g7n6MFfhfphV7GzHHYjB.jpg"
---

# Trick 'r Treat (2007)

![](https://image.tmdb.org/t/p/w500/w0nmol4g7n6MFfhfphV7GzHHYjB.jpg)

Four interwoven stories that occur on Halloween: an everyday high school principal has a secret life as a serial killer; a college virgin might have just met the one guy for her; a group of teenagers pull a mean prank, and a bitter old recluse receives an uninvited guest.