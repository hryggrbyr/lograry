---
type: movie
country: US
title: "Ghostbusters II"
year: 1989
director: Ivan Reitman
actors: [Bill Murray, Dan Aykroyd, Sigourney Weaver, Harold Ramis, Rick Moranis]
genre: [Comedy, Fantasy]
length: "1h 48m"
shelf: watched
owned: false
rating: 
watched: 1989-06-16
poster: "https://image.tmdb.org/t/p/w500/yObYPMA58DnTMvJooFW7GG6jWAt.jpg"
---

# Ghostbusters II (1989)

![](https://image.tmdb.org/t/p/w500/yObYPMA58DnTMvJooFW7GG6jWAt.jpg)

The discovery of a massive river of ectoplasm and a resurgence of spectral activity allows the staff of Ghostbusters to revive the business.