---
type: movie
country: FR
title: "Amélie"
year: 2001
director: Jean-Pierre Jeunet
actors: [Audrey Tautou, Mathieu Kassovitz, Rufus, Serge Merlin, Jamel Debbouze]
genre: [Comedy, Romance]
length: "2h 2m"
shelf: watched
owned: false
rating: 
watched: 2001-04-25
poster: "https://image.tmdb.org/t/p/w500/oTKduWL2tpIKEmkAqF4mFEAWAsv.jpg"
---

# Amélie (2001)

![](https://image.tmdb.org/t/p/w500/oTKduWL2tpIKEmkAqF4mFEAWAsv.jpg)

At a tiny Parisian café, the adorable yet painfully shy Amélie accidentally discovers a gift for helping others. Soon Amelie is spending her days as a matchmaker, guardian angel, and all-around do-gooder. But when she bumps into a handsome stranger, will she find the courage to become the star of her very own love story?