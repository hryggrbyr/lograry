---
type: movie
country: US
title: "Insidious"
year: 2011
director: James Wan
actors: [Patrick Wilson, Rose Byrne, Lin Shaye, Ty Simpkins, Barbara Hershey]
genre: [Horror, Thriller]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 2011-04-01
poster: "https://image.tmdb.org/t/p/w500/tmlDFIUpGRKiuWm9Ixc6CYDk4y0.jpg"
---

# Insidious (2011)

![](https://image.tmdb.org/t/p/w500/tmlDFIUpGRKiuWm9Ixc6CYDk4y0.jpg)

A family discovers that dark spirits have invaded their home after their son inexplicably falls into an endless sleep. When they reach out to a professional for help, they learn things are a lot more personal than they thought.