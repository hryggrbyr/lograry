---
type: movie
country: US
title: "Bird Box"
year: 2018
director: Susanne Bier
actors: [Sandra Bullock, Trevante Rhodes, John Malkovich, Sarah Paulson, Jacki Weaver]
genre: [Horror, Thriller, Drama]
length: "2h 4m"
shelf: watched
owned: false
rating: 
watched: 2018-12-21
poster: "https://image.tmdb.org/t/p/w500/rGfGfgL2pEPCfhIvqHXieXFn7gp.jpg"
---

# Bird Box (2018)

![](https://image.tmdb.org/t/p/w500/rGfGfgL2pEPCfhIvqHXieXFn7gp.jpg)

Five years after an ominous unseen presence drives most of society to suicide, a survivor and her two children make a desperate bid to reach safety.