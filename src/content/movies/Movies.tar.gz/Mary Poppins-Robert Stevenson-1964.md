---
type: movie
country: US
title: "Mary Poppins"
year: 1964
director: Robert Stevenson
actors: [Julie Andrews, Dick Van Dyke, David Tomlinson, Glynis Johns, Hermione Baddeley]
genre: [Comedy, Family, Fantasy]
length: "2h 19m"
shelf: watched
owned: true
rating: 
watched: 1965-08-18
poster: "https://image.tmdb.org/t/p/w500/ei8hhYCMfURfPOXKBnyl61be2iV.jpg"
---

# Mary Poppins (1964)

![](https://image.tmdb.org/t/p/w500/ei8hhYCMfURfPOXKBnyl61be2iV.jpg)

Mr Banks is looking for a nanny for his two mischievous children and comes across Mary Poppins, an angelic nanny. She not only brings a change in their lives but also spreads happiness.