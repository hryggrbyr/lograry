---
type: movie
country: Canada, Australia, United States
title: Candyman
year: 2021
director: Nia DaCosta
actors: [Yahya Abdul-Mateen II, Teyonah Parris, Nathan Stewart-Jarrett]
genre: [Horror, Thriller]
length: 91
shelf: watched
owned: false
rating: 
watched: 2021-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMzFjMTQwMGYtNjNmNC00NjMyLWJjNWYtOGRhMmVkNGY1N2U5XkEyXkFqcGc@._V1_SX300.jpg"
---

# Candyman (2021)

![](https://m.media-amazon.com/images/M/MV5BMzFjMTQwMGYtNjNmNC00NjMyLWJjNWYtOGRhMmVkNGY1N2U5XkEyXkFqcGc@._V1_SX300.jpg)

A sequel to the horror film Candyman (1992) that returns to the now-gentrified Chicago neighborhood where the legend began.