---
type: series
country: US
title: "Over the Garden Wall"
year: 2014
director: Unknown
actors: [Elijah Wood, Collin Dean, Melanie Lynskey]
genre: [Mystery, Sci-Fi & Fantasy, Animation, Family, Comedy]
length: "1 season (10 episodes)"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/m3lU8n7WxzMecxKZcqhq5y5ESy.jpg"
---

# Over the Garden Wall (2014)

![](https://image.tmdb.org/t/p/w500/m3lU8n7WxzMecxKZcqhq5y5ESy.jpg)

Two brothers, Wirt and Greg, find themselves lost in the Unknown; a strange forest adrift in time. With the help of a wise old Woodsman and a foul-tempered bluebird named Beatrice, Wirt and Greg must travel across this strange land, in hope of finding their way home. Join them as they encounter surprises and obstacles on their journey through the wood.
