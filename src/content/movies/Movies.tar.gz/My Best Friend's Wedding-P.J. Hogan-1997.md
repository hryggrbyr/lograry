---
type: movie
country: US
title: "My Best Friend's Wedding"
year: 1997
director: P.J. Hogan
actors: [Julia Roberts, Dermot Mulroney, Cameron Diaz, Rupert Everett, Philip Bosco]
genre: [Comedy, Romance]
length: "1h 45m"
shelf: watched
owned: false
rating: 
watched: 1997-06-19
poster: "https://image.tmdb.org/t/p/w500/b5g4bp8gS5ovMyR5439AII6zQ3n.jpg"
---

# My Best Friend's Wedding (1997)

![](https://image.tmdb.org/t/p/w500/b5g4bp8gS5ovMyR5439AII6zQ3n.jpg)

When she receives word that her longtime platonic pal Michael O'Neal is getting married to debutante Kimberly Wallace, food critic Julianne Potter realizes her true feelings for Michael -- and sets out to sabotage the wedding.