---
type: movie
country: US
title: "G.I. Jane"
year: 1997
director: Ridley Scott
actors: [Demi Moore, Viggo Mortensen, Morris Chestnut, Josh Hopkins, David Vadim]
genre: [Action, Drama]
length: "2h 5m"
shelf: watched
owned: false
rating: 
watched: 1997-08-22
poster: "https://image.tmdb.org/t/p/w500/6yBgZJYqaR4XkxwjsB9tS4GK1ZN.jpg"
---

# G.I. Jane (1997)

![](https://image.tmdb.org/t/p/w500/6yBgZJYqaR4XkxwjsB9tS4GK1ZN.jpg)

In response to political pressure from Senator Lillian DeHaven, the U.S. Navy begins a program that would allow for the eventual integration of women into its combat services. The program begins with a single trial candidate, Lieutenant Jordan O'Neil, who is chosen specifically for her femininity. O'Neil enters the grueling Navy SEAL training program under the command of Master Chief John James Urgayle, who unfairly pushes O'Neil until her determination wins his respect.