---
type: movie
country: US
title: "Until Dawn"
year: 2025
director: David F. Sandberg
actors: [Ella Rubin, Maia Mitchell, Peter Stormare, Michael Cimino, Odessa A'zion]
genre: [Horror, Mystery]
length: "1h 43m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/bLY5yN4MKVynZ2HMZWElTOGBgBe.jpg"
---

# Until Dawn (2025)

![](https://image.tmdb.org/t/p/w500/bLY5yN4MKVynZ2HMZWElTOGBgBe.jpg)

One year after her sister Melanie mysteriously disappeared, Clover and her friends head into the remote valley where she vanished in search of answers. Exploring an abandoned visitor center, they find themselves stalked by a masked killer and horrifically murdered one by one...only to wake up and find themselves back at the beginning of the same evening.
