---
type: movie
country: JP
title: "Howl's Moving Castle"
year: 2004
director: Hayao Miyazaki
actors: [Chieko Baisho, Takuya Kimura, Akihiro Miwa, Tatsuya Gashûin, Ryunosuke Kamiki]
genre: [Fantasy, Animation, Adventure]
length: "1h 59m"
shelf: watched
owned: false
rating: 
watched: 2004-11-19
poster: "https://image.tmdb.org/t/p/w500/TkTPELv4kC3u1lkloush8skOjE.jpg"
---

# Howl's Moving Castle (2004)

![](https://image.tmdb.org/t/p/w500/TkTPELv4kC3u1lkloush8skOjE.jpg)

Sophie, a young milliner, is turned into an elderly woman by a witch who enters her shop and curses her. She encounters a wizard named Howl and gets caught up in his resistance to fighting for the king.