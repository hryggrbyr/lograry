---
type: movie
country: GB
title: "Harry Potter and the Goblet of Fire"
year: 2005
director: Mike Newell
actors: [Daniel Radcliffe, Rupert Grint, Emma Watson, Brendan Gleeson, Michael Gambon]
genre: [Adventure, Fantasy]
length: "2h 37m"
shelf: watched
owned: false
rating: 
watched: 2023-07-14
poster: "https://image.tmdb.org/t/p/w500/fECBtHlr0RB3foNHDiCBXeg9Bv9.jpg"
---

# Harry Potter and the Goblet of Fire (2005)

![](https://image.tmdb.org/t/p/w500/fECBtHlr0RB3foNHDiCBXeg9Bv9.jpg)

When Harry Potter's name emerges from the Goblet of Fire, he becomes a competitor in a grueling battle for glory among three wizarding schools—the Triwizard Tournament. But since Harry never submitted his name for the Tournament, who did? Now Harry must confront a deadly dragon, fierce water demons and an enchanted maze only to find himself in the cruel grasp of He Who Must Not Be Named.