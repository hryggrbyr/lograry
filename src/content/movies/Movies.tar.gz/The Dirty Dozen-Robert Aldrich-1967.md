---
type: movie
country: US, GB
title: "The Dirty Dozen"
year: 1967
director: Robert Aldrich
actors: [Lee Marvin, Ernest Borgnine, Charles Bronson, Jim Brown, John Cassavetes]
genre: [Action, Adventure, War]
length: "2h 29m"
shelf: watched
owned: false
rating: 
watched: 1967-06-15
poster: "https://image.tmdb.org/t/p/w500/tFWWsuhp22zJ6OG6QepJIiPUfeF.jpg"
---

# The Dirty Dozen (1967)

![](https://image.tmdb.org/t/p/w500/tFWWsuhp22zJ6OG6QepJIiPUfeF.jpg)

12 American military prisoners in World War II are ordered to infiltrate a well-guarded enemy château and kill the Nazi officers vacationing there. The soldiers, most of whom are facing death sentences for a variety of violent crimes, agree to the mission and the possible commuting of their sentences.