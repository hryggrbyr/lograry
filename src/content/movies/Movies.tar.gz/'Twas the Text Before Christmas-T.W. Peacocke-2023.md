---
type: movie
country: CA, US
title: "'Twas the Text Before Christmas"
year: 2023
director: T.W. Peacocke
actors: [Merritt Patterson, Trevor Donovan, Rob Stewart, Jayne Eastwood, Marisa McIntyre]
genre: [Romance, Comedy, TV Movie, Christmas]
length: "1h 25m"
shelf: watched
owned: false
rating: 
watched: 2024-12-13
poster: "https://image.tmdb.org/t/p/w500/e1fvQdD63RP2MS9jCB8jzg7fkdr.jpg"
---

# 'Twas the Text Before Christmas (2023)

![](https://image.tmdb.org/t/p/w500/e1fvQdD63RP2MS9jCB8jzg7fkdr.jpg)

Addie is a New York City chiropractor mistakenly receives a text from “Nana.” The accidental text turns into a loving friendship between the matronly Nana and Addie who now communicate regularly. Nana invites Addie to spend the holiday in Vermont. It is picture-postcard perfect and exactly as Nana described except for one surprise. Nana’s single son, James, a traveling doctor is also home for the holidays. Over three consecutive years, James and Addie are together during the holidays, though it isn’t until they are both single that they begin to see each other in a different light.