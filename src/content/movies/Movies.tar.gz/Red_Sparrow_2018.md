---
type: movie
country: US
title: "Red Sparrow"
year: 2018
director: Francis Lawrence
actors: [Jennifer Lawrence, Joel Edgerton, Matthias Schoenaerts, Charlotte Rampling, Jeremy Irons]
genre: [Thriller, Mystery]
length: "2h 20m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/vLCogyfQGxVLDC1gqUdNAIkc29L.jpg"
---

# Red Sparrow (2018)

![](https://image.tmdb.org/t/p/w500/vLCogyfQGxVLDC1gqUdNAIkc29L.jpg)

Prima ballerina Dominika Egorova faces a bleak and uncertain future after she suffers an injury that ends her career. She soon turns to Sparrow School, a secret intelligence service that trains exceptional young people to use their minds and bodies as weapons. Dominika emerges as the most dangerous Sparrow after completing the sadistic training process. As she comes to terms with her new abilities, she meets a CIA agent who tries to convince her that he is the only person she can trust.
