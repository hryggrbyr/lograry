---
type: movie
country: GB
title: "Whistle Down the Wind"
year: 1961
director: Bryan Forbes
actors: [Hayley Mills, Bernard Lee, Alan Bates, Norman Bird, Diane Clare]
genre: [Crime, Drama]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 1990-05-08
poster: "https://image.tmdb.org/t/p/w500/2Q8wpOJCmhE9B03HoifIcvrPzXz.jpg"
---

# Whistle Down the Wind (1961)

![](https://image.tmdb.org/t/p/w500/2Q8wpOJCmhE9B03HoifIcvrPzXz.jpg)

When an injured wife-murderer takes refuge on a remote Lancashire farm, the farmer’s three children mistakenly believe him to be the Second Coming of Christ.