---
type: movie
country: NO
title: "22 July"
year: 2018
director: Paul Greengrass
actors: [Jonas Strand Gravli, Anders Danielsen Lie, Jon Øigarden, Seda Witt, Ola G. Furuseth]
genre: [Crime, Drama, History, Thriller]
length: "2h 23m"
shelf: watched
owned: false
rating: 
watched: 2018-10-10
poster: "https://image.tmdb.org/t/p/w500/rd940KzuIZwbdOvOUF7XDTzn8te.jpg"
---

# 22 July (2018)

![](https://image.tmdb.org/t/p/w500/rd940KzuIZwbdOvOUF7XDTzn8te.jpg)

On 22 July 2011, neo-Nazi terrorist Anders Behring Breivik murdered 77 young people attending a Labour Party Youth Camp on Utøya Island outside of Oslo. This three-part story focuses on the survivors, the political leadership of Norway, and the lawyers involved.