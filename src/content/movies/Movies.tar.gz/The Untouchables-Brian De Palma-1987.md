---
type: movie
country: US
title: "The Untouchables"
year: 1987
director: Brian De Palma
actors: [Kevin Costner, Sean Connery, Robert De Niro, Charles Martin Smith, Andy García]
genre: [Crime, History, Thriller]
length: "1h 59m"
shelf: watched
owned: false
rating: 
watched: 1987-06-03
poster: "https://image.tmdb.org/t/p/w500/8BquGK22zCcsmBWiaIakaaPpSZb.jpg"
---

# The Untouchables (1987)

![](https://image.tmdb.org/t/p/w500/8BquGK22zCcsmBWiaIakaaPpSZb.jpg)

Elliot Ness, an ambitious prohibition agent, is determined to take down Al Capone. In order to achieve this goal, he forms a group given the nickname “The Untouchables”.