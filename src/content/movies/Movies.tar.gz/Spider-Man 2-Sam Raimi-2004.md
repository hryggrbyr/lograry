---
type: movie
country: US
title: "Spider-Man 2"
year: 2004
director: Sam Raimi
actors: [Tobey Maguire, Kirsten Dunst, James Franco, Alfred Molina, Rosemary Harris]
genre: [Action, Adventure, Science Fiction]
length: "2h 7m"
shelf: watched
owned: false
rating: 
watched: 2004-06-30
poster: "https://image.tmdb.org/t/p/w500/aGuvNAaaZuWXYQQ6N2v7DeuP6mB.jpg"
---

# Spider-Man 2 (2004)

![](https://image.tmdb.org/t/p/w500/aGuvNAaaZuWXYQQ6N2v7DeuP6mB.jpg)

Peter Parker is going through a major identity crisis. Burned out from being Spider-Man, he decides to shelve his superhero alter ego, which leaves the city suffering in the wake of carnage left by the evil Doc Ock. In the meantime, Parker still can't act on his feelings for Mary Jane Watson, a girl he's loved since childhood. A certain anger begins to brew in his best friend Harry Osborn as well...