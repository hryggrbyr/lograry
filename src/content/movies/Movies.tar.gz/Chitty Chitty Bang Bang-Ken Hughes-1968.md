---
type: movie
country: US, GB
title: "Chitty Chitty Bang Bang"
year: 1968
director: Ken Hughes
actors: [Dick Van Dyke, Sally Ann Howes, Lionel Jeffries, Gert Fröbe, Anna Quayle]
genre: [Family, Music, Adventure, Fantasy, Comedy]
length: "2h 24m"
shelf: watched
owned: false
rating: 
watched: 1968-12-17
poster: "https://image.tmdb.org/t/p/w500/wJ62FzGeCAs6PjCIK1as6xzdIY5.jpg"
---

# Chitty Chitty Bang Bang (1968)

![](https://image.tmdb.org/t/p/w500/wJ62FzGeCAs6PjCIK1as6xzdIY5.jpg)

A hapless inventor finally finds success with a flying car, which a dictator from a foreign government sets out to take for himself.