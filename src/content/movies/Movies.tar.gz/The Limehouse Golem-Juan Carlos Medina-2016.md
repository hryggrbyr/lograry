---
type: movie
country: GB
title: "The Limehouse Golem"
year: 2016
director: Juan Carlos Medina
actors: [Bill Nighy, Olivia Cooke, Douglas Booth, Daniel Mays, Sam Reid]
genre: [Horror, Mystery, Thriller]
length: "1h 49m"
shelf: watched
owned: false
rating: 
watched: 2017-09-01
poster: "https://image.tmdb.org/t/p/w500/u9NnEq4Be7hhwSvkNf6dOAD8ppi.jpg"
---

# The Limehouse Golem (2016)

![](https://image.tmdb.org/t/p/w500/u9NnEq4Be7hhwSvkNf6dOAD8ppi.jpg)

A series of murders has shaken the community to the point where people believe that only a legendary creature from dark times – the mythical Golem – must be responsible.