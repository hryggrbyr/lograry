---
type: movie
country: United States
title: "Mission Impossible"
year: 1996
director: Brian De Palma
actors: [Tom Cruise, Jon Voight, Emmanuelle Béart]
genre: [Action, Adventure, Thriller]
length: 110
shelf: watched
owned: false
rating: 
watched: 1996-12-31
poster: "https://m.media-amazon.com/images/M/MV5BOGZjNDlkMTYtMTJkZi00OTkzLWI4NDEtYTA2ODQyMjcwYTdlXkEyXkFqcGc@._V1_SX300.jpg"
---

# Mission Impossible (1996)

![](https://m.media-amazon.com/images/M/MV5BOGZjNDlkMTYtMTJkZi00OTkzLWI4NDEtYTA2ODQyMjcwYTdlXkEyXkFqcGc@._V1_SX300.jpg)

An American agent, under false suspicion of disloyalty, must discover and expose the real spy without the help of his organization.