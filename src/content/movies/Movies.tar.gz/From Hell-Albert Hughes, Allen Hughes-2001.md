---
type: movie
country: US
title: "From Hell"
year: 2001
director: Albert Hughes, Allen Hughes
actors: [Johnny Depp, Heather Graham, Ian Holm, Robbie Coltrane, Ian Richardson]
genre: [Horror, Mystery, Thriller]
length: "2h 2m"
shelf: watched
owned: false
rating: 
watched: 2001-10-19
poster: "https://image.tmdb.org/t/p/w500/t2WpWM8nBO4sULXr2bDfNEt4qgr.jpg"
---

# From Hell (2001)

![](https://image.tmdb.org/t/p/w500/t2WpWM8nBO4sULXr2bDfNEt4qgr.jpg)

Frederick Abberline is an opium-huffing inspector from Scotland Yard who falls for one of Jack the Ripper's prostitute targets in this Hughes brothers adaption of a graphic novel that posits the Ripper's true identity.