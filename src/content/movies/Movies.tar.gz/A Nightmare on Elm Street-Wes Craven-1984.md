---
type: movie
country: US
title: "A Nightmare on Elm Street"
year: 1984
director: Wes Craven
actors: [Heather Langenkamp, Robert Englund, Johnny Depp, John Saxon, Ronee Blakley]
genre: [Horror]
length: "1h 31m"
shelf: watched
owned: false
rating: 
watched: 1984-11-09
poster: "https://image.tmdb.org/t/p/w500/wGTpGGRMZmyFCcrY2YoxVTIBlli.jpg"
---

# A Nightmare on Elm Street (1984)

![](https://image.tmdb.org/t/p/w500/wGTpGGRMZmyFCcrY2YoxVTIBlli.jpg)

Teenagers in a small town are dropping like flies, apparently in the grip of mass hysteria causing their suicides. A cop's daughter, Nancy Thompson, traces the cause to child molester Fred Krueger, who was burned alive by angry parents many years before. Krueger has now come back in the dreams of his killers' children, claiming their lives as his revenge. Nancy and her boyfriend, Glen, must devise a plan to lure the monster out of the realm of nightmares and into the real world...