---
type: movie
country: GB
title: "Jackdaw"
year: 2024
director: Jamie Childs
actors: [Oliver Jackson-Cohen, Jenna Coleman, Thomas Turgoose, Joe Blakemore, Rory McCann]
genre: [Action, Drama, Crime, Thriller]
length: "1h 37m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/m3OwT2vQ468E6b05pNCcCKY0Q7u.jpg"
---

# Jackdaw (2024)

![](https://image.tmdb.org/t/p/w500/m3OwT2vQ468E6b05pNCcCKY0Q7u.jpg)

A former motocross champion and army veteran, now caring for his younger brother. Broke, he agrees to do an open water pick up of a mysterious illegal package in the North Sea. A resulting double cross and his brother’s disappearance set him and his old bike on a violent nocturnal odyssey through England’s northern rust belt.
