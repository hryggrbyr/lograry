---
type: movie
country: United States
title: "Pitch Black"
year: 2000
director: David Twohy
actors: [Radha Mitchell, Cole Hauser, Vin Diesel]
genre: [Horror, Sci-Fi, Thriller]
length: 109
shelf: watched
owned: true
rating: 
watched: 2000-12-31
poster: "https://m.media-amazon.com/images/M/MV5BNGJlYjllOTUtZGRiNS00YmI4LTkxYmItYjBmYTdmZWZlMTMxXkEyXkFqcGc@._V1_SX300.jpg"
---

# Pitch Black (2000)

![](https://m.media-amazon.com/images/M/MV5BNGJlYjllOTUtZGRiNS00YmI4LTkxYmItYjBmYTdmZWZlMTMxXkEyXkFqcGc@._V1_SX300.jpg)

A transport ship crashes and leaves its crew stranded on a desert planet inhabited by bloodthirsty creatures that come out during an eclipse.