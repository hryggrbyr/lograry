---
type: movie
country: FR
title: "The Fifth Element"
year: 1997
director: Luc Besson
actors: [Bruce Willis, Milla Jovovich, Gary Oldman, Ian Holm, Chris Tucker]
genre: [Science Fiction, Action, Adventure]
length: "2h 6m"
shelf: watched
owned: true
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/fPtlCO1yQtnoLHOwKtWz7db6RGU.jpg"
---

# The Fifth Element (1997)

![](https://image.tmdb.org/t/p/w500/fPtlCO1yQtnoLHOwKtWz7db6RGU.jpg)

In 2257, a taxi driver is unintentionally given the task of saving a young girl who is part of the key that will ensure the survival of humanity.