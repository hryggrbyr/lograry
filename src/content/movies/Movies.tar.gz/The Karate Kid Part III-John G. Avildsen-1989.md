---
type: movie
country: US
title: "The Karate Kid Part III"
year: 1989
director: John G. Avildsen
actors: [Ralph Macchio, Pat Morita, Robyn Lively, Thomas Ian Griffith, Martin Kove]
genre: [Action, Family, Drama, Adventure]
length: "1h 52m"
shelf: watched
owned: false
rating: 
watched: 1989-06-29
poster: "https://image.tmdb.org/t/p/w500/lVZ3r0iDwGejlCvFEvXGzhQB9ds.jpg"
---

# The Karate Kid Part III (1989)

![](https://image.tmdb.org/t/p/w500/lVZ3r0iDwGejlCvFEvXGzhQB9ds.jpg)

Despondent over the closing of his karate school, Cobra Kai teacher John Kreese joins a ruthless businessman and martial artist to get revenge on Daniel and Mr. Miyagi.