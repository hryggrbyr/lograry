---
type: movie
country: GB
title: "Christmas on Mistletoe Farm"
year: 2022
director: Debbie Isitt
actors: [Scott Garnham, Kathryn Drysdale, Scott Paige, Sydney Isitt-Ager, Ashley Jensen]
genre: [Family, Comedy, Christmas]
length: "1h 44m"
shelf: watched
owned: false
rating: 
watched: 2023-11-26
poster: "https://image.tmdb.org/t/p/w500/rGCwI76dylPViDF9VXFY0ORRhls.jpg"
---

# Christmas on Mistletoe Farm (2022)

![](https://image.tmdb.org/t/p/w500/rGCwI76dylPViDF9VXFY0ORRhls.jpg)

After inheriting a farm at Christmas time, a widowed father makes a bumpy adjustment to village life — while his kids hatch a plan to stay there forever.