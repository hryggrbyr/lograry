---
type: movie
country: N/A
title: CBeebies Musical The Great Ice Cream Hunt
year: 2025
director: N/A
actors: [N/A]
genre: [N/A]
length: N/A
shelf: watched
owned: false
rating: 5
watched: 2025-08-29
poster: "N/A"
---

# CBeebies Musical The Great Ice Cream Hunt (2025)

![](N/A)

N/A