---
type: movie
country: US
title: "Catch Me If You Can"
year: 2002
director: Steven Spielberg
actors: [Leonardo DiCaprio, Tom Hanks, Christopher Walken, Martin Sheen, Nathalie Baye]
genre: [Drama, Crime]
length: "2h 21m"
shelf: watched
owned: false
rating: 
watched: 2002-12-25
poster: "https://image.tmdb.org/t/p/w500/ctjEj2xM32OvBXCq8zAdK3ZrsAj.jpg"
---

# Catch Me If You Can (2002)

![](https://image.tmdb.org/t/p/w500/ctjEj2xM32OvBXCq8zAdK3ZrsAj.jpg)

A true story about Frank Abagnale Jr. who, before his 19th birthday, successfully conned millions of dollars worth of checks as a Pan Am pilot, doctor, and legal prosecutor. An FBI agent makes it his mission to put him behind bars. But Frank not only eludes capture, he revels in the pursuit.