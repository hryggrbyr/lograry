---
type: movie
country: US
title: "Indiana Jones and the Temple of Doom"
year: 1984
director: Steven Spielberg
actors: [Harrison Ford, Kate Capshaw, Ke Huy Quan, Amrish Puri, Roshan Seth]
genre: [Adventure, Action]
length: "1h 58m"
shelf: watched
owned: false
rating: 
watched: 1984-05-23
poster: "https://image.tmdb.org/t/p/w500/gpdVNUaa4LhRMLfJOPj1AZdhAZ3.jpg"
---

# Indiana Jones and the Temple of Doom (1984)

![](https://image.tmdb.org/t/p/w500/gpdVNUaa4LhRMLfJOPj1AZdhAZ3.jpg)

After arriving in India, Indiana Jones is asked by a desperate village to find a mystical stone. He agrees – and stumbles upon a secret cult plotting a terrible plan in the catacombs of an ancient palace.