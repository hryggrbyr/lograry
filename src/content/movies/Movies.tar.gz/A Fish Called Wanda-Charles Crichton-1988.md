---
type: movie
country: GB, US
title: "A Fish Called Wanda"
year: 1988
director: Charles Crichton
actors: [Jamie Lee Curtis, John Cleese, Kevin Kline, Michael Palin, Maria Aitken]
genre: [Comedy, Crime]
length: "1h 49m"
shelf: watched
owned: false
rating: 
watched: 1988-07-15
poster: "https://image.tmdb.org/t/p/w500/hkSGFNVfEEUXFCxRZDITFHVhUlu.jpg"
---

# A Fish Called Wanda (1988)

![](https://image.tmdb.org/t/p/w500/hkSGFNVfEEUXFCxRZDITFHVhUlu.jpg)

While a diamond advocate attempts to steal a collection of diamonds, troubles arise when he realises he’s not the only one after the collection.