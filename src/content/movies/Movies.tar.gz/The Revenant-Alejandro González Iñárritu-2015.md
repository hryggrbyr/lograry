---
type: movie
country: US
title: "The Revenant"
year: 2015
director: Alejandro González Iñárritu
actors: [Leonardo DiCaprio, Tom Hardy, Domhnall Gleeson, Will Poulter, Forrest Goodluck]
genre: [Western, Drama, Adventure]
length: "2h 37m"
shelf: watched
owned: false
rating: 
watched: 2015-12-25
poster: "https://image.tmdb.org/t/p/w500/ji3ecJphATlVgWNY0B0RVXZizdf.jpg"
---

# The Revenant (2015)

![](https://image.tmdb.org/t/p/w500/ji3ecJphATlVgWNY0B0RVXZizdf.jpg)

In the 1820s, a frontiersman, Hugh Glass, sets out on a path of vengeance against those who left him for dead after a bear mauling.