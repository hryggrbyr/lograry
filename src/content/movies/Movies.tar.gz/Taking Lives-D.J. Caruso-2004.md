---
type: movie
country: US
title: "Taking Lives"
year: 2004
director: D.J. Caruso
actors: [Angelina Jolie, Ethan Hawke, Kiefer Sutherland, Gena Rowlands, Olivier Martinez]
genre: [Thriller]
length: "1h 43m"
shelf: watched
owned: false
rating: 
watched: 2004-03-19
poster: "https://image.tmdb.org/t/p/w500/1JEt0qtEaYrJZuPeTArR691V256.jpg"
---

# Taking Lives (2004)

![](https://image.tmdb.org/t/p/w500/1JEt0qtEaYrJZuPeTArR691V256.jpg)

Recruited to assist Montreal police in their desperate search for a serial killer who assumes the identities of his victims, FBI profiler Illeana Scott knows it's only a matter of time before the killer strikes again. Her most promising lead is a museum employee who might be the killer's only eyewitness.