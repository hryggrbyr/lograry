---
type: movie
country: US
title: "The Little Mermaid"
year: 1989
director: Ron Clements, John Musker
actors: [Jodi Benson, Samuel E. Wright, Pat Carroll, Christopher Daniel Barnes, Kenneth Mars]
genre: [Animation, Family, Fantasy]
length: "1h 23m"
shelf: watched
owned: false
rating: 
watched: 1989-11-17
poster: "https://image.tmdb.org/t/p/w500/plcZXvI310FkbwIptvd6rqk63LP.jpg"
---

# The Little Mermaid (1989)

![](https://image.tmdb.org/t/p/w500/plcZXvI310FkbwIptvd6rqk63LP.jpg)

This colorful adventure tells the story of an impetuous mermaid princess named Ariel who falls in love with the very human Prince Eric and puts everything on the line for the chance to be with him. Memorable songs and characters -- including the villainous sea witch Ursula.