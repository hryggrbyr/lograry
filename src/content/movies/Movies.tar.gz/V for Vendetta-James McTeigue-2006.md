---
type: movie
country: US
title: "V for Vendetta"
year: 2006
director: James McTeigue
actors: [Natalie Portman, Hugo Weaving, Stephen Rea, Stephen Fry, John Hurt,  Rupert Graves]
genre: [Action, Thriller, Drama, Science Fiction]
length: "2h 12m"
shelf: watched
owned: true
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/1avD1JeaRiJX5M4ahPdZPypGoGN.jpg"
---

# V for Vendetta (2006)

![](https://image.tmdb.org/t/p/w500/1avD1JeaRiJX5M4ahPdZPypGoGN.jpg)

In a world in which Great Britain has become a fascist state, a masked vigilante known only as “V” conducts guerrilla warfare against the oppressive British government. When V rescues a young woman from the secret police, he finds in her an ally with whom he can continue his fight to free the people of Britain.