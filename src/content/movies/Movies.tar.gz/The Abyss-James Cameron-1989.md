---
type: movie
country: US
title: "The Abyss"
year: 1989
director: James Cameron
actors: [Ed Harris, Mary Elizabeth Mastrantonio, Michael Biehn, Leo Burmester, Todd Graff]
genre: [Adventure, Thriller, Science Fiction]
length: "2h 20m"
shelf: watched
owned: false
rating: 
watched: 1989-08-09
poster: "https://image.tmdb.org/t/p/w500/2dCit3XAtv9KWCJvRKdPkJ0FAkH.jpg"
---

# The Abyss (1989)

![](https://image.tmdb.org/t/p/w500/2dCit3XAtv9KWCJvRKdPkJ0FAkH.jpg)

A civilian oil rig crew is recruited to conduct a search and rescue effort when a nuclear submarine mysteriously sinks. One diver soon finds himself on a spectacular odyssey 25,000 feet below the ocean's surface where he confronts a mysterious force that has the power to change the world or destroy it.