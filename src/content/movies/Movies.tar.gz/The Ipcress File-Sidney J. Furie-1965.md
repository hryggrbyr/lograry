---
type: movie
country: GB
title: "The Ipcress File"
year: 1965
director: Sidney J. Furie
actors: [Michael Caine, Nigel Green, Guy Doleman, Sue Lloyd, Gordon Jackson]
genre: [Thriller]
length: "1h 49m"
shelf: watched
owned: false
rating: 
watched: 1965-03-18
poster: "https://image.tmdb.org/t/p/w500/iCNRK7NVhBvNpiyMRmCpTBFNoLO.jpg"
---

# The Ipcress File (1965)

![](https://image.tmdb.org/t/p/w500/iCNRK7NVhBvNpiyMRmCpTBFNoLO.jpg)

Sly and dry intelligence agent Harry Palmer is tasked with investigating British Intelligence security, and is soon enmeshed in a world of double-dealing, kidnap and murder when he finds a traitor operating at the heart of the secret service.