---
type: movie
country: US
title: "Deck the Halls"
year: 2006
director: John Whitesell
actors: [Danny DeVito, Matthew Broderick, Kristin Davis, Kristin Chenoweth, Alia Shawkat]
genre: [Comedy, Family, Christmas]
length: "1h 33m"
shelf: watched
owned: false
rating: 
watched: 2024-12-25
poster: "https://image.tmdb.org/t/p/w500/smJDzhYGhl6j9OrucsB7IkMNy82.jpg"
---

# Deck the Halls (2006)

![](https://image.tmdb.org/t/p/w500/smJDzhYGhl6j9OrucsB7IkMNy82.jpg)

Determined to unseat Steve Finch's reign as the town's holiday season king, Buddy Hall plasters his house with so many decorative lights that it'll be visible from space! When their wives bond, and their kids follow suit, the two men only escalate their rivalry - and their decorating.