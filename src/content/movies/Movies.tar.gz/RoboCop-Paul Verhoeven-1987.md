---
type: movie
country: US
title: "RoboCop"
year: 1987
director: Paul Verhoeven
actors: [Peter Weller, Nancy Allen, Dan O'Herlihy, Ronny Cox, Kurtwood Smith]
genre: [Action, Thriller, Science Fiction]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 1987-07-17
poster: "https://image.tmdb.org/t/p/w500/esmAU0fCO28FbS6bUBKLAzJrohZ.jpg"
---

# RoboCop (1987)

![](https://image.tmdb.org/t/p/w500/esmAU0fCO28FbS6bUBKLAzJrohZ.jpg)

In a violent, near-apocalyptic Detroit, evil corporation Omni Consumer Products wins a contract from the city government to privatize the police force. To test their crime-eradicating cyborgs, the company leads street cop Alex Murphy into an armed confrontation with crime lord Boddicker so they can use his body to support their untested RoboCop prototype. But when RoboCop learns of the company's nefarious plans, he turns on his masters.