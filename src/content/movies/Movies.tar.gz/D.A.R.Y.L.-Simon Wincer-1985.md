---
type: movie
country: GB, US
title: "D.A.R.Y.L."
year: 1985
director: Simon Wincer
actors: [Barret Oliver, Mary Beth Hurt, Michael McKean, Kathryn Walker, Colleen Camp]
genre: [Family, Science Fiction, Action]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 1985-06-14
poster: "https://image.tmdb.org/t/p/w500/87huhTOQijJy0pLhusZfest1MoZ.jpg"
---

# D.A.R.Y.L. (1985)

![](https://image.tmdb.org/t/p/w500/87huhTOQijJy0pLhusZfest1MoZ.jpg)

Daryl is a normal 10-year-old boy in many ways. However, unbeknown to his foster parents and friends, Daryl is actually a government-created robot with superhuman reflexes and mental abilities. Even his name has a hidden meaning -- it's actually an acronym for Data Analyzing Robot Youth Life-form. When the organization that created him deems the "super soldier" experiment a failure and schedules Daryl to be disassembled, it is up to a few rogue scientists to help him escape.