---
type: movie
country: US
title: "Constantine"
year: 2005
director: Francis Lawrence
actors: [Keanu Reeves, Rachel Weisz, Shia LaBeouf, Djimon Hounsou, Max Baker]
genre: [Fantasy, Action, Horror]
length: "2h 1m"
shelf: watched
owned: false
rating: 
watched: 2005-02-18
poster: "https://image.tmdb.org/t/p/w500/vPYgvd2MwHlxTamAOjwVQp4qs1W.jpg"
---

# Constantine (2005)

![](https://image.tmdb.org/t/p/w500/vPYgvd2MwHlxTamAOjwVQp4qs1W.jpg)

John Constantine has literally been to Hell and back. When he teams up with a policewoman to solve the mysterious suicide of her twin sister, their investigation takes them through the world of demons and angels that exists beneath the landscape of contemporary Los Angeles.