---
type: movie
country: MX, ES
title: "Pan's Labyrinth"
year: 2006
director: Guillermo del Toro
actors: [Ivana Baquero, Sergi López, Maribel Verdú, Ariadna Gil, Doug Jones]
genre: [Fantasy, Drama, War]
length: "1h 58m"
shelf: watched
owned: false
rating: 
watched: 2006-12-29
poster: "https://image.tmdb.org/t/p/w500/s8C4whhKtDaJvMDcyiMvx3BIF5F.jpg"
---

# Pan's Labyrinth (2006)

![](https://image.tmdb.org/t/p/w500/s8C4whhKtDaJvMDcyiMvx3BIF5F.jpg)

In post–civil war Spain, 10-year-old Ofelia moves with her pregnant mother to live under the control of her cruel stepfather. Drawn into a mysterious labyrinth, she meets a faun who reveals that she may be a lost princess from an underground kingdom. To return to her true father, she must complete a series of surreal and perilous tasks that blur the line between reality and fantasy.