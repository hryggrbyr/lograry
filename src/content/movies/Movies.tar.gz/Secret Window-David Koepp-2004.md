---
type: movie
country: US
title: "Secret Window"
year: 2004
director: David Koepp
actors: [Johnny Depp, John Turturro, Maria Bello, Timothy Hutton, Charles S. Dutton]
genre: [Mystery, Thriller]
length: "1h 36m"
shelf: watched
owned: false
rating: 
watched: 2004-03-12
poster: "https://image.tmdb.org/t/p/w500/hvzw4wufKZkDCTPVeG71Z7pGfZh.jpg"
---

# Secret Window (2004)

![](https://image.tmdb.org/t/p/w500/hvzw4wufKZkDCTPVeG71Z7pGfZh.jpg)

Mort Rainey, a writer just emerging from a painful divorce with his ex-wife, is stalked at his remote lake house by a psychotic stranger and would-be scribe who claims Rainey swiped his best story idea. But as Rainey endeavors to prove his innocence, he begins to question his own sanity.