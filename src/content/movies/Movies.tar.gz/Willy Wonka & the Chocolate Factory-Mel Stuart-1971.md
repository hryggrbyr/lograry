---
type: movie
country: US
title: "Willy Wonka & the Chocolate Factory"
year: 1971
director: Mel Stuart
actors: [Gene Wilder, Peter Ostrum, Jack Albertson, Paris Themmen, Nora Denney]
genre: [Family, Fantasy, Comedy]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 1971-06-30
poster: "https://image.tmdb.org/t/p/w500/vmpsZkrs4Uvkp9r1atL8B3frA63.jpg"
---

# Willy Wonka & the Chocolate Factory (1971)

![](https://image.tmdb.org/t/p/w500/vmpsZkrs4Uvkp9r1atL8B3frA63.jpg)

When eccentric candy man Willy Wonka promises a lifetime supply of sweets and a tour of his chocolate factory to five lucky kids, penniless Charlie Bucket seeks the golden ticket that will make him a winner.