---
type: movie
country: Japan
title: "The Secret World of Arrietty"
year: 2010
director: Hiromasa Yonebayashi
actors: [Bridgit Mendler, Amy Poehler, Will Arnett]
genre: [Animation, Adventure, Drama]
length: 94
shelf: watched
owned: false
rating: 4
watched: 2025-10-15
poster: "https://m.media-amazon.com/images/M/MV5BMTAxNjk3OTYyODReQTJeQWpwZ15BbWU3MDgyODY2OTY@._V1_SX300.jpg"
---

# The Secret World of Arrietty (2010)

![](https://m.media-amazon.com/images/M/MV5BMTAxNjk3OTYyODReQTJeQWpwZ15BbWU3MDgyODY2OTY@._V1_SX300.jpg)

The Clock family are four-inch-tall people who live anonymously in another family's residence, borrowing simple items to make their home. Life changes for the Clocks when their teenage daughter Arrietty is discovered.