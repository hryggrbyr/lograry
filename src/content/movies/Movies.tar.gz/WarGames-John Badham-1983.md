---
type: movie
country: US
title: "WarGames"
year: 1983
director: John Badham
actors: [Matthew Broderick, Dabney Coleman, John Wood, Ally Sheedy, Barry Corbin]
genre: [Thriller, Science Fiction, Drama]
length: "1h 54m"
shelf: watched
owned: false
rating: 
watched: 1983-06-03
poster: "https://image.tmdb.org/t/p/w500/zZ1rN4LoPxKNfAp67Xl300WxVeD.jpg"
---

# WarGames (1983)

![](https://image.tmdb.org/t/p/w500/zZ1rN4LoPxKNfAp67Xl300WxVeD.jpg)

High school student David Lightman has a talent for hacking. But while trying to hack into a computer system to play unreleased video games, he unwittingly taps into the Department of Defense's war computer and initiates a confrontation of global proportions. Together with his friend and a wizardly computer genius, David must race against time to outwit his opponent and prevent a nuclear Armageddon.