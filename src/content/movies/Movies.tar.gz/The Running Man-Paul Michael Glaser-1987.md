---
type: movie
country: US
title: "The Running Man"
year: 1987
director: Paul Michael Glaser
actors: [Arnold Schwarzenegger, Richard Dawson, María Conchita Alonso, Yaphet Kotto, Jim Brown]
genre: [Action, Thriller, Science Fiction]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 1987-11-13
poster: "https://image.tmdb.org/t/p/w500/GTAUOhO4BN0peJVvxGEQydJvUO.jpg"
---

# The Running Man (1987)

![](https://image.tmdb.org/t/p/w500/GTAUOhO4BN0peJVvxGEQydJvUO.jpg)

By 2017, the global economy has collapsed and U.S. society has become a totalitarian police state, censoring all cultural activity. The government pacifies the populace by broadcasting a number of game shows in which convicted criminals fight for their lives, including the gladiator-style The Running Man, hosted by the ruthless Damon Killian, where “runners” attempt to evade “stalkers” and certain death for a chance to be pardoned and set free.