---
type: movie
country: GB, US
title: "Velvet Goldmine"
year: 1998
director: Todd Haynes
actors: [Ewan McGregor, Jonathan Rhys Meyers, Toni Collette, Christian Bale, Eddie Izzard]
genre: [Drama, Music]
length: "2h 3m"
shelf: watched
owned: false
rating: 
watched: 1998-10-26
poster: "https://image.tmdb.org/t/p/w500/bsuSac0PldPFcOtR1Vioe7VBF4l.jpg"
---

# Velvet Goldmine (1998)

![](https://image.tmdb.org/t/p/w500/bsuSac0PldPFcOtR1Vioe7VBF4l.jpg)

Almost a decade since larger-than-life glam-rock enigma Brian Slade disappeared from public eye, an investigative journalist is on assignment to uncover the truth behind his former idol.