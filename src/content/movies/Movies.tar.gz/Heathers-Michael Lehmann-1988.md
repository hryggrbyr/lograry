---
type: movie
country: US
title: "Heathers"
year: 1988
director: Michael Lehmann
actors: [Winona Ryder, Christian Slater, Shannen Doherty, Lisanne Falk, Kim Walker]
genre: [Comedy, Crime]
length: "1h 43m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/dGbVfM4WlM7uvIbyRehfPZUIgp2.jpg"
---

# Heathers (1988)

![](https://image.tmdb.org/t/p/w500/dGbVfM4WlM7uvIbyRehfPZUIgp2.jpg)

A girl who halfheartedly tries to be part of the "in crowd" of her school meets a rebel who teaches her a more devious way to play social politics: by killing the popular kids.