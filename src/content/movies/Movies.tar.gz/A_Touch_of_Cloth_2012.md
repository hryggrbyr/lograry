---
type: series
country: GB
title: "A Touch of Cloth"
year: 2012
director: Unknown
actors: [John Hannah, Suranne Jones, Julian Rhind-Tutt, Adrian Bower, Navin Chowdhry]
genre: [Comedy, Crime]
length: "3 seasons (6 episodes)"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/nMSkzU1yWltiqY1cqMgJDWFmWkc.jpg"
---

# A Touch of Cloth (2012)

![](https://image.tmdb.org/t/p/w500/nMSkzU1yWltiqY1cqMgJDWFmWkc.jpg)

Hannah plays DI Jack Cloth, who is called in to investigate an apparent series of serial killings alongside his new partner, DC Anne Oldman, described as a "plucky, no-nonsense sidekick". Playing with the cliches and conventions of British police dramas, subplots include Cloth dealing with visions of his dead wife and the bisexual DC Oldman coming to grips with her feelings for both her female fiancee and Cloth.
