---
type: movie
country: US
title: "Groundhog Day"
year: 1993
director: Harold Ramis
actors: [Bill Murray, Andie MacDowell, Chris Elliott, Stephen Tobolowsky, Brian Doyle-Murray]
genre: [Romance, Fantasy, Drama, Comedy]
length: "1h 41m"
shelf: watched
owned: false
rating: 
watched: 1993-02-11
poster: "https://image.tmdb.org/t/p/w500/gCgt1WARPZaXnq523ySQEUKinCs.jpg"
---

# Groundhog Day (1993)

![](https://image.tmdb.org/t/p/w500/gCgt1WARPZaXnq523ySQEUKinCs.jpg)

A narcissistic TV weatherman, along with his attractive-but-distant producer, and his mawkish cameraman, is sent to report on Groundhog Day in the small town of Punxsutawney, where he finds himself repeating the same day over and over.