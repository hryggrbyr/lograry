---
type: movie
country: GB
title: "A Close Shave"
year: 1996
director: Nick Park
actors: [Peter Sallis, Anne Reid]
genre: [Family, Animation, Comedy]
length: "30m"
shelf: watched
owned: false
rating: 
watched: 2024-01-01
poster: "https://image.tmdb.org/t/p/w500/qdIR27trLyrlJ5nmkbcG3Bomah6.jpg"
---

# A Close Shave (1996)

![](https://image.tmdb.org/t/p/w500/qdIR27trLyrlJ5nmkbcG3Bomah6.jpg)

Wallace's whirlwind romance with the proprietor of the local wool shop puts his head in a spin, and Gromit is framed for sheep-rustling in a fiendish criminal plot.