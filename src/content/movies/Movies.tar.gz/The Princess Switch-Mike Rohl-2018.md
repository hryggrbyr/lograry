---
type: movie
country: US
title: "The Princess Switch"
year: 2018
director: Mike Rohl
actors: [Vanessa Hudgens, Sam Palladio, Nick Sagar, Alexa Adeosun, Suanne Braun]
genre: [Romance, Comedy]
length: "1h 41m"
shelf: watched
owned: false
rating: 
watched: 2023-12-08
poster: "https://image.tmdb.org/t/p/w500/yDQftfpTEppAvdgLDDil56W1VWS.jpg"
---

# The Princess Switch (2018)

![](https://image.tmdb.org/t/p/w500/yDQftfpTEppAvdgLDDil56W1VWS.jpg)

When a down-to-earth Chicago baker and a soon-to-be princess discover they look like twins, they hatch a Christmastime plan to trade places.