---
type: movie
country: US
title: "Aladdin"
year: 1992
director: Ron Clements, John Musker
actors: [Scott Weinger, Robin Williams, Linda Larkin, Jonathan Freeman, Gilbert Gottfried]
genre: [Animation, Family, Adventure, Fantasy, Romance]
length: "1h 32m"
shelf: watched
owned: false
rating: 
watched: 2023-11-01
poster: "https://image.tmdb.org/t/p/w500/eLFfl7vS8dkeG1hKp5mwbm37V83.jpg"
---

# Aladdin (1992)

![](https://image.tmdb.org/t/p/w500/eLFfl7vS8dkeG1hKp5mwbm37V83.jpg)

In the boorish city of Agrabah, kind-hearted street urchin Aladdin and Princess Jasmine fall in love, although she can only marry a prince. He and power-hungry Grand Vizier Jafar vie for a magic lamp that can fulfill their wishes.