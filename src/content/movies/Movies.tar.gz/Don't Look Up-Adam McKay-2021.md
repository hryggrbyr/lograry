---
type: movie
country: United States, Canada
title: Don't Look Up
year: 2021
director: Adam McKay
actors: [Leonardo DiCaprio, Jennifer Lawrence, Meryl Streep]
genre: [Comedy, Drama, Sci-Fi]
length: 138
shelf: watchlist
owned: false
rating: 
poster: "https://m.media-amazon.com/images/M/MV5BMjhhNWFjNzctYTJjOS00MDc0LThiNjItZmM0ZDVmMWViY2UzXkEyXkFqcGc@._V1_SX300.jpg"
url: N/A
---

# Don't Look Up (2021)

![](https://m.media-amazon.com/images/M/MV5BMjhhNWFjNzctYTJjOS00MDc0LThiNjItZmM0ZDVmMWViY2UzXkEyXkFqcGc@._V1_SX300.jpg)

Two low-level astronomers must go on a giant media tour to warn humankind of an approaching comet that will destroy planet Earth.