---
type: movie
country: Australia
title: "Mad Max"
year: 1979
director: George Miller
actors: [Mel Gibson, Joanne Samuel, Hugh Keays-Byrne]
genre: [Action, Adventure, Sci-Fi]
length: 88
shelf: watched
owned: false
rating: 
watched: 1979-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMTM4Mjg5ODEzMV5BMl5BanBnXkFtZTcwMDc3NDk0NA@@._V1_SX300.jpg"
---

# Mad Max (1979)

![](https://m.media-amazon.com/images/M/MV5BMTM4Mjg5ODEzMV5BMl5BanBnXkFtZTcwMDc3NDk0NA@@._V1_SX300.jpg)

In a self-destructing world, a vengeful Australian policeman sets out to stop a violent motorcycle gang.