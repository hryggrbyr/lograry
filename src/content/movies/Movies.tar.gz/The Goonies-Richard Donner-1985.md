---
type: movie
country: United States
title: The Goonies
year: 1985
director: Richard Donner
actors: [Sean Astin, Josh Brolin, Jeff Cohen]
genre: [Adventure, Comedy, Family]
length: 114
shelf: watched
owned: false
rating: 
watched: 1985-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMjE1OWU4ODEtZmEzMC00NTcwLWFlMWUtYjhlNzExOTIxYzVlXkEyXkFqcGc@._V1_SX300.jpg"
---

# The Goonies (1985)

![](https://m.media-amazon.com/images/M/MV5BMjE1OWU4ODEtZmEzMC00NTcwLWFlMWUtYjhlNzExOTIxYzVlXkEyXkFqcGc@._V1_SX300.jpg)

A group of young misfits called The Goonies discover an ancient map and set out on an adventure to find a legendary pirate's long-lost treasure.