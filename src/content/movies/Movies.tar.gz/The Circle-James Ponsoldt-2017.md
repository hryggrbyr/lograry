---
type: movie
country: US
title: "The Circle"
year: 2017
director: James Ponsoldt
actors: [Emma Watson, Tom Hanks, John Boyega, Karen Gillan, Ellar Coltrane]
genre: [Drama, Thriller, Science Fiction]
length: "1h 50m"
shelf: watched
owned: false
rating: 
watched: 2017-04-28
poster: "https://image.tmdb.org/t/p/w500/bQVqd5rWrx5GbXhJNuvKy4Viz6j.jpg"
---

# The Circle (2017)

![](https://image.tmdb.org/t/p/w500/bQVqd5rWrx5GbXhJNuvKy4Viz6j.jpg)

A young tech worker takes a job at a powerful Internet corporation, quickly rises up the company's ranks, and soon finds herself in a perilous situation concerning privacy, surveillance and freedom. She comes to learn that her decisions and actions will determine the future of humanity.