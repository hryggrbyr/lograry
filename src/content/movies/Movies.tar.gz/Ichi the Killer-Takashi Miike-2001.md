---
type: movie
country: JP
title: "Ichi the Killer"
year: 2001
director: Takashi Miike
actors: [Tadanobu Asano, Nao Omori, Shinya Tsukamoto, SABU, Paulyn Sun]
genre: [Action, Crime, Horror]
length: "2h 9m"
shelf: watched
owned: false
rating: 
watched: 2001-12-22
poster: "https://image.tmdb.org/t/p/w500/k8j4YLZlda98dqp9ErymKzjYowG.jpg"
---

# Ichi the Killer (2001)

![](https://image.tmdb.org/t/p/w500/k8j4YLZlda98dqp9ErymKzjYowG.jpg)

As sadomasochistic yakuza enforcer Kakihara searches for his missing boss he comes across Ichi, a repressed and psychotic killer who may be able to inflict levels of pain that Kakihara has only dreamed of.