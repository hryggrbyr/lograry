---
type: movie
country: US
title: "Gremlins"
year: 1984
director: Joe Dante
actors: [Zach Galligan, Phoebe Cates, Hoyt Axton, Frances Lee McCain, Corey Feldman]
genre: [Fantasy, Horror, Comedy, Christmas]
length: "1h 46m"
shelf: watched
owned: false
rating: 
watched: 1984-06-07
poster: "https://image.tmdb.org/t/p/w500/6m0F7fsXjQvUbCZrPWcJNrjvIui.jpg"
---

# Gremlins (1984)

![](https://image.tmdb.org/t/p/w500/6m0F7fsXjQvUbCZrPWcJNrjvIui.jpg)

After receiving an exotic small animal as a Christmas gift, a young man inadvertently breaks three important rules concerning his new pet, which unleashes a horde of malevolently mischievous creatures on a small town.