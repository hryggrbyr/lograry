---
type: movie
country: US
title: "Twister"
year: 1996
director: Jan de Bont
actors: [Helen Hunt, Bill Paxton, Jami Gertz, Cary Elwes, Lois Smith]
genre: [Action, Adventure, Drama]
length: "1h 53m"
shelf: watched
owned: false
rating: 
watched: 1996-05-10
poster: "https://image.tmdb.org/t/p/w500/d4ie3f6QTvNw40V770Uzo87SDZn.jpg"
---

# Twister (1996)

![](https://image.tmdb.org/t/p/w500/d4ie3f6QTvNw40V770Uzo87SDZn.jpg)

An unprecedented series of violent tornadoes is sweeping across Oklahoma. Tornado chasers, headed by Dr. Jo Harding, attempt to release a groundbreaking device that will allow them to track them and create a more advanced warning system. They are joined by Jo's soon to be ex-husband Bill, a former tornado chaser himself, and his girlfriend Melissa.