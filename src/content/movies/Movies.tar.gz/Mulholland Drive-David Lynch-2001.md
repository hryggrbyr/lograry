---
type: movie
country: US
title: "Mulholland Drive"
year: 2001
director: David Lynch
actors: [Naomi Watts, Laura Harring, Justin Theroux, Ann Miller, Mark Pellegrino]
genre: [Thriller, Drama, Mystery]
length: "2h 27m"
shelf: watched
owned: false
rating: 
watched: 2001-10-19
poster: "https://image.tmdb.org/t/p/w500/x7A59t6ySylr1L7aubOQEA480vM.jpg"
---

# Mulholland Drive (2001)

![](https://image.tmdb.org/t/p/w500/x7A59t6ySylr1L7aubOQEA480vM.jpg)

Blonde Betty Elms has only just arrived in Hollywood to become a movie star when she meets an enigmatic brunette with amnesia. Meanwhile, as the two set off to solve the second woman's identity, filmmaker Adam Kesher runs into ominous trouble while casting his latest project.