---
type: movie
country: Japan
title: "Mary and the Witch's Flower"
year: 2017
director: Hiromasa Yonebayashi
actors: [Hana Sugisaki, Ryûnosuke Kamiki, Yûki Amami]
genre: [Animation, Adventure, Family, magic, fantasy]
length: 103
shelf: watched
owned: false
rating: 
watched: 2025-11-10
poster: "https://m.media-amazon.com/images/M/MV5BMzk3NWViZjctMGVhNy00OWJjLTkxYWQtNmZmMzI2ZDRlNTUyXkEyXkFqcGc@._V1_SX300.jpg"
---

# Mary and the Witch's Flower (2017)

![](https://m.media-amazon.com/images/M/MV5BMzk3NWViZjctMGVhNy00OWJjLTkxYWQtNmZmMzI2ZDRlNTUyXkEyXkFqcGc@._V1_SX300.jpg)

Based on "The Little Broomstick" by Mary Stewart, a strange flower grants a girl magic powers.