---
type: movie
country: US, GB
title: "Dangerous Liaisons"
year: 1988
director: Stephen Frears
actors: [Glenn Close, John Malkovich, Michelle Pfeiffer, Uma Thurman, Swoosie Kurtz]
genre: [Drama, Romance]
length: "1h 59m"
shelf: watched
owned: false
rating: 
watched: 1988-12-21
poster: "https://image.tmdb.org/t/p/w500/7etDozwd9Pf5oCcyo4h1Hki6U13.jpg"
---

# Dangerous Liaisons (1988)

![](https://image.tmdb.org/t/p/w500/7etDozwd9Pf5oCcyo4h1Hki6U13.jpg)

In 18th century France, Marquise de Merteuil asks her ex-lover Vicomte de Valmont to seduce the future wife of another ex-lover of hers in return for one last night with her. Yet things don’t go as planned.