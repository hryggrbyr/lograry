---
type: movie
country: JP
title: "The Dark Maidens"
year: 2017
director: Saiji Yakumo
actors: [Marie Iitoyo, Yoshiko Sengen, Nana Seino, Riria Kojima, Tina Tamashiro]
genre: [Mystery, Drama]
length: "1h 45m"
shelf: watched
owned: false
rating: 
watched: 2017-04-01
poster: "https://image.tmdb.org/t/p/w500/rsymDwOeRqCNHAcXYJ9t1WQJYcA.jpg"
---

# The Dark Maidens (2017)

![](https://image.tmdb.org/t/p/w500/rsymDwOeRqCNHAcXYJ9t1WQJYcA.jpg)

Set in an academy for daughters of the rich and powerful, this murder mystery involves six girls with a dark secret. Literature club chairman Itsumi Shiraishi, has fallen to her death from the school roof. Rumours soon circulate that one of the members of the literature club is the culprit. New chairman and friend of the victim, Sayuri Sumikawa, holds a meeting and asks each member to recount their whereabouts at the time of Itsumi’s death. Who is telling a lie and what really happened to Itsumi?