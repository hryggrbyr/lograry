---
type: movie
country: US
title: "Snake Eyes"
year: 1998
director: Brian De Palma
actors: [Nicolas Cage, Gary Sinise, Carla Gugino, John Heard, Stan Shaw]
genre: [Thriller, Crime, Mystery]
length: "1h 38m"
shelf: watched
owned: false
rating: 
watched: 1998-08-07
poster: "https://image.tmdb.org/t/p/w500/gsh9mQKRrr4M90XC9Rr0wxefc9u.jpg"
---

# Snake Eyes (1998)

![](https://image.tmdb.org/t/p/w500/gsh9mQKRrr4M90XC9Rr0wxefc9u.jpg)

All bets are off when shady homicide cop Rick Santoro witnesses a murder during a boxing match. It's up to him and lifelong friend, Naval intelligence agent Kevin Dunne, to uncover the conspiracy behind the killing. At every turn, Santoro makes increasingly shocking discoveries that even he can't turn a blind eye to.