---
type: movie
country: US
title: "Reservoir Dogs"
year: 1992
director: Quentin Tarantino
actors: [Harvey Keitel, Tim Roth, Michael Madsen, Chris Penn, Steve Buscemi]
genre: [Crime, Thriller]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 1992-10-23
poster: "https://image.tmdb.org/t/p/w500/xi8Iu6qyTfyZVDVy60raIOYJJmk.jpg"
---

# Reservoir Dogs (1992)

![](https://image.tmdb.org/t/p/w500/xi8Iu6qyTfyZVDVy60raIOYJJmk.jpg)

A botched robbery indicates a police informant, and the pressure mounts in the aftermath at a warehouse. Crime begets violence as the survivors -- veteran Mr. White, newcomer Mr. Orange, psychopathic parolee Mr. Blonde, bickering weasel Mr. Pink and Nice Guy Eddie -- unravel.