---
type: movie
country: US
title: "Lara Croft: Tomb Raider"
year: 2001
director: Simon West
actors: [Angelina Jolie, Iain Glen, Daniel Craig, Noah Taylor, Chris Barrie]
genre: [Adventure, Fantasy, Action, Thriller]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 2001-06-11
poster: "https://image.tmdb.org/t/p/w500/7WyMvoqPYJe5g1ENsbLTv40pUrX.jpg"
---

# Lara Croft: Tomb Raider (2001)

![](https://image.tmdb.org/t/p/w500/7WyMvoqPYJe5g1ENsbLTv40pUrX.jpg)

Orphaned heiress, English aristocrat and intrepid archaeologist, Lara Croft, embarks on a dangerous quest to retrieve the two halves of an ancient artifact which controls time before it falls into the wrong hands. As an extremely rare planetary alignment is about to occur for the first time in 5,000 years, the fearless tomb raider will have to team up with rival adventurers and sworn enemies to collect the pieces, while time is running out. But, in the end, who can harness the archaic talisman's unlimited power?