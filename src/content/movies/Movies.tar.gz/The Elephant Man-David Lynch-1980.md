---
type: movie
country: US
title: "The Elephant Man"
year: 1980
director: David Lynch
actors: [Anthony Hopkins, John Hurt, Anne Bancroft, John Gielgud, Wendy Hiller]
genre: [Drama, History]
length: "2h 4m"
shelf: watched
owned: false
rating: 
watched: 1980-10-10
poster: "https://image.tmdb.org/t/p/w500/u0wpPYjuSt8DIe1Y3Vapnh8jcKE.jpg"
---

# The Elephant Man (1980)

![](https://image.tmdb.org/t/p/w500/u0wpPYjuSt8DIe1Y3Vapnh8jcKE.jpg)

A Victorian surgeon rescues a heavily disfigured man being mistreated by his "owner" as a side-show freak. Behind his monstrous façade, there is revealed a person of great intelligence and sensitivity. Based on the true story of Joseph Merrick (called John Merrick in the film), a severely deformed man in 19th century London.