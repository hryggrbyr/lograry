---
type: movie
country: US
title: "Aliens"
year: 1986
director: James Cameron
actors: [Sigourney Weaver, Carrie Henn, Michael Biehn, Paul Reiser, Lance Henriksen]
genre: [Action, Thriller, Science Fiction]
length: "2h 17m"
shelf: watched
owned: false
rating: 
watched: 1986-07-18
poster: "https://image.tmdb.org/t/p/w500/r1x5JGpyqZU8PYhbs4UcrO1Xb6x.jpg"
---

# Aliens (1986)

![](https://image.tmdb.org/t/p/w500/r1x5JGpyqZU8PYhbs4UcrO1Xb6x.jpg)

Ripley, the sole survivor of the Nostromo's deadly encounter with the monstrous Alien, returns to Earth after drifting through space in hypersleep for 57 years. Although her story is initially met with skepticism, she agrees to accompany a team of Colonial Marines back to LV-426.