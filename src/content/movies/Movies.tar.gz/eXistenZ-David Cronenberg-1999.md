---
type: movie
country: CA, FR, GB
title: "eXistenZ"
year: 1999
director: David Cronenberg
actors: [Jennifer Jason Leigh, Jude Law, Ian Holm, Willem Dafoe, Don McKellar]
genre: [Action, Thriller, Science Fiction]
length: "1h 37m"
shelf: watched
owned: false
rating: 
watched: 1999-04-23
poster: "https://image.tmdb.org/t/p/w500/kETKF0JhdTPn1knci8CAdYL0d79.jpg"
---

# eXistenZ (1999)

![](https://image.tmdb.org/t/p/w500/kETKF0JhdTPn1knci8CAdYL0d79.jpg)

A game designer on the run from assassins must play her latest virtual reality creation with a marketing trainee to determine if the game has been damaged.