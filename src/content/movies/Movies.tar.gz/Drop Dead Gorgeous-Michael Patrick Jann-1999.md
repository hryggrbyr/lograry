---
type: movie
country: US
title: "Drop Dead Gorgeous"
year: 1999
director: Michael Patrick Jann
actors: [Kirsten Dunst, Ellen Barkin, Denise Richards, Kirstie Alley, Allison Janney]
genre: [Comedy]
length: "1h 38m"
shelf: watched
owned: false
rating: 
watched: 1999-07-23
poster: "https://image.tmdb.org/t/p/w500/s4nHRCB5GqWyWiqweVf6UUv8GWt.jpg"
---

# Drop Dead Gorgeous (1999)

![](https://image.tmdb.org/t/p/w500/s4nHRCB5GqWyWiqweVf6UUv8GWt.jpg)

In a small Minnesota town, the annual beauty pageant is being covered by a TV crew. Former winner Gladys Leeman wants to make sure her daughter follows in her footsteps; explosions, falling lights, and trailer fires prove that. As the Leemans are the richest family in town, the police are pretty relaxed about it all. Despite everything, main rival (but sweet) Amber Atkins won't give up without a fight.