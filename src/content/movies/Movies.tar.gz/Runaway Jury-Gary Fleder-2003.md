---
type: movie
country: US
title: "Runaway Jury"
year: 2003
director: Gary Fleder
actors: [John Cusack, Gene Hackman, Dustin Hoffman, Rachel Weisz, Bruce Davison]
genre: [Drama, Thriller]
length: "2h 7m"
shelf: watched
owned: false
rating: 
watched: 2003-10-09
poster: "https://image.tmdb.org/t/p/w500/g58RA1zzE39KnkRpKRfgA5RxoXP.jpg"
---

# Runaway Jury (2003)

![](https://image.tmdb.org/t/p/w500/g58RA1zzE39KnkRpKRfgA5RxoXP.jpg)

After a workplace shooting in New Orleans, a trial against the gun manufacturer pits lawyer Wendell Rohr against shady jury consultant Rankin Fitch, who uses illegal means to stack the jury with people sympathetic to the defense. But when juror Nicholas Easter and his girlfriend Marlee reveal their ability to sway the jury into delivering any verdict they want, a high-stakes cat-and-mouse game begins.