---
type: movie
country: GB, US
title: "2001: A Space Odyssey"
year: 1968
director: Stanley Kubrick
actors: [Keir Dullea, Gary Lockwood, William Sylvester, Douglas Rain, Daniel Richter]
genre: [Science Fiction, Mystery, Adventure]
length: "2h 29m"
shelf: watched
owned: false
rating: 
watched: 1968-04-10
poster: "https://image.tmdb.org/t/p/w500/ve72VxNqjGM69Uky4WTo2bK6rfq.jpg"
---

# 2001: A Space Odyssey (1968)

![](https://image.tmdb.org/t/p/w500/ve72VxNqjGM69Uky4WTo2bK6rfq.jpg)

Humanity finds a mysterious object buried beneath the lunar surface and sets off to find its origins with the help of HAL 9000, the world's most advanced super computer.