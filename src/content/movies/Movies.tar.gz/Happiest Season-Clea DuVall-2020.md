---
type: movie
country: US
title: "Happiest Season"
year: 2020
director: Clea DuVall
actors: [Kristen Stewart, Mackenzie Davis, Mary Steenburgen, Victor Garber, Alison Brie]
genre: [Romance, Comedy, Christmas, lgbt]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 2020-11-25
poster: "https://image.tmdb.org/t/p/w500/vzec9kkOSE93tygyfOktedkeOQ.jpg"
---

# Happiest Season (2020)

![](https://image.tmdb.org/t/p/w500/vzec9kkOSE93tygyfOktedkeOQ.jpg)

A young woman's plans to propose to her girlfriend while at her family's annual holiday party are upended when she discovers her partner hasn't yet come out to her conservative parents.