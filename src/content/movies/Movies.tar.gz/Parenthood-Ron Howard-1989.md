---
type: movie
country: US
title: "Parenthood"
year: 1989
director: Ron Howard
actors: [Steve Martin, Mary Steenburgen, Dianne Wiest, Jason Robards, Rick Moranis]
genre: [Comedy, Drama, Romance, Family]
length: "2h 4m"
shelf: watched
owned: false
rating: 
watched: 1989-07-31
poster: "https://image.tmdb.org/t/p/w500/e51tNNQBJpJi9xkyuj0QFhyBcz7.jpg"
---

# Parenthood (1989)

![](https://image.tmdb.org/t/p/w500/e51tNNQBJpJi9xkyuj0QFhyBcz7.jpg)

The story of the Buckman family and friends, attempting to bring up their children. They suffer/enjoy all the events that occur: estranged relatives, the 'black sheep' of the family, the eccentrics, the skeletons in the closet, and the rebellious teenagers.