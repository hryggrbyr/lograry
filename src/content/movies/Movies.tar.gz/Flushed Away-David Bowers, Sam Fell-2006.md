---
type: movie
country: United Kingdom, United States
title: "Flushed Away"
year: 2006
director: David Bowers, Sam Fell
actors: [Hugh Jackman, Kate Winslet, Ian McKellen]
genre: [Animation, Action, Adventure]
length: 85
shelf: watched
owned: false
rating: 4
watched: 2025-11-02
poster: "https://m.media-amazon.com/images/M/MV5BMTI1MzE1MDk2N15BMl5BanBnXkFtZTYwMjEwMzI3._V1_SX300.jpg"
---

# Flushed Away (2006)

![](https://m.media-amazon.com/images/M/MV5BMTI1MzE1MDk2N15BMl5BanBnXkFtZTYwMjEwMzI3._V1_SX300.jpg)

The story of an uptown rat that gets flushed down the toilet from his penthouse apartment, ending in the sewers of London, where he has to learn a whole new and different way of life.