---
type: movie
country: US
title: "The Lords of Salem"
year: 2013
director: Rob Zombie
actors: [Sheri Moon Zombie, Bruce Davison, Jeff Daniel Phillips, Judy Geeson, Meg Foster]
genre: [Horror, Thriller]
length: "1h 41m"
shelf: watched
owned: false
rating: 
watched: 2013-04-19
poster: "https://image.tmdb.org/t/p/w500/nqZ6CGGZpQWt139YioekSYHvvkU.jpg"
---

# The Lords of Salem (2013)

![](https://image.tmdb.org/t/p/w500/nqZ6CGGZpQWt139YioekSYHvvkU.jpg)

Heidi, a radio DJ, is sent a box containing a record - a "gift from the Lords". The sounds within the grooves trigger flashbacks of her town's violent past. Is Heidi going mad, or are the Lords back to take revenge on Salem, Massachusetts?