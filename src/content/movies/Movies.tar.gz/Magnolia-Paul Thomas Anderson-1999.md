---
type: movie
country: US
title: "Magnolia"
year: 1999
director: Paul Thomas Anderson
actors: [Tom Cruise, Philip Baker Hall, Philip Seymour Hoffman, Julianne Moore, William H. Macy]
genre: [Drama]
length: "3h 9m"
shelf: watched
owned: false
rating: 
watched: 1999-12-17
poster: "https://image.tmdb.org/t/p/w500/tpfC325Jk6S38VTe5dDWjWtoyxr.jpg"
---

# Magnolia (1999)

![](https://image.tmdb.org/t/p/w500/tpfC325Jk6S38VTe5dDWjWtoyxr.jpg)

On one random day in the San Fernando Valley, a dying father, a young wife, a male caretaker, a famous lost son, a police officer in love, a boy genius, an ex-boy genius, a game show host and an estranged daughter will each become part of a dazzling multiplicity of plots, but one story.