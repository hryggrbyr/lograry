---
type: movie
country: US
title: "Series 7: The Contenders"
year: 2001
director: Daniel Minahan
actors: [Brooke Smith, Mark Woodbury, Michael Kaycheck, Marylouise Burke, Richard Venture]
genre: [Action, Comedy, Thriller]
length: "1h 26m"
shelf: watched
owned: false
rating: 
watched: 2001-01-20
poster: "https://image.tmdb.org/t/p/w500/85tuJxQdjQcec3DTMc9dxwlYYfi.jpg"
---

# Series 7: The Contenders (2001)

![](https://image.tmdb.org/t/p/w500/85tuJxQdjQcec3DTMc9dxwlYYfi.jpg)

A reality TV program selects six contestants to participate in a free-for-all, no holds barred deathmatch, where they must skillfully outwit and kill each other in order to be the last person alive.