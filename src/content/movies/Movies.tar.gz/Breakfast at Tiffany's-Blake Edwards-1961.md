---
type: movie
country: US
title: "Breakfast at Tiffany's"
year: 1961
director: Blake Edwards
actors: [Audrey Hepburn, George Peppard, Patricia Neal, Buddy Ebsen, Martin Balsam]
genre: [Comedy, Romance, Drama]
length: "1h 55m"
shelf: watched
owned: false
rating: 
watched: 1961-10-06
poster: "https://image.tmdb.org/t/p/w500/79xm4gXw4l7A5D0XukUOJRocFYQ.jpg"
---

# Breakfast at Tiffany's (1961)

![](https://image.tmdb.org/t/p/w500/79xm4gXw4l7A5D0XukUOJRocFYQ.jpg)

Holly Golightly is an eccentric New York City playgirl determined to marry a Brazilian millionaire. But when young writer Paul Varjak moves into her apartment building, her past threatens to get in their way.