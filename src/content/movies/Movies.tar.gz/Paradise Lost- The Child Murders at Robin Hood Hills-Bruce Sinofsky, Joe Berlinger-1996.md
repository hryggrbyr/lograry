---
type: movie
country: US
title: "Paradise Lost: The Child Murders at Robin Hood Hills"
year: 1996
director: Bruce Sinofsky, Joe Berlinger
actors: [Damien Echols, Jason Baldwin, Jessie Misskelley Jr., Joe Berlinger, Bruce Sinofsky]
genre: [Documentary, Crime]
length: "2h 30m"
shelf: watched
owned: false
rating: 
watched: 1996-06-06
poster: "https://image.tmdb.org/t/p/w500/h65fwEQTv9zRNyEuExE1wAk5CQ2.jpg"
---

# Paradise Lost: The Child Murders at Robin Hood Hills (1996)

![](https://image.tmdb.org/t/p/w500/h65fwEQTv9zRNyEuExE1wAk5CQ2.jpg)

A horrific triple child murder leads to an indictment and trial of three nonconformist boys based on questionable evidence.