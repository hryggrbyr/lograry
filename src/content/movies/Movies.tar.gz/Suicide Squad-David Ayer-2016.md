---
type: movie
country: US
title: "Suicide Squad"
year: 2016
director: David Ayer
actors: [Will Smith, Jared Leto, Margot Robbie, Joel Kinnaman, Viola Davis]
genre: [Action, Adventure, Fantasy]
length: "2h 2m"
shelf: watchlist
owned: false
rating: 
watched:
poster: "https://image.tmdb.org/t/p/w500/sk3FZgh3sRrmr8vyhaitNobMcfh.jpg"
---

# Suicide Squad (2016)

![](https://image.tmdb.org/t/p/w500/sk3FZgh3sRrmr8vyhaitNobMcfh.jpg)

From DC Comics comes the Suicide Squad, an antihero team of incarcerated supervillains who act as deniable assets for the United States government, undertaking high-risk black ops missions in exchange for commuted prison sentences.