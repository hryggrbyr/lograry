---
type: movie
country: US
title: "Big Daddy"
year: 1999
director: Dennis Dugan
actors: [Adam Sandler, Cole Sprouse, Dylan Sprouse, Joey Lauren Adams, Josh Mostel]
genre: [Comedy, Drama]
length: "1h 33m"
shelf: watched
owned: false
rating: 
watched: 1999-06-25
poster: "https://image.tmdb.org/t/p/w500/cqFnFg6YS8urJT6YC95IDkn0VHz.jpg"
---

# Big Daddy (1999)

![](https://image.tmdb.org/t/p/w500/cqFnFg6YS8urJT6YC95IDkn0VHz.jpg)

A lazy law school grad adopts a kid to impress his girlfriend, but everything doesn't go as planned and he becomes the unlikely foster father.