---
type: movie
country: GB
title: "The Boy, the Mole, the Fox and the Horse"
year: 2022
director: Peter Baynton, Charlie Mackesy
actors: [Jude Coward Nicoll, Tom Hollander, Idris Elba, Gabriel Byrne]
genre: [Animation, Family, Adventure, Fantasy]
length: "35m"
shelf: watched
owned: false
rating: 
watched: 2024-11-03
poster: "https://image.tmdb.org/t/p/w500/aBBJRyS17TIrdXih3uSYvPAR3Ua.jpg"
---

# The Boy, the Mole, the Fox and the Horse (2022)

![](https://image.tmdb.org/t/p/w500/aBBJRyS17TIrdXih3uSYvPAR3Ua.jpg)

The unlikely friendship of a boy, a mole, a fox and a horse traveling together in the boy's search for home.