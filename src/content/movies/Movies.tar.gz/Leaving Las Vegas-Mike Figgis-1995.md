---
type: movie
country: US
title: "Leaving Las Vegas"
year: 1995
director: Mike Figgis
actors: [Nicolas Cage, Elisabeth Shue, Julian Sands, Richard Lewis, Steven Weber]
genre: [Drama, Romance]
length: "1h 51m"
shelf: watched
owned: false
rating: 
watched: 1995-10-27
poster: "https://image.tmdb.org/t/p/w500/wTrFpGe3U65kXTldIUxuM2hmOAK.jpg"
---

# Leaving Las Vegas (1995)

![](https://image.tmdb.org/t/p/w500/wTrFpGe3U65kXTldIUxuM2hmOAK.jpg)

Ben Sanderson, an alcoholic Hollywood screenwriter who lost everything because of his drinking, arrives in Las Vegas to drink himself to death. There, he meets and forms an uneasy friendship and non-interference pact with prostitute Sera.