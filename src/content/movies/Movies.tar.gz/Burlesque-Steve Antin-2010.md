---
type: movie
country: US
title: "Burlesque"
year: 2010
director: Steve Antin
actors: [Cher, Christina Aguilera, Cam Gigandet, Kristen Bell, Stanley Tucci]
genre: [Drama, Romance]
length: "1h 59m"
shelf: watched
owned: false
rating: 
watched: 2010-11-23
poster: "https://image.tmdb.org/t/p/w500/3U9zBIibERQZqYKM3N1a4MYgBsN.jpg"
---

# Burlesque (2010)

![](https://image.tmdb.org/t/p/w500/3U9zBIibERQZqYKM3N1a4MYgBsN.jpg)

Ali leaves behind a troubled life and follows her dreams to Los Angeles, where she lands a job as a cocktail waitress at the Burlesque Lounge, a once-majestic theater that houses an inspired musical revue. Vowing to perform there, she makes the leap from bar to stage, helping restore the club's former glory.