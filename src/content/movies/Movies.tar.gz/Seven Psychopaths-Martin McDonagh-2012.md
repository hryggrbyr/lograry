---
type: movie
country: GB
title: "Seven Psychopaths"
year: 2012
director: Martin McDonagh
actors: [Colin Farrell, Sam Rockwell, Woody Harrelson, Christopher Walken, Olga Kurylenko]
genre: [Comedy, Crime]
length: "1h 50m"
shelf: watched
owned: false
rating: 
watched: 2012-10-12
poster: "https://image.tmdb.org/t/p/w500/4ukEYAxlSivFcDG6vLxJB6PjTjg.jpg"
---

# Seven Psychopaths (2012)

![](https://image.tmdb.org/t/p/w500/4ukEYAxlSivFcDG6vLxJB6PjTjg.jpg)

A struggling screenwriter inadvertently becomes entangled in the Los Angeles criminal underworld after his oddball friends kidnap a gangster's beloved Shih Tzu.