---
type: movie
country: US
title: "Who Framed Roger Rabbit"
year: 1988
director: Robert Zemeckis
actors: [Bob Hoskins, Christopher Lloyd, Joanna Cassidy, Charles Fleischer, Kathleen Turner]
genre: [Fantasy, Animation, Comedy, Crime]
length: "1h 44m"
shelf: watched
owned: false
rating: 
watched: 1988-06-21
poster: "https://image.tmdb.org/t/p/w500/lYfRc57Kx9VgLZ48iulu0HKnM15.jpg"
---

# Who Framed Roger Rabbit (1988)

![](https://image.tmdb.org/t/p/w500/lYfRc57Kx9VgLZ48iulu0HKnM15.jpg)

'Toon star Roger is worried that his wife Jessica is playing pattycake with someone else, so the studio hires detective Eddie Valiant to snoop on her. But the stakes are quickly raised when Marvin Acme is found dead and Roger is the prime suspect.