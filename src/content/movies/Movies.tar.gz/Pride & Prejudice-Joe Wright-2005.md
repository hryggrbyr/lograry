---
type: movie
country: GB
title: "Pride & Prejudice"
year: 2005
director: Joe Wright
actors: [Keira Knightley, Matthew Macfadyen, Brenda Blethyn, Rosamund Pike, Carey Mulligan]
genre: [Drama, Romance]
length: "2h 7m"
shelf: watched
owned: false
rating: 
watched: 2005-11-11
poster: "https://image.tmdb.org/t/p/w500/jnsoq5q98DQaE8yw6WZH0F9dW5G.jpg"
---

# Pride & Prejudice (2005)

![](https://image.tmdb.org/t/p/w500/jnsoq5q98DQaE8yw6WZH0F9dW5G.jpg)

A story of love and life among the landed English gentry during the Georgian era. Mr. Bennet is a gentleman living in Hertfordshire with his overbearing wife and five daughters, but if he dies their house will be inherited by a distant cousin whom they have never met, so the family's future happiness and security is dependent on the daughters making good marriages.