---
type: movie
country: US
title: "Rosemary's Baby"
year: 1968
director: Roman Polanski
actors: [Mia Farrow, John Cassavetes, Ruth Gordon, Sidney Blackmer, Maurice Evans]
genre: [Drama, Horror, Thriller]
length: "2h 18m"
shelf: watched
owned: false
rating: 
watched: 1968-06-12
poster: "https://image.tmdb.org/t/p/w500/uYgvlHceRFjAFbsNeMInYcLZLUb.jpg"
---

# Rosemary's Baby (1968)

![](https://image.tmdb.org/t/p/w500/uYgvlHceRFjAFbsNeMInYcLZLUb.jpg)

A young couple, Rosemary and Guy, moves into an infamous New York apartment building, known by frightening legends and mysterious events, with the purpose of starting a family.