---
type: movie
country: United States
title: "Pleasantville"
year: 1998
director: Gary Ross
actors: [Tobey Maguire, Jeff Daniels, Joan Allen]
genre: [Comedy, Drama, Fantasy]
length: 124
shelf: watched
owned: false
rating: 
watched: 1998-12-31
poster: "https://m.media-amazon.com/images/M/MV5BYmM4ZThmNzAtYzRmNi00ZjZmLThhYjAtYjU2YTcwMmY3MzRmXkEyXkFqcGc@._V1_SX300.jpg"
---

# Pleasantville (1998)

![](https://m.media-amazon.com/images/M/MV5BYmM4ZThmNzAtYzRmNi00ZjZmLThhYjAtYjU2YTcwMmY3MzRmXkEyXkFqcGc@._V1_SX300.jpg)

Two 1990s teenage siblings find themselves transported to a 1950s sitcom where their influence begins to profoundly change that colorless, complacent world.