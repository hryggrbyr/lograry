---
type: movie
country: US
title: "Longlegs"
year: 2024
director: Osgood Perkins
actors: [Maika Monroe, Nicolas Cage, Blair Underwood, Alicia Witt, Michelle Choi-Lee]
genre: [Crime, Horror, Thriller]
length: "1h 41m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/1EwNyiiNFd863H4e8nWEzutnZD7.jpg"
---

# Longlegs (2024)

![](https://image.tmdb.org/t/p/w500/1EwNyiiNFd863H4e8nWEzutnZD7.jpg)

FBI Agent Lee Harker is a gifted new recruit assigned to the unsolved case of an elusive serial killer. As the case takes complex turns, unearthing evidence of the occult, Harker discovers a personal connection to the merciless killer and must race against time to stop him before he claims the lives of another innocent family.
