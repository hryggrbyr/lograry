---
type: movie
country: US
title: "Ace Ventura: When Nature Calls"
year: 1995
director: Steve Oedekerk
actors: [Jim Carrey, Ian McNeice, Simon Callow, Maynard Eziashi, Bob Gunton]
genre: [Crime, Comedy, Adventure]
length: "1h 30m"
shelf: watched
owned: false
rating: 
watched: 1995-11-10
poster: "https://image.tmdb.org/t/p/w500/wcinCf1ov2D6M3P7BBZkzQFOiIb.jpg"
---

# Ace Ventura: When Nature Calls (1995)

![](https://image.tmdb.org/t/p/w500/wcinCf1ov2D6M3P7BBZkzQFOiIb.jpg)

Summoned from an ashram in Tibet, Ace finds himself on a perilous journey into the jungles of Africa to find Shikaka, the missing sacred animal of the friendly Wachati tribe. He must accomplish this before the wedding of the Wachati's Princess to the prince of the warrior Wachootoos. If Ace fails, the result will be a vicious tribal war.