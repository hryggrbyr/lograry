---
type: movie
country: US
title: "Basquiat"
year: 1996
director: Julian Schnabel
actors: [Jeffrey Wright, Michael Wincott, Benicio del Toro, Claire Forlani, David Bowie]
genre: [Drama, History]
length: "1h 47m"
shelf: watched
owned: true
rating: 
watched: 1996-08-09
poster: "https://image.tmdb.org/t/p/w500/hNjjGGnHrLILwFiEwGESWD6QRCy.jpg"
---

# Basquiat (1996)

![](https://image.tmdb.org/t/p/w500/hNjjGGnHrLILwFiEwGESWD6QRCy.jpg)

The brief life of Jean Michel Basquiat, a world renowned New York street artist struggling with fame, drugs and his identity.