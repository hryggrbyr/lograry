---
type: movie
country: US
title: "Requiem for a Dream"
year: 2000
director: Darren Aronofsky
actors: [Ellen Burstyn, Jared Leto, Jennifer Connelly, Marlon Wayans, Christopher McDonald]
genre: [Crime, Drama]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/nOd6vjEmzCT0k4VYqsA2hwyi87C.jpg"
---

# Requiem for a Dream (2000)

![](https://image.tmdb.org/t/p/w500/nOd6vjEmzCT0k4VYqsA2hwyi87C.jpg)

The drug-induced utopias of four Coney Island residents are shattered when their addictions run deep.