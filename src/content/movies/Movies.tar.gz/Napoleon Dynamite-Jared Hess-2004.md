---
type: movie
country: US
title: "Napoleon Dynamite"
year: 2004
director: Jared Hess
actors: [Jon Heder, Efren Ramirez, Tina Majorino, Aaron Ruell, Jon Gries]
genre: [Comedy]
length: "1h 35m"
shelf: watched
owned: false
rating: 
watched: 2004-08-27
poster: "https://image.tmdb.org/t/p/w500/6Iv6Uwa2SBLN0dSGM00rdrwN4MJ.jpg"
---

# Napoleon Dynamite (2004)

![](https://image.tmdb.org/t/p/w500/6Iv6Uwa2SBLN0dSGM00rdrwN4MJ.jpg)

A listless and alienated teenager decides to help his new friend win the class presidency in their small western high school, while he must deal with his bizarre family life back home.