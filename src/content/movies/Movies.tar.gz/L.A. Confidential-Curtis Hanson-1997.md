---
type: movie
country: US
title: "L.A. Confidential"
year: 1997
director: Curtis Hanson
actors: [Kevin Spacey, Russell Crowe, Guy Pearce, James Cromwell, Kim Basinger]
genre: [Crime, Mystery, Thriller, Drama]
length: "2h 18m"
shelf: watched
owned: false
rating: 
watched: 1997-09-19
poster: "https://image.tmdb.org/t/p/w500/lWCgf5sD5FpMljjpkRhcC8pXcch.jpg"
---

# L.A. Confidential (1997)

![](https://image.tmdb.org/t/p/w500/lWCgf5sD5FpMljjpkRhcC8pXcch.jpg)

Three detectives in the corrupt and brutal L.A. police force of the 1950s use differing methods to uncover a conspiracy behind the shotgun slayings of the patrons at an all-night diner.