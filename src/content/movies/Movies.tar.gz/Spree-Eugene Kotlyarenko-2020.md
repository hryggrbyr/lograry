---
type: movie
country: US
title: "Spree"
year: 2020
director: Eugene Kotlyarenko
actors: [Joe Keery, Sasheer Zamata, David Arquette, Joshua Ovalle, A.J. Del Cueto]
genre: [Comedy, Crime, Horror, Thriller]
length: "1h 33m"
shelf: watched
owned: false
rating: 
watched: 2020-08-14
poster: "https://image.tmdb.org/t/p/w500/tbYvzpy4QFhUHRBHe4VeUKJst96.jpg"
---

# Spree (2020)

![](https://image.tmdb.org/t/p/w500/tbYvzpy4QFhUHRBHe4VeUKJst96.jpg)

Desperate for an online following, a rideshare driver has figured out a deadly plan to go viral and he will stop at nothing to get his five minutes of fame.