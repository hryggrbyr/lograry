---
type: movie
country: US
title: "Deadpool"
year: 2016
director: Tim Miller
actors: [Ryan Reynolds, Morena Baccarin, Ed Skrein, T.J. Miller, Gina Carano]
genre: [Action, Adventure, Comedy]
length: "1h 48m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/3E53WEZJqP6aM84D8CckXx4pIHw.jpg"
---

# Deadpool (2016)

![](https://image.tmdb.org/t/p/w500/3E53WEZJqP6aM84D8CckXx4pIHw.jpg)

The origin story of former Special Forces operative turned mercenary Wade Wilson, who, after being subjected to a rogue experiment that leaves him with accelerated healing powers, adopts the alter ego Deadpool. Armed with his new abilities and a dark, twisted sense of humor, Deadpool hunts down the man who nearly destroyed his life.