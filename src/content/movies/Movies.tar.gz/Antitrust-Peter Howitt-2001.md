---
type: movie
country: CA, US
title: "Antitrust"
year: 2001
director: Peter Howitt
actors: [Ryan Phillippe, Rachael Leigh Cook, Tim Robbins, Claire Forlani, Richard Roundtree]
genre: [Action, Crime, Drama]
length: "1h 48m"
shelf: watched
owned: false
rating: 
watched: 2001-01-12
poster: "https://image.tmdb.org/t/p/w500/9PXyfcJe53A9qFkcj5dkTJwIWoS.jpg"
---

# Antitrust (2001)

![](https://image.tmdb.org/t/p/w500/9PXyfcJe53A9qFkcj5dkTJwIWoS.jpg)

A computer programmer's dream job at a hot Portland-based firm turns nightmarish when he discovers his boss has a secret and ruthless means of dispatching anti-trust problems.