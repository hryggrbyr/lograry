---
type: movie
country: US
title: "Hellboy"
year: 2004
director: Guillermo del Toro
actors: [Ron Perlman, Selma Blair, Doug Jones, John Hurt, Rupert Evans]
genre: [Fantasy, Action]
length: "2h 2m"
shelf: watched
owned: false
rating: 
watched: 2004-04-02
poster: "https://image.tmdb.org/t/p/w500/21hS8mD8uxBVvf8xVYR30LbbmPO.jpg"
---

# Hellboy (2004)

![](https://image.tmdb.org/t/p/w500/21hS8mD8uxBVvf8xVYR30LbbmPO.jpg)

In the final days of World War II, the Nazis attempt to use black magic to aid their dying cause. The Allies raid the camp where the ceremony is taking place, but not before they summon a baby demon who is rescued by Allied forces and dubbed "Hellboy". Sixty years later, Hellboy serves the cause of good rather than evil as an agent in the Bureau of Paranormal Research & Defense, along with Abe Sapien - a merman with psychic powers, and Liz Sherman - a woman with pyrokinesis, protecting America against dark forces.