---
type: movie
country: US
title: "Pet Sematary"
year: 1989
director: Mary Lambert
actors: [Dale Midkiff, Fred Gwynne, Denise Crosby, Brad Greenquist, Michael Lombard]
genre: [Horror]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 1989-04-21
poster: "https://image.tmdb.org/t/p/w500/a1gIACZb04bL8EvLqMpofW2Eqeo.jpg"
---

# Pet Sematary (1989)

![](https://image.tmdb.org/t/p/w500/a1gIACZb04bL8EvLqMpofW2Eqeo.jpg)

After the Creed family's cat is accidentally killed, a friendly neighbor advises its burial in a mysterious nearby cemetery.