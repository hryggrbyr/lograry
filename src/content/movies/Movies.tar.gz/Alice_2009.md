---
type: series
country: CA
title: "Alice"
year: 2009
director: Unknown
actors: [Caterina Scorsone, Andrew-Lee Potts, Matt Frewer, Harry Dean Stanton, Alessandro Juliani]
genre: [Sci-Fi & Fantasy, Comedy]
length: "1 season (2 episodes)"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/2lvWLSOPtsqkgVIfEz9ai7D6TUr.jpg"
---

# Alice (2009)

![](https://image.tmdb.org/t/p/w500/2lvWLSOPtsqkgVIfEz9ai7D6TUr.jpg)

Alice Hamilton, a fiercely independent twenty-something, watches as her lover Jack Chase is kidnapped and driven into darkness. Desperate to find Jack, Alice puts her trust in a stranger who calls himself White Rabbit and suddenly finds herself on the other side of a looking glass.
