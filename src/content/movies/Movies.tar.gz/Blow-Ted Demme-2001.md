---
type: movie
country: US
title: "Blow"
year: 2001
director: Ted Demme
actors: [Johnny Depp, Penélope Cruz, Franka Potente, Rachel Griffiths, Ray Liotta]
genre: [Crime, Drama]
length: "2h 4m"
shelf: watched
owned: false
rating: 
watched: 2001-04-05
poster: "https://image.tmdb.org/t/p/w500/yYZFVfk8aeMP4GxBSU9MTvqs9mJ.jpg"
---

# Blow (2001)

![](https://image.tmdb.org/t/p/w500/yYZFVfk8aeMP4GxBSU9MTvqs9mJ.jpg)

A boy named George Jung grows up in a struggling family in the 1950's. His mother nags at her husband as he is trying to make a living for the family. It is finally revealed that George's father cannot make a living and the family goes bankrupt. George does not want the same thing to happen to him, and his friend Tuna, in the 1960's, suggests that he deal marijuana. He is a big hit in California in the 1960's, yet he goes to jail, where he finds out about the wonders of cocaine. As a result, when released, he gets rich by bringing cocaine to America. However, he soon pays the price.