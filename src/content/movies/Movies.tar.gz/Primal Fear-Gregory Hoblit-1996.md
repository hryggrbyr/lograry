---
type: movie
country: US
title: "Primal Fear"
year: 1996
director: Gregory Hoblit
actors: [Richard Gere, Laura Linney, Edward Norton, John Mahoney, Alfre Woodard]
genre: [Crime, Drama, Mystery, Thriller]
length: "2h 9m"
shelf: watched
owned: false
rating: 
watched: 2014-10-15
poster: "https://image.tmdb.org/t/p/w500/qJf2TzE8nRTFbFMPJNW6c8mI0KU.jpg"
---

# Primal Fear (1996)

![](https://image.tmdb.org/t/p/w500/qJf2TzE8nRTFbFMPJNW6c8mI0KU.jpg)

An arrogant, high-powered attorney takes on the case of a poor altar boy found running away from the scene of the grisly murder of the bishop who has taken him in. The case gets a lot more complex when the accused reveals that there may or may not have been a third person in the room.