---
type: movie
country: GB
title: "The Hunger"
year: 1983
director: Tony Scott
actors: [Catherine Deneuve, David Bowie, Susan Sarandon, Cliff DeYoung, Beth Ehlers]
genre: [Horror, Drama]
length: "1h 36m"
shelf: watched
owned: false
rating: 
watched: 1983-04-29
poster: "https://image.tmdb.org/t/p/w500/lFTDtRtK8J55A1LTpwigV7QGQg7.jpg"
---

# The Hunger (1983)

![](https://image.tmdb.org/t/p/w500/lFTDtRtK8J55A1LTpwigV7QGQg7.jpg)

Five-thousand-year-old vampire Miriam promises her lovers the gift of eternal life. When John, her cellist companion for centuries, discovers that he has suddenly begun growing old, he attempts to seek out the help of Dr. Sarah Roberts, a researcher on the mechanisms of aging.