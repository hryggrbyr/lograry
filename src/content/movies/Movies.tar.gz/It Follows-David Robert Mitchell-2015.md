---
type: movie
country: US
title: "It Follows"
year: 2015
director: David Robert Mitchell
actors: [Maika Monroe, Keir Gilchrist, Daniel Zovatto, Jake Weary, Olivia Luccardi]
genre: [Horror, Mystery]
length: "1h 41m"
shelf: watched
owned: false
rating: 
watched: 2014-09-24
poster: "https://image.tmdb.org/t/p/w500/iwnQ1JH1wdWrGYkgWySptJ5284A.jpg"
---

# It Follows (2015)

![](https://image.tmdb.org/t/p/w500/iwnQ1JH1wdWrGYkgWySptJ5284A.jpg)

When carefree teenager Jay sleeps with her older boyfriend for the first time, she learns that she is the latest recipient of a fatal curse that is passed from victim to victim via sexual intercourse. Death, Jay learns, will creep inexorably toward her as either a friend or a stranger. Jay's friends don't believe her seemingly paranoid ravings, until they too begin to see the phantom assassins and band together to help her defend herself.