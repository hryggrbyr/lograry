---
type: movie
country: US
title: "The Birds"
year: 1963
director: Alfred Hitchcock
actors: [Tippi Hedren, Rod Taylor, Jessica Tandy, Suzanne Pleshette, Veronica Cartwright]
genre: [Horror, Thriller]
length: "2h 0m"
shelf: watched
owned: false
rating: 
watched: 1963-03-28
poster: "https://image.tmdb.org/t/p/w500/eClg8QPg8mwB6INIC4pyR5pAbDr.jpg"
---

# The Birds (1963)

![](https://image.tmdb.org/t/p/w500/eClg8QPg8mwB6INIC4pyR5pAbDr.jpg)

Thousands of birds flock into a seaside town and terrorize the residents in a series of deadly attacks.