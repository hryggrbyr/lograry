---
type: movie
country: TH
title: "Shutter"
year: 2004
director: Parkpoom Wongpoom, Banjong Pisanthanakun
actors: [Ananda Everingham, Natthaweeranuch Thongmee, Achita Sikamana, Unnop Chanpaibool, Titikarn Tongprasearth]
genre: [Horror, Mystery, Thriller]
length: "1h 37m"
shelf: watched
owned: false
rating: 
watched: 2004-09-09
poster: "https://image.tmdb.org/t/p/w500/zUyaVtyugDaDHtOC6kCMJhbZsWu.jpg"
---

# Shutter (2004)

![](https://image.tmdb.org/t/p/w500/zUyaVtyugDaDHtOC6kCMJhbZsWu.jpg)

After killing a young girl in a hit-and-run accident, a couple is haunted by more than just the memory of their deadly choice.