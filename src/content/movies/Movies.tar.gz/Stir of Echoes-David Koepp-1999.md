---
type: movie
country: US
title: "Stir of Echoes"
year: 1999
director: David Koepp
actors: [Kevin Bacon, Kathryn Erbe, Illeana Douglas, Zachary David Cope, Kevin Dunn]
genre: [Horror, Mystery, Thriller]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 1999-09-10
poster: "https://image.tmdb.org/t/p/w500/9CyJ5aYF27cITX1WSUTENeP4wBE.jpg"
---

# Stir of Echoes (1999)

![](https://image.tmdb.org/t/p/w500/9CyJ5aYF27cITX1WSUTENeP4wBE.jpg)

After being hypnotized by his sister-in-law, Tom Witzky begins seeing haunting visions of a girl's ghost and a mystery begins to unfold around her.