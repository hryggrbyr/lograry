---
type: movie
country: GB
title: "Under the Skin"
year: 2014
director: Jonathan Glazer
actors: [Scarlett Johansson, Jeremy McWilliams, Lynsey Taylor Mackay, Dougie McConnell, Kevin McAlinden]
genre: [Thriller, Science Fiction, Drama]
length: "1h 48m"
shelf: watched
owned: false
rating: 
watched: 2014-04-04
poster: "https://image.tmdb.org/t/p/w500/55wmcXJIDYITr7JDijJTdvwSaAv.jpg"
---

# Under the Skin (2014)

![](https://image.tmdb.org/t/p/w500/55wmcXJIDYITr7JDijJTdvwSaAv.jpg)

A seductive stranger prowls the streets of Glasgow in search of prey: unsuspecting men who fall under her spell.