---
type: movie
country: US
title: "Bullitt"
year: 1968
director: Peter Yates
actors: [Steve McQueen, Robert Vaughn, Jacqueline Bisset, Don Gordon, Robert Duvall]
genre: [Action, Crime, Thriller, Romance, Drama]
length: "1h 53m"
shelf: watched
owned: false
rating: 
watched: 1968-10-17
poster: "https://image.tmdb.org/t/p/w500/2ffzF1WmeXtH420fSUoCrecFvDA.jpg"
---

# Bullitt (1968)

![](https://image.tmdb.org/t/p/w500/2ffzF1WmeXtH420fSUoCrecFvDA.jpg)

Senator Walter Chalmers is aiming to take down mob boss Pete Ross with the help of testimony from the criminal's hothead brother Johnny, who is in protective custody in San Francisco under the watch of police lieutenant Frank Bullitt. When a pair of mob hitmen enter the scene, Bullitt follows their trail through a maze of complications and double-crosses. This thriller includes one of the most famous car chases ever filmed.