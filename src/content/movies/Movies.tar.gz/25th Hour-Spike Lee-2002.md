---
type: movie
country: US
title: "25th Hour"
year: 2002
director: Spike Lee
actors: [Edward Norton, Philip Seymour Hoffman, Barry Pepper, Rosario Dawson, Anna Paquin]
genre: [Crime, Drama]
length: "2h 15m"
shelf: watched
owned: false
rating: 
watched: 2002-12-19
poster: "https://image.tmdb.org/t/p/w500/uW7tTRElr2tRhmAVESzvHy4ByXg.jpg"
---

# 25th Hour (2002)

![](https://image.tmdb.org/t/p/w500/uW7tTRElr2tRhmAVESzvHy4ByXg.jpg)

In New York City in the days following the events of 9/11, Monty Brogan is a convicted drug dealer about to start a seven-year prison sentence, and his final hours of freedom are devoted to hanging out with his closest buddies and trying to prepare his girlfriend for his extended absence.