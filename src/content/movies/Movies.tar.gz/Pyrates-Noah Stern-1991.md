---
type: movie
country: US
title: "Pyrates"
year: 1991
director: Noah Stern
actors: [Kyra Sedgwick, Kevin Bacon, Bruce Payne, Kristin Dattilo, Deborah Falconer]
genre: [Romance, Comedy, Drama]
length: "1h 31m"
shelf: watched
owned: false
rating: 
watched: 1991-12-18
poster: "https://image.tmdb.org/t/p/w500/gPrC6AVW9egAoLCmtFP3h9kXIgU.jpg"
---

# Pyrates (1991)

![](https://image.tmdb.org/t/p/w500/gPrC6AVW9egAoLCmtFP3h9kXIgU.jpg)

As soon as they meet Ari and Sam get into a pretty passionate - and combustible - relationship. Indeed, the scenes of their rendezvous often seem reminiscent of the Chicago Fire. But the course of true flaming lust never runs true, and as they try to handle their all-consuming passion their two best friends endlessly meet to compare notes on developments.