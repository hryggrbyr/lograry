---
type: movie
country: US
title: "Aladdin"
year: 2019
director: Guy Ritchie
actors: [Will Smith, Mena Massoud, Naomi Scott, Marwan Kenzari, Navid Negahban]
genre: [Adventure, Fantasy, Romance, Family]
length: "2h 7m"
shelf: watched
owned: false
rating: 
watched: 2019-05-24
poster: "https://image.tmdb.org/t/p/w500/ykUEbfpkf8d0w49pHh0AD2KrT52.jpg"
---

# Aladdin (2019)

![](https://image.tmdb.org/t/p/w500/ykUEbfpkf8d0w49pHh0AD2KrT52.jpg)

A kindhearted street urchin named Aladdin embarks on a magical adventure after finding a lamp that releases a wisecracking genie while a power-hungry Grand Vizier vies for the same lamp that has the power to make their deepest wishes come true.