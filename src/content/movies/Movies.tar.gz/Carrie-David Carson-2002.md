---
type: movie
country: CA, US
title: "Carrie"
year: 2002
director: David Carson
actors: [Angela Bettis, Patricia Clarkson, Rena Sofer, Kandyse McClure, Emilie de Ravin]
genre: [Horror, Drama, TV Movie]
length: "2h 12m"
shelf: watched
owned: false
rating: 
watched: 2002-11-04
poster: "https://image.tmdb.org/t/p/w500/knjeEeeyIwDkUtZwDfJOcUIuNdB.jpg"
---

# Carrie (2002)

![](https://image.tmdb.org/t/p/w500/knjeEeeyIwDkUtZwDfJOcUIuNdB.jpg)

An awkward, telekinetic teenage girl's lonely life is dominated by relentless bullying at school and an oppressive religious fanatic mother at home. When her tormentors pull a humiliating prank at the senior prom, she unleashes a horrifying chaos on everyone, leaving nothing but destruction in her wake.