---
type: movie
country: US
title: "He's All That"
year: 2021
director: Mark Waters
actors: [Addison Rae, Tanner Buchanan, Madison Pettis, Rachael Leigh Cook, Matthew Lillard]
genre: [Comedy, Romance]
length: "1h 31m"
shelf: watched
owned: false
rating: 
watched: 2021-08-27
poster: "https://image.tmdb.org/t/p/w500/kW3AG5NHoyq52dcSbMiFB6LyHvk.jpg"
---

# He's All That (2021)

![](https://image.tmdb.org/t/p/w500/kW3AG5NHoyq52dcSbMiFB6LyHvk.jpg)

To get revenge on her ex-boyfriend, an influencer attempts to transform an unpopular classmate into prom king.