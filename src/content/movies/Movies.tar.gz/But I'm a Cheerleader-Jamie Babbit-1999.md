---
type: movie
country: United States
title: But I'm a Cheerleader
year: 1999
director: Jamie Babbit
actors: [Natasha Lyonne, Clea DuVall, Michelle Williams]
genre: [Comedy, Drama, Romance]
length: 85
shelf: watched
owned: true
rating: 3
watched: 1999-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMjY2ZDdlNzctMzU4MS00YWNlLWIzYTUtNjMwZjYyMjk0M2UzXkEyXkFqcGc@._V1_SX300.jpg"
---

# But I'm a Cheerleader (1999)

![](https://m.media-amazon.com/images/M/MV5BMjY2ZDdlNzctMzU4MS00YWNlLWIzYTUtNjMwZjYyMjk0M2UzXkEyXkFqcGc@._V1_SX300.jpg)

A naive teenager is sent to rehab camp when her straitlaced parents and friends suspect her of being a lesbian.