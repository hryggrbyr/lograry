---
type: movie
country: JP
title: "Ring"
year: 1998
director: Hideo Nakata
actors: [Nanako Matsushima, Hiroyuki Sanada, Rikiya Ôtaka, Miki Nakatani, Yuko Takeuchi]
genre: [Horror, Thriller]
length: "1h 36m"
shelf: watched
owned: true
rating: 
watched: 1998-01-30
poster: "https://image.tmdb.org/t/p/w500/1YINof6kN5yRdePEbcU5360ejoq.jpg"
---

# Ring (1998)

![](https://image.tmdb.org/t/p/w500/1YINof6kN5yRdePEbcU5360ejoq.jpg)

A mysterious video has been linked to a number of deaths, and when an inquisitive journalist finds the tape and views it herself, she sets in motion a chain of events that puts her own life in danger.