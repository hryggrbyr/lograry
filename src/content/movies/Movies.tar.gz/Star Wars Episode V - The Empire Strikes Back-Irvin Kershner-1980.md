---
type: movie
country: United States
title: Star Wars Episode V - The Empire Strikes Back
year: 1980
director: Irvin Kershner
actors: [Mark Hamill, Harrison Ford, Carrie Fisher]
genre: [Action, Adventure, Fantasy]
length: 124
shelf: watched
owned: false
rating: 
watched: 1989-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMTkxNGFlNDktZmJkNC00MDdhLTg0MTEtZjZiYWI3MGE5NWIwXkEyXkFqcGc@._V1_SX300.jpg"
---

# Star Wars Episode V - The Empire Strikes Back (1980)

![](https://m.media-amazon.com/images/M/MV5BMTkxNGFlNDktZmJkNC00MDdhLTg0MTEtZjZiYWI3MGE5NWIwXkEyXkFqcGc@._V1_SX300.jpg)

After the Empire overpowers the Rebel Alliance, Luke Skywalker begins training with Jedi Master Yoda, while Darth Vader and bounty hunter Boba Fett pursue his friends across the galaxy.