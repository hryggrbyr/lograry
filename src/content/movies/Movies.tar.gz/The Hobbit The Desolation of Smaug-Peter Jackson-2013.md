---
type: movie
country: New Zealand, United States
title: "The Hobbit: The Desolation of Smaug"
year: 2013
director: Peter Jackson
actors: [Ian McKellen, Martin Freeman, Richard Armitage]
genre: [Adventure, Fantasy]
length: 161
shelf: watched
owned: false
rating: 
watched: 2013-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMzU0NDY0NDEzNV5BMl5BanBnXkFtZTgwOTIxNDU1MDE@._V1_SX300.jpg"
---

# The Hobbit: The Desolation of Smaug (2013)

![](https://m.media-amazon.com/images/M/MV5BMzU0NDY0NDEzNV5BMl5BanBnXkFtZTgwOTIxNDU1MDE@._V1_SX300.jpg)

The dwarves, along with Bilbo Baggins and Gandalf the Grey, continue their quest to reclaim the Lonely Mountain, their homeland, from the dragon Smaug.