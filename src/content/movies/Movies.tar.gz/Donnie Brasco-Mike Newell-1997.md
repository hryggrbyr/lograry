---
type: movie
country: US
title: "Donnie Brasco"
year: 1997
director: Mike Newell
actors: [Johnny Depp, Al Pacino, Michael Madsen, Bruno Kirby, James Russo]
genre: [Crime, Drama, Thriller]
length: "2h 7m"
shelf: watched
owned: false
rating: 
watched: 1997-02-24
poster: "https://image.tmdb.org/t/p/w500/xtKLvpOfARi1XVm8u2FTdhY5Piq.jpg"
---

# Donnie Brasco (1997)

![](https://image.tmdb.org/t/p/w500/xtKLvpOfARi1XVm8u2FTdhY5Piq.jpg)

An FBI undercover agent infiltrates the mob and identifies more with the mafia life at the expense of his regular one.