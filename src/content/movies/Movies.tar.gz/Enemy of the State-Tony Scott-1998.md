---
type: movie
country: US
title: "Enemy of the State"
year: 1998
director: Tony Scott
actors: [Will Smith, Gene Hackman, Jon Voight, Regina King, Loren Dean]
genre: [Action, Drama, Thriller]
length: "2h 12m"
shelf: watched
owned: false
rating: 
watched: 1998-11-20
poster: "https://image.tmdb.org/t/p/w500/x9pXrMKLsBGGOFyyZ0Gwt9YpVub.jpg"
---

# Enemy of the State (1998)

![](https://image.tmdb.org/t/p/w500/x9pXrMKLsBGGOFyyZ0Gwt9YpVub.jpg)

The life of labor lawyer and dedicated family man Robert 'Bobby' Dean is turned upside down after a chance meeting with a college buddy while holiday shopping. Unbeknownst to Dean, he's just been burdened with a videotape of a congressman's assassination. Hot on the trail of this tape is a ruthless group of National Security Agents commanded by a belligerently ambitious NSA official named Reynolds. Using satellite surveillance, bugs, and other sophisticated snooping devices, the NSA infiltrates every facet of Dean's existence, tracing each physical and digital footprint he leaves while also framing him for murder. With the help of the mysterious Brill, he attempts to throw the NSA off his trail and prove his innocence.