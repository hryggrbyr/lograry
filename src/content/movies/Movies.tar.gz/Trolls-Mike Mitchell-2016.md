---
type: movie
country: US
title: "Trolls"
year: 2016
director: Mike Mitchell
actors: [Anna Kendrick, Justin Timberlake, Zooey Deschanel, Christopher Mintz-Plasse, Christine Baranski]
genre: [Family, Animation, Fantasy, Adventure, Comedy, Music]
length: "1h 32m"
shelf: watched
owned: false
rating: 
watched: 2016-11-04
poster: "https://image.tmdb.org/t/p/w500/9VlK2j0THZWzhQPq0W3Oc0IIdBB.jpg"
---

# Trolls (2016)

![](https://image.tmdb.org/t/p/w500/9VlK2j0THZWzhQPq0W3Oc0IIdBB.jpg)

After the monstrous Bergens invade Troll Village, Princess Poppy, the happiest Troll ever born, and overly-cautious, curmudgeonly outcast Branch set off on a journey to rescue her friends. Their mission is full of adventure and mishaps, as this mismatched duo try to tolerate each other long enough to get the job done.