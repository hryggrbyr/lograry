---
type: movie
country: France, United States
title: "The Purge"
year: 2013
director: James DeMonaco
actors: [Ethan Hawke, Lena Headey, Max Burkholder]
genre: [Horror, Sci-Fi, Thriller]
length: 85
shelf: watched
owned: false
rating: 
watched: 2013-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMTQzNTcwODEyM15BMl5BanBnXkFtZTcwMjM1MDI0OQ@@._V1_SX300.jpg"
---

# The Purge (2013)

![](https://m.media-amazon.com/images/M/MV5BMTQzNTcwODEyM15BMl5BanBnXkFtZTcwMjM1MDI0OQ@@._V1_SX300.jpg)

A wealthy family is held hostage for harboring the target of a murderous syndicate during the Purge, a 12-hour period in which any and all crime is legal.