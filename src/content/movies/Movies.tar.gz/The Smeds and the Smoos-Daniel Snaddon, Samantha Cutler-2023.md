---
type: movie
country: GB, DE
title: "The Smeds and the Smoos"
year: 2023
director: Daniel Snaddon, Samantha Cutler
actors: [Sally Hawkins, Bill Bailey, Ashna Rabheru, Adjoa Andoh, Daniel Ezra]
genre: [Animation, Family]
length: "25m"
shelf: watched
owned: false
rating: 
watched: 2024-08-10
poster: "https://image.tmdb.org/t/p/w500/9DBDCnuKzZau2Qbab8vHS2xkvQ6.jpg"
---

# The Smeds and the Smoos (2023)

![](https://image.tmdb.org/t/p/w500/9DBDCnuKzZau2Qbab8vHS2xkvQ6.jpg)

In this animated intergalactic adventure, the red Smeds and the blue Smoos must learn to overcome their differences and work together to find young Janet and Bill – who eloped to escape their families’ long standing rivalries.