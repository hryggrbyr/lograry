---
type: series
country: US
title: "The White Princess"
year: 2017
director: Unknown
actors: [Jodie Comer, Rebecca Benson, Jacob Collins-Levy, Kenneth Cranham, Essie Davis]
genre: [Drama, War & Politics]
length: "1 season (8 episodes)"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/8urYFWrEd8ue94Fm4JpHccQg3M7.jpg"
---

# The White Princess (2017)

![](https://image.tmdb.org/t/p/w500/8urYFWrEd8ue94Fm4JpHccQg3M7.jpg)

The story of Elizabeth of York, the White Queen's daughter, and her marriage to the Lancaster victor, Henry VII. Based on the Philippa Gregory book of the same name.
