---
type: movie
country: US
title: "Night of the Living Dead"
year: 1968
director: George A. Romero
actors: [Judith O'Dea, Duane Jones, Marilyn Eastman, Karl Hardman, Judith Ridley]
genre: [Horror, Thriller]
length: "1h 36m"
shelf: watched
owned: false
rating: 
watched: 1968-10-04
poster: "https://image.tmdb.org/t/p/w500/rb2NWyb008u1EcKCOyXs2Nmj0ra.jpg"
---

# Night of the Living Dead (1968)

![](https://image.tmdb.org/t/p/w500/rb2NWyb008u1EcKCOyXs2Nmj0ra.jpg)

A ragtag group barricade themselves in an old Pennsylvania farmhouse to remain safe from a horde of flesh-eating ghouls ravaging the Northeast.