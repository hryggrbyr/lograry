---
type: movie
country: US
title: "Falling for Christmas"
year: 2022
director: Janeen Damian
actors: [Lindsay Lohan, Chord Overstreet, George Young, Jack Wagner, Olivia Perez]
genre: [Romance, Comedy, Family, Christmas]
length: "1h 35m"
shelf: watched
owned: false
rating: 
watched: 2022-11-10
poster: "https://image.tmdb.org/t/p/w500/zgtkXLJagDMlW4iXTCojL5guDeu.jpg"
---

# Falling for Christmas (2022)

![](https://image.tmdb.org/t/p/w500/zgtkXLJagDMlW4iXTCojL5guDeu.jpg)

An engaged, spoiled hotel heiress finds herself in the care of a handsome, blue-collar lodge owner and his precocious daughter after getting amnesia in a skiing accident.