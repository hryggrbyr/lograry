---
type: movie
country: US
title: "Malice"
year: 1993
director: Harold Becker
actors: [Alec Baldwin, Nicole Kidman, Bill Pullman, Bebe Neuwirth, George C. Scott]
genre: [Thriller]
length: "1h 47m"
shelf: watched
owned: false
rating: 
watched: 1993-09-29
poster: "https://image.tmdb.org/t/p/w500/6kcjUrhvHrXSLDLQHvcOvJmLSqs.jpg"
---

# Malice (1993)

![](https://image.tmdb.org/t/p/w500/6kcjUrhvHrXSLDLQHvcOvJmLSqs.jpg)

A tale about a happily married couple who would like to have children. Tracy teaches infants, Andy's a college professor. Things are never the same after she is taken to hospital and operated upon by Jed, a "know all" doctor.