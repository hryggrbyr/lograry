---
type: movie
country: US
title: "Jurassic Park"
year: 1993
director: Steven Spielberg
actors: [Sam Neill, Laura Dern, Jeff Goldblum, Richard Attenborough, Bob Peck]
genre: [Adventure, Science Fiction]
length: "2h 7m"
shelf: watched
owned: false
rating: 
watched: 1993-06-11
poster: "https://image.tmdb.org/t/p/w500/63viWuPfYQjRYLSZSZNq7dglJP5.jpg"
---

# Jurassic Park (1993)

![](https://image.tmdb.org/t/p/w500/63viWuPfYQjRYLSZSZNq7dglJP5.jpg)

A wealthy entrepreneur secretly creates a theme park featuring living dinosaurs drawn from prehistoric DNA. Before opening day, he invites a team of experts and his two eager grandchildren to experience the park and help calm anxious investors. However, the park is anything but amusing as the security systems go off-line and the dinosaurs escape.