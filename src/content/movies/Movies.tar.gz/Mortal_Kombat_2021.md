---
type: movie
country: AU, CA, US
title: "Mortal Kombat"
year: 2021
director: Simon McQuoid
actors: [Lewis Tan, Jessica McNamee, Mehcad Brooks, Josh Lawson, Ludi Lin]
genre: [Action, Fantasy, Adventure]
length: "1h 50m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/ybrX94xQm8lXYpZAPRmwD9iIbWP.jpg"
---

# Mortal Kombat (2021)

![](https://image.tmdb.org/t/p/w500/ybrX94xQm8lXYpZAPRmwD9iIbWP.jpg)

Washed-up MMA fighter Cole Young, unaware of his heritage, and hunted by Emperor Shang Tsung's best warrior, Sub-Zero, seeks out and trains with Earth's greatest champions as he prepares to stand against the enemies of Outworld in a high stakes battle for the universe.
