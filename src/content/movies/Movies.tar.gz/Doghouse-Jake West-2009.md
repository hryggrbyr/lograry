---
type: movie
country: GB
title: "Doghouse"
year: 2009
director: Jake West
actors: [Stephen Graham, Danny Dyer, Noel Clarke, Emil Marwa, Lee Ingleby]
genre: [Comedy, Horror]
length: "1h 29m"
shelf: watched
owned: false
rating: 
watched: 2009-06-12
poster: "https://image.tmdb.org/t/p/w500/8XBd0TLZRcnSpbeEyoYRxxDCafJ.jpg"
---

# Doghouse (2009)

![](https://image.tmdb.org/t/p/w500/8XBd0TLZRcnSpbeEyoYRxxDCafJ.jpg)

A group of men, heading to a remote village to help one of their friends get over his divorce, soon discover that all the women have been infected with a virus that makes them man-hating cannibals.