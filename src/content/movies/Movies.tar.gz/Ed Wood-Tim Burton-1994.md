---
type: movie
country: US
title: "Ed Wood"
year: 1994
director: Tim Burton
actors: [Johnny Depp, Martin Landau, Sarah Jessica Parker, Patricia Arquette, Jeffrey Jones]
genre: [Comedy, Drama, History]
length: "2h 7m"
shelf: watched
owned: false
rating: 
watched: 1994-09-27
poster: "https://image.tmdb.org/t/p/w500/2jjFN4BtTSz01J3ZD4iYjf26pWX.jpg"
---

# Ed Wood (1994)

![](https://image.tmdb.org/t/p/w500/2jjFN4BtTSz01J3ZD4iYjf26pWX.jpg)

The mostly true story of the legendary "worst director of all time", who, with the help of his strange friends, filmed countless B-movies without ever becoming famous or successful.