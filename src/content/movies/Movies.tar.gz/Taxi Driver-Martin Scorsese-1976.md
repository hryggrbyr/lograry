---
type: movie
country: US
title: "Taxi Driver"
year: 1976
director: Martin Scorsese
actors: [Robert De Niro, Jodie Foster, Cybill Shepherd, Harvey Keitel, Peter Boyle]
genre: [Crime, Drama]
length: "1h 54m"
shelf: watched
owned: false
rating: 
watched: 1976-02-09
poster: "https://image.tmdb.org/t/p/w500/ekstpH614fwDX8DUln1a2Opz0N8.jpg"
---

# Taxi Driver (1976)

![](https://image.tmdb.org/t/p/w500/ekstpH614fwDX8DUln1a2Opz0N8.jpg)

A mentally unstable Vietnam War veteran works as a night-time taxi driver in New York City where the perceived decadence and sleaze feed his urge for violent action.