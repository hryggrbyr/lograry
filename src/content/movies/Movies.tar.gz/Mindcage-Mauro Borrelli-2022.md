---
type: movie
country: US
title: "Mindcage"
year: 2022
director: Mauro Borrelli
actors: [Martin Lawrence, Melissa Roxburgh, John Malkovich, Aiden Turner, Jacob Grodnik]
genre: [Mystery, Thriller, Crime]
length: "1h 37m"
shelf: watched
owned: false
rating: 
watched: 2023-04-23
poster: "https://image.tmdb.org/t/p/w500/fUi9vNYQaB8QtrbEyS9J6vbKJJt.jpg"
---

# Mindcage (2022)

![](https://image.tmdb.org/t/p/w500/fUi9vNYQaB8QtrbEyS9J6vbKJJt.jpg)

Detectives Jake Doyle and Mary Kelly seek the help of an incarcerated serial killer named The Artist when a copycat killer strikes. While Mary searches for clues in The Artist's brilliant but twisted psyche, she and Jake are lured into a diabolical game of cat and mouse, racing against time to stay one step ahead of The Artist and his copycat.