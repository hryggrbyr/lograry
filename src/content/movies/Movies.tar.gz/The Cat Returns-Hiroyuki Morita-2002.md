---
type: movie
country: JP
title: "The Cat Returns"
year: 2002
director: Hiroyuki Morita
actors: [Chizuru Ikewaki, Yoshihiko Hakamada, Aki Maeda, Tetsu Watanabe, Yousuke Saito]
genre: [Adventure, Fantasy, Animation, Drama, Family]
length: "1h 15m"
shelf: watched
owned: false
rating: 
watched: 2002-07-19
poster: "https://image.tmdb.org/t/p/w500/pqyY7IEWkCWNZ7EuRStQaJITEta.jpg"
---

# The Cat Returns (2002)

![](https://image.tmdb.org/t/p/w500/pqyY7IEWkCWNZ7EuRStQaJITEta.jpg)

Young Haru rescues a cat from being run over, but soon learns it's no ordinary feline; it happens to be the Prince of the Cats.