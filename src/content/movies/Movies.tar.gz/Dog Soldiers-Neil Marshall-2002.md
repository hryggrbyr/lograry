---
type: movie
country: GB, LU
title: "Dog Soldiers"
year: 2002
director: Neil Marshall
actors: [Sean Pertwee, Kevin McKidd, Emma Cleasby, Liam Cunningham, Thomas Lockyer]
genre: [Horror, Action, Thriller]
length: "1h 45m"
shelf: watched
owned: false
rating: 
watched: 2002-11-05
poster: "https://image.tmdb.org/t/p/w500/fYHUYWglzq8Ax0EaDWqg9emjL7T.jpg"
---

# Dog Soldiers (2002)

![](https://image.tmdb.org/t/p/w500/fYHUYWglzq8Ax0EaDWqg9emjL7T.jpg)

A band of soldiers is dispatched to war games deep in the woods. When they stumble across a rival team slaughtered in camp, they realize they're not alone.