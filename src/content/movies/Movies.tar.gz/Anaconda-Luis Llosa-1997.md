---
type: movie
country: US
title: "Anaconda"
year: 1997
director: Luis Llosa
actors: [Jennifer Lopez, Ice Cube, Jon Voight, Eric Stoltz, Jonathan Hyde]
genre: [Adventure, Horror, Thriller]
length: "1h 29m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/33NysOnLpLZY0ewHTcfpalzAsRG.jpg"
---

# Anaconda (1997)

![](https://image.tmdb.org/t/p/w500/33NysOnLpLZY0ewHTcfpalzAsRG.jpg)

A 'National Geographic' film crew is taken hostage by an insane hunter, who takes them along on his quest to capture the world's largest — and deadliest — snake.