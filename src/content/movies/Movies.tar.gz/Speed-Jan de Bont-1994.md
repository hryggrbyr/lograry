---
type: movie
country: US
title: "Speed"
year: 1994
director: Jan de Bont
actors: [Keanu Reeves, Dennis Hopper, Sandra Bullock, Joe Morton, Jeff Daniels]
genre: [Action, Thriller]
length: "1h 56m"
shelf: watched
owned: false
rating: 
watched: 1994-06-09
poster: "https://image.tmdb.org/t/p/w500/o1Zs7VaS9y2GYH9CLeWxaVLWd3x.jpg"
---

# Speed (1994)

![](https://image.tmdb.org/t/p/w500/o1Zs7VaS9y2GYH9CLeWxaVLWd3x.jpg)

Jack Traven, an LAPD cop on SWAT detail, and veteran SWAT officer Harry Temple thwart an extortionist-bomber's scheme for a $3 million ransom. As they corner the bomber, he flees and detonates a bomb vest, seemingly killing himself. Weeks later, Jack witnesses a mass transit city bus explode and nearby a pay phone rings. On the phone is that same bomber looking for vengeance and the money he's owed. He gives a personal challenge to Jack: a bomb is rigged on another city bus - if it slows down below 50 mph, it will explode - bad enough any day, but a nightmare in LA traffic. And that's just the beginning...