---
type: movie
country: US
title: "One Hour Photo"
year: 2002
director: Mark Romanek
actors: [Robin Williams, Connie Nielsen, Michael Vartan, Gary Cole, Erin Daniels]
genre: [Drama, Thriller]
length: "1h 36m"
shelf: watched
owned: false
rating: 
watched: 2002-08-21
poster: "https://image.tmdb.org/t/p/w500/fuSIN3Nq6dmaA8LZSkASpQueFO1.jpg"
---

# One Hour Photo (2002)

![](https://image.tmdb.org/t/p/w500/fuSIN3Nq6dmaA8LZSkASpQueFO1.jpg)

Sy "the photo guy" Parrish has lovingly developed photos for the Yorkin family since their son was a baby. But as the Yorkins' lives become fuller, Sy's only seems lonelier, until he eventually believes he's part of their family. When "Uncle" Sy's picture-perfect fantasy collides with an ugly dose of reality, what happens next "has the spine-tingling elements of the best psychological thrillers!"