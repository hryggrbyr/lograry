---
type: movie
country: GB
title: "Tabby McTat"
year: 2024
director: Sarah Scrimgeour, Jac Hamman
actors: [Jodie Whittaker, Rob Brydon, Ṣọpẹ́ Dìrísù, Susan Wokoma, Joanna Scanlan]
genre: [Family, Animation]
length: "25m"
shelf: watched
owned: false
rating: 
watched: 2024-07-27
poster: "https://image.tmdb.org/t/p/w500/o8Ob85i772akIhwUlkBWpu5yRUu.jpg"
---

# Tabby McTat (2024)

![](https://image.tmdb.org/t/p/w500/o8Ob85i772akIhwUlkBWpu5yRUu.jpg)

Busker Fred and his cat Tabby McTat entertain and delight passersby with music across London. One day, Fred falls, injures his leg, and is whisked away in an ambulance, leaving Tabby alone on the city's streets.