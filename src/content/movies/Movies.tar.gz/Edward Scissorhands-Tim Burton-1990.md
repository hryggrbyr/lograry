---
type: movie
country: US
title: "Edward Scissorhands"
year: 1990
director: Tim Burton
actors: [Johnny Depp, Winona Ryder, Dianne Wiest, Anthony Michael Hall, Kathy Baker]
genre: [Fantasy, Drama, Romance]
length: "1h 45m"
shelf: watched
owned: false
rating: 
watched: 1990-12-07
poster: "https://image.tmdb.org/t/p/w500/e0FqKFvGPdQNWG8tF9cZBtev9Em.jpg"
---

# Edward Scissorhands (1990)

![](https://image.tmdb.org/t/p/w500/e0FqKFvGPdQNWG8tF9cZBtev9Em.jpg)

A small suburban town receives a visit from a castaway unfinished science experiment named Edward.