---
type: movie
country: US
title: "Pi"
year: 1998
director: Darren Aronofsky
actors: [Sean Gullette, Mark Margolis, Ben Shenkman, Pamela Hart, Stephen Pearlman]
genre: [Mystery, Drama, Thriller]
length: "1h 24m"
shelf: watched
owned: false
rating: 
watched: 1998-07-10
poster: "https://image.tmdb.org/t/p/w500/fJA22FjlAW8rzrOw9Mwanl6oTc9.jpg"
---

# Pi (1998)

![](https://image.tmdb.org/t/p/w500/fJA22FjlAW8rzrOw9Mwanl6oTc9.jpg)

A mathematical genius discovers a link between numbers and reality, and thus believes he can predict the future.