---
type: movie
country: United States
title: "Extremely Loud & Incredibly Close"
year: 2011
director: Stephen Daldry
actors: [Thomas Horn, Tom Hanks, Sandra Bullock]
genre: [Adventure, Drama, Mystery]
length: 129
shelf: watchlist
owned: false
rating: 
watched: 
poster: "https://m.media-amazon.com/images/M/MV5BMTUxNzYwMTE3NV5BMl5BanBnXkFtZTcwMDY2NzU4Ng@@._V1_SX300.jpg"
---

# Extremely Loud & Incredibly Close (2011)

![](https://m.media-amazon.com/images/M/MV5BMTUxNzYwMTE3NV5BMl5BanBnXkFtZTcwMDY2NzU4Ng@@._V1_SX300.jpg)

A nine-year-old amateur inventor, Francophile, and pacifist searches New York City for the lock that matches a mysterious key left behind by his father, who died in the World Trade Center on September 11, 2001.