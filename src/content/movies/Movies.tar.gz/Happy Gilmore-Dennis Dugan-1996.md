---
type: movie
country: US
title: "Happy Gilmore"
year: 1996
director: Dennis Dugan
actors: [Adam Sandler, Christopher McDonald, Julie Bowen, Frances Bay, Carl Weathers]
genre: [Comedy]
length: "1h 32m"
shelf: watched
owned: false
rating: 
watched: 1996-02-16
poster: "https://image.tmdb.org/t/p/w500/epFP29rGrLPseuKxpz3mGKr23Do.jpg"
---

# Happy Gilmore (1996)

![](https://image.tmdb.org/t/p/w500/epFP29rGrLPseuKxpz3mGKr23Do.jpg)

Failed hockey player-turned-golf whiz Happy Gilmore — whose unconventional approach and antics on the green courts the ire of rival Shooter McGavin — is determined to win a PGA tournament so he can save his granny's house with the prize money. Meanwhile, an attractive tour publicist tries to soften Happy's image.