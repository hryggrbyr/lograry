---
type: movie
country: US
title: "The Irishman"
year: 2019
director: Martin Scorsese
actors: [Robert De Niro, Al Pacino, Joe Pesci, Harvey Keitel, Ray Romano]
genre: [Crime, Drama, History]
length: "3h 29m"
shelf: watched
owned: false
rating: 
watched: 2019-11-01
poster: "https://image.tmdb.org/t/p/w500/mbm8k3GFhXS0ROd9AD1gqYbIFbM.jpg"
---

# The Irishman (2019)

![](https://image.tmdb.org/t/p/w500/mbm8k3GFhXS0ROd9AD1gqYbIFbM.jpg)

Pennsylvania, 1956. Frank Sheeran, a war veteran of Irish origin who works as a truck driver, accidentally meets mobster Russell Bufalino. Once Frank becomes his trusted man, Bufalino sends him to Chicago with the task of helping Jimmy Hoffa, a powerful union leader related to organized crime, with whom Frank will maintain a close friendship for nearly twenty years.