---
type: movie
country: AU
title: "Dead Calm"
year: 1989
director: Phillip Noyce
actors: [Nicole Kidman, Sam Neill, Billy Zane, George Shevtsov, Rod Mullinar]
genre: [Thriller, Horror]
length: "1h 36m"
shelf: watched
owned: false
rating: 
watched: 1989-05-25
poster: "https://image.tmdb.org/t/p/w500/hXpav86ZX5N1YIfVfVtzuZLNrjW.jpg"
---

# Dead Calm (1989)

![](https://image.tmdb.org/t/p/w500/hXpav86ZX5N1YIfVfVtzuZLNrjW.jpg)

An Australian couple takes a sailing trip in the Pacific to get over the recent loss of their son. While on the open sea, they come across a sinking ship with one survivor who is not at all what he seems.