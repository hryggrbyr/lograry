---
type: movie
country: US
title: "Arsenic and Old Lace"
year: 1944
director: Frank Capra
actors: [Cary Grant, Priscilla Lane, Josephine Hull, Jean Adair, Raymond Massey]
genre: [Comedy, Crime]
length: "1h 58m"
shelf: watched
owned: false
rating: 
watched: 1944-09-01
poster: "https://image.tmdb.org/t/p/w500/xG1GEEQGgExKl0WT5sRo1Arst5D.jpg"
---

# Arsenic and Old Lace (1944)

![](https://image.tmdb.org/t/p/w500/xG1GEEQGgExKl0WT5sRo1Arst5D.jpg)

Mortimer Brewster, a newspaper drama critic, playwright, and author known for his diatribes against marriage, suddenly falls in love and gets married;  but when he makes a quick trip home to tell his two maiden aunts, he finds out his aunts' hobby - killing lonely old men and burying them in the cellar!