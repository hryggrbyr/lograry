---
type: movie
country: US, CA
title: "Prozac Nation"
year: 2001
director: Erik Skjoldbjærg
actors: [Christina Ricci, Jason Biggs, Anne Heche, Michelle Williams, Jonathan Rhys Meyers]
genre: [Drama, Romance]
length: "1h 35m"
shelf: watched
owned: false
rating: 
watched: 2003-08-22
poster: "https://image.tmdb.org/t/p/w500/4QB1h6mxlmQVM8BtYMybTwL2foc.jpg"
---

# Prozac Nation (2001)

![](https://image.tmdb.org/t/p/w500/4QB1h6mxlmQVM8BtYMybTwL2foc.jpg)

When talented young writer Elizabeth Wurtzel earns a scholarship to Harvard, she sees it as her chance to escape the pressures of her working-class background and concentrate on her true talent. But what starts out so promising leads to self-destructive behavior and paralyzing depression that reflects an entire generation's struggle to navigate the effects of divorce, drugs, sex, and high expectations.