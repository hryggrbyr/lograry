---
type: movie
country: US
title: "JFK"
year: 1991
director: Oliver Stone
actors: [Kevin Costner, Tommy Lee Jones, Gary Oldman, Kevin Bacon, Michael Rooker]
genre: [Drama, Thriller, History]
length: "3h 9m"
shelf: watched
owned: false
rating: 
watched: 1991-12-20
poster: "https://image.tmdb.org/t/p/w500/r0VWVTYlqdRCK5ZoOdNnHdqM2gt.jpg"
---

# JFK (1991)

![](https://image.tmdb.org/t/p/w500/r0VWVTYlqdRCK5ZoOdNnHdqM2gt.jpg)

Follows the investigation into the assassination of President John F. Kennedy led by New Orleans district attorney Jim Garrison.