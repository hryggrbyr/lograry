---
type: movie
country: United States
title: "Sugar & Spice"
year: 2001
director: Francine McDougall
actors: [Marla Sokoloff, Marley Shelton, Melissa George]
genre: [Comedy, Crime]
length: 81
shelf: watched
owned: true
rating: 
watched: 2001-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMTc4MTg3ZmUtNmQ4Ny00MjcyLThkMDEtZGI2OTc4Y2EwOTc2XkEyXkFqcGc@._V1_SX300.jpg"
---

# Sugar & Spice (2001)

![](https://m.media-amazon.com/images/M/MV5BMTc4MTg3ZmUtNmQ4Ny00MjcyLThkMDEtZGI2OTc4Y2EwOTc2XkEyXkFqcGc@._V1_SX300.jpg)

A popular high-school cheerleader becomes pregnant by the star quarterback and turns to crime to support her desired lifestyle.