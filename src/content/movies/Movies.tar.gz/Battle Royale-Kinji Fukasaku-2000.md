---
type: movie
country: JP
title: "Battle Royale"
year: 2000
director: Kinji Fukasaku
actors: [Tatsuya Fujiwara, Aki Maeda, Takeshi Kitano, Taro Yamamoto, Masanobu Ando]
genre: [Drama, Thriller, Action]
length: "1h 53m"
shelf: watched
owned: false
rating: 
watched: 2000-12-16
poster: "https://image.tmdb.org/t/p/w500/gFX7NuBUeKysOB9nEzRqVpHNT32.jpg"
---

# Battle Royale (2000)

![](https://image.tmdb.org/t/p/w500/gFX7NuBUeKysOB9nEzRqVpHNT32.jpg)

In the future, the Japanese government captures a class of ninth-grade students and forces them to kill each other under the revolutionary "Battle Royale" act.