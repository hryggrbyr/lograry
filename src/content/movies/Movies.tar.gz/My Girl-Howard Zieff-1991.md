---
type: movie
country: US
title: "My Girl"
year: 1991
director: Howard Zieff
actors: [Anna Chlumsky, Macaulay Culkin, Dan Aykroyd, Jamie Lee Curtis, Richard Masur]
genre: [Comedy, Drama]
length: "1h 43m"
shelf: watched
owned: false
rating: 
watched: 1991-11-27
poster: "https://image.tmdb.org/t/p/w500/qyJJNHteA7BUwQSey05t7qP4vRV.jpg"
---

# My Girl (1991)

![](https://image.tmdb.org/t/p/w500/qyJJNHteA7BUwQSey05t7qP4vRV.jpg)

Vada Sultenfuss is obsessed with death. Her mother is dead, and her father runs a funeral parlor. She is also in love with her English teacher, and joins a poetry class over the summer just to impress him. Thomas J., her best friend, is "allergic to everything", and sticks with Vada despite her hangups. When Vada's father hires Shelly, and begins to fall for her, things take a turn to the worse...