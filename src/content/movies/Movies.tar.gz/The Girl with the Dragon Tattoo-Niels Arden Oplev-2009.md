---
type: movie
country: DK, DE, NO, SE
title: "The Girl with the Dragon Tattoo"
year: 2009
director: Niels Arden Oplev
actors: [Michael Nyqvist, Noomi Rapace, Lena Endre, Sven-Bertil Taube, Peter Haber]
genre: [Drama, Thriller, Crime, Mystery]
length: "2h 32m"
shelf: watched
owned: false
rating: 
watched: 2009-02-27
poster: "https://image.tmdb.org/t/p/w500/6w0TKhfR0Rzby5SXxgfuI99Jrva.jpg"
---

# The Girl with the Dragon Tattoo (2009)

![](https://image.tmdb.org/t/p/w500/6w0TKhfR0Rzby5SXxgfuI99Jrva.jpg)

Swedish thriller based on Stieg Larsson's novel about a male journalist and a young female hacker. In the opening of the movie, Mikael Blomkvist, a middle-aged publisher for the magazine Millennium, loses a libel case brought by corrupt Swedish industrialist Hans-Erik Wennerström. Nevertheless, he is hired by Henrik Vanger in order to solve a cold case, the disappearance of Vanger's niece