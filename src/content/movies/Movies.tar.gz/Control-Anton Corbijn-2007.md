---
type: movie
country: GB
title: "Control"
year: 2007
director: Anton Corbijn
actors: [Sam Riley, Samantha Morton, Alexandra Maria Lara, Joe Anderson, Toby Kebbell]
genre: [Drama]
length: "2h 1m"
shelf: watched
owned: false
rating: 
watched: 2007-10-10
poster: "https://image.tmdb.org/t/p/w500/jOJiaOhwrDdwqTRZvZOhbndqHGp.jpg"
---

# Control (2007)

![](https://image.tmdb.org/t/p/w500/jOJiaOhwrDdwqTRZvZOhbndqHGp.jpg)

The story of Joy Division’s lead singer Ian Curtis, from his schoolboy days in 1973 to his suicide on the eve of the band's first American tour in 1980.