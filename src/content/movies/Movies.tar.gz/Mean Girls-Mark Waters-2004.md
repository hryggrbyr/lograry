---
type: movie
country: US
title: "Mean Girls"
year: 2004
director: Mark Waters
actors: [Lindsay Lohan, Rachel McAdams, Lizzy Caplan, Lacey Chabert, Amanda Seyfried]
genre: [Drama, Comedy]
length: "1h 36m"
shelf: watched
owned: true
rating: 
watched: 2023-08-23
poster: "https://image.tmdb.org/t/p/w500/2ZkuQXvVhh45uSvkBej4S7Ix1NJ.jpg"
---

# Mean Girls (2004)

![](https://image.tmdb.org/t/p/w500/2ZkuQXvVhh45uSvkBej4S7Ix1NJ.jpg)

Cady Heron is a hit with The Plastics, the A-list girl clique at her new school, until she makes the mistake of falling for Aaron Samuels, the ex-boyfriend of alpha Plastic Regina George.