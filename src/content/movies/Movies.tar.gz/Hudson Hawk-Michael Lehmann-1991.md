---
type: movie
country: US
title: "Hudson Hawk"
year: 1991
director: Michael Lehmann
actors: [Bruce Willis, Danny Aiello, Andie MacDowell, James Coburn, Richard E. Grant]
genre: [Action, Adventure, Comedy]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 1991-05-23
poster: "https://image.tmdb.org/t/p/w500/2AiR7HZuIOUdJp6LYOEOA8z7pF3.jpg"
---

# Hudson Hawk (1991)

![](https://image.tmdb.org/t/p/w500/2AiR7HZuIOUdJp6LYOEOA8z7pF3.jpg)

Eddie Hawkins, called Hudson Hawk has just been released from ten years of prison and is planning to spend the rest of his life honestly. But then the crazy Mayflower couple blackmail him to steal some of the works of Leonardo da Vinci. If he refuses, they threaten to kill his friend Tommy.