---
type: movie
country: US
title: "Shutter"
year: 2008
director: Masayuki Ochiai
actors: [Joshua Jackson, Rachael Taylor, Megumi Okina, David Denman, Elly Otoguro]
genre: [Horror, Mystery, Thriller]
length: "1h 25m"
shelf: watched
owned: false
rating: 
watched: 2008-03-21
poster: "https://image.tmdb.org/t/p/w500/bft6OyITsxSZuTxu2oJipApLran.jpg"
---

# Shutter (2008)

![](https://image.tmdb.org/t/p/w500/bft6OyITsxSZuTxu2oJipApLran.jpg)

A newly married couple discovers disturbing, ghostly images in photographs they develop after a tragic accident. Fearing the manifestations may be connected, they investigate and learn that some mysteries are better left unsolved.