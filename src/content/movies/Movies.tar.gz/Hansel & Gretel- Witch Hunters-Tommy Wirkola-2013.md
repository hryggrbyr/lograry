---
type: movie
country: US
title: "Hansel & Gretel: Witch Hunters"
year: 2013
director: Tommy Wirkola
actors: [Jeremy Renner, Gemma Arterton, Famke Janssen, Pihla Viitala, Derek Mears]
genre: [Fantasy, Horror, Action]
length: "1h 28m"
shelf: watched
owned: false
rating: 
watched: 2013-01-25
poster: "https://image.tmdb.org/t/p/w500/j343Rpj3WeNvP0SV80zveve70io.jpg"
---

# Hansel & Gretel: Witch Hunters (2013)

![](https://image.tmdb.org/t/p/w500/j343Rpj3WeNvP0SV80zveve70io.jpg)

After getting a taste for blood as children, Hansel and Gretel have become the ultimate vigilantes, hell-bent on retribution. Now, unbeknownst to them, Hansel and Gretel have become the hunted, and must face an evil far greater than witches... their past.