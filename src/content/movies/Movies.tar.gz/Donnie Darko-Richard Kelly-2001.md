---
type: movie
country: US
title: "Donnie Darko"
year: 2001
director: Richard Kelly
actors: [Jake Gyllenhaal, Jena Malone, James Duval, Drew Barrymore, Beth Grant]
genre: [Fantasy, Drama, Mystery]
length: "1h 54m"
shelf: watched
owned: false
rating: 
watched: 2001-10-26
poster: "https://image.tmdb.org/t/p/w500/fhQoQfejY1hUcwyuLgpBrYs6uFt.jpg"
---

# Donnie Darko (2001)

![](https://image.tmdb.org/t/p/w500/fhQoQfejY1hUcwyuLgpBrYs6uFt.jpg)

After narrowly escaping a bizarre accident, a troubled teenager is plagued by visions of a large bunny rabbit that manipulates him to commit a series of crimes.