---
type: movie
country: United States, United Kingdom
title: "The Fanatic"
year: 2019
director: Fred Durst
actors: [John Travolta, Devon Sawa, Ana Golja]
genre: [Crime, Drama, Mystery]
length: 88
shelf: watched
owned: false
rating: 
watched: 2019-12-31
poster: "https://m.media-amazon.com/images/M/MV5BYjc5MzM2NzItZGFkYS00ZTU5LTg5MjctN2U1NjczNzg2MjAyXkEyXkFqcGc@._V1_SX300.jpg"
---

# The Fanatic (2019)

![](https://m.media-amazon.com/images/M/MV5BYjc5MzM2NzItZGFkYS00ZTU5LTg5MjctN2U1NjczNzg2MjAyXkEyXkFqcGc@._V1_SX300.jpg)

A rabid film fan stalks his favorite action hero and destroys his life.