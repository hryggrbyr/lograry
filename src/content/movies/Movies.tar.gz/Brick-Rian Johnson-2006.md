---
type: movie
country: US
title: "Brick"
year: 2006
director: Rian Johnson
actors: [Joseph Gordon-Levitt, Emilie de Ravin, Nora Zehetner, Lukas Haas, Noah Fleiss]
genre: [Drama, Mystery]
length: "1h 50m"
shelf: watched
owned: false
rating: 
watched: 2006-03-31
poster: "https://image.tmdb.org/t/p/w500/5WVk8JpNIxepn4fpZzQeCumkOL5.jpg"
---

# Brick (2006)

![](https://image.tmdb.org/t/p/w500/5WVk8JpNIxepn4fpZzQeCumkOL5.jpg)

A teenage loner pushes his way into the underworld of a high school crime ring to investigate the disappearance of his ex-girlfriend.