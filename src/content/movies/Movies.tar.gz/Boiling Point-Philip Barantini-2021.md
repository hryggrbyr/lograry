---
type: movie
country: GB
title: "Boiling Point"
year: 2021
director: Philip Barantini
actors: [Stephen Graham, Vinette Robinson, Alice May Feetham, Jason Flemyng, Hannah Walters]
genre: [Drama, Thriller]
length: "1h 35m"
shelf: watched
owned: false
rating: 
watched: 2022-01-05
poster: "https://image.tmdb.org/t/p/w500/kdkk7OBnIL1peW2zwcAAp6O54Jo.jpg"
---

# Boiling Point (2021)

![](https://image.tmdb.org/t/p/w500/kdkk7OBnIL1peW2zwcAAp6O54Jo.jpg)

A head chef balances multiple personal and professional crises at a popular restaurant in London.