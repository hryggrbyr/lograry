---
type: movie
country: United Kingdom, Canada
title: "The Ritual"
year: 2017
director: David Bruckner
actors: [Rafe Spall, Arsher Ali, Robert James-Collier]
genre: [Horror, Mystery, Thriller]
length: 94
shelf: watched
owned: false
rating: 
watched: 2017-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMjAzMzAyMDI4Ml5BMl5BanBnXkFtZTgwODMwOTY2NDM@._V1_SX300.jpg"
---

# The Ritual (2017)

![](https://m.media-amazon.com/images/M/MV5BMjAzMzAyMDI4Ml5BMl5BanBnXkFtZTgwODMwOTY2NDM@._V1_SX300.jpg)

A group of old college friends reunite for a trip to a most dangerous country in Europe - Sweden, encountering a menacing presence there stalking them.