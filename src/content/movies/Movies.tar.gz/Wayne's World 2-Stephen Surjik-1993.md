---
type: movie
country: United States
title: Wayne's World 2
year: 1993
director: Stephen Surjik
actors: [Mike Myers, Dana Carvey, Christopher Walken]
genre: [Comedy, Music]
length: 95
shelf: watched
owned: false
rating: 
watched: 1993-12-31
poster: "https://m.media-amazon.com/images/M/MV5BZTBmNzQ0OGUtYWY5ZC00ZjBhLTkwMzQtNjUxZGVlYTczMjEwXkEyXkFqcGc@._V1_SX300.jpg"
---

# Wayne's World 2 (1993)

![](https://m.media-amazon.com/images/M/MV5BZTBmNzQ0OGUtYWY5ZC00ZjBhLTkwMzQtNjUxZGVlYTczMjEwXkEyXkFqcGc@._V1_SX300.jpg)

The inseparable duo try to organize a rock concert while Wayne must fend off a record producer who has an eye for his girlfriend.