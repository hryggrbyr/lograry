---
type: movie
country: US
title: "The Shining"
year: 1980
director: Stanley Kubrick
actors: [Jack Nicholson, Shelley Duvall, Danny Lloyd, Scatman Crothers, Barry Nelson]
genre: [Horror, Thriller]
length: "2h 24m"
shelf: watched
owned: true
rating: 5
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/xazWoLealQwEgqZ89MLZklLZD3k.jpg"
---

# The Shining (1980)

![](https://image.tmdb.org/t/p/w500/xazWoLealQwEgqZ89MLZklLZD3k.jpg)

Jack Torrance accepts a caretaker job at the Overlook Hotel, where he, along with his wife Wendy and their son Danny, must live isolated from the rest of the world for the winter. But they aren't prepared for the madness that lurks within.