---
type: movie
country: US
title: "Wall Street"
year: 1987
director: Oliver Stone
actors: [Michael Douglas, Charlie Sheen, Martin Sheen, Daryl Hannah, John C. McGinley]
genre: [Crime, Drama]
length: "2h 6m"
shelf: watched
owned: false
rating: 
watched: 1987-12-10
poster: "https://image.tmdb.org/t/p/w500/2tQYq9ntzn2dEwDIGLBSipYPenv.jpg"
---

# Wall Street (1987)

![](https://image.tmdb.org/t/p/w500/2tQYq9ntzn2dEwDIGLBSipYPenv.jpg)

A young and impatient stockbroker is willing to do anything to get to the top, including trading on illegal inside information taken through a ruthless and greedy corporate raider, whom takes the youth under his wing.