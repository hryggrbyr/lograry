---
type: movie
country: US
title: "The Others"
year: 2001
director: Alejandro Amenábar
actors: [Nicole Kidman, Alakina Mann, Fionnula Flanagan, James Bentley, Eric Sykes]
genre: [Horror, Mystery, Thriller]
length: "1h 44m"
shelf: watched
owned: false
rating: 
watched: 2001-08-10
poster: "https://image.tmdb.org/t/p/w500/p8g1vlTvpM6nr2hMMiZ1fUlKF0D.jpg"
---

# The Others (2001)

![](https://image.tmdb.org/t/p/w500/p8g1vlTvpM6nr2hMMiZ1fUlKF0D.jpg)

Grace is a religious woman who lives in an old house kept dark because her two children, Anne and Nicholas, have a rare sensitivity to light. When the family begins to suspect the house is haunted, Grace fights to protect her children at any cost in the face of strange events and disturbing visions.