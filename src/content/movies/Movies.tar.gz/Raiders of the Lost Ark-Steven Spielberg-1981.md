---
type: movie
country: US
title: "Raiders of the Lost Ark"
year: 1981
director: Steven Spielberg
actors: [Harrison Ford, Karen Allen, Paul Freeman, John Rhys-Davies, Ronald Lacey]
genre: [Adventure, Action]
length: "1h 55m"
shelf: watched
owned: false
rating: 
watched: 2023-07-01
poster: "https://image.tmdb.org/t/p/w500/ceG9VzoRAVGwivFU403Wc3AHRys.jpg"
---

# Raiders of the Lost Ark (1981)

![](https://image.tmdb.org/t/p/w500/ceG9VzoRAVGwivFU403Wc3AHRys.jpg)

When Dr. Indiana Jones – the tweed-suited professor who just happens to be a celebrated archaeologist – is hired by the government to locate the legendary Ark of the Covenant, he finds himself up against the entire Nazi regime.