---
type: movie
country: US
title: "E.T. the Extra-Terrestrial"
year: 1982
director: Steven Spielberg
actors: [Henry Thomas, Drew Barrymore, Robert MacNaughton, Peter Coyote, Dee Wallace]
genre: [Science Fiction, Adventure, Family, Fantasy]
length: "1h 55m"
shelf: watched
owned: false
rating: 
watched: 1982-06-11
poster: "https://image.tmdb.org/t/p/w500/an0nD6uq6byfxXCfk6lQBzdL2J1.jpg"
---

# E.T. the Extra-Terrestrial (1982)

![](https://image.tmdb.org/t/p/w500/an0nD6uq6byfxXCfk6lQBzdL2J1.jpg)

An alien is left behind on Earth and saved by the 10-year-old Elliot who decides to keep him hidden in his home. While a task force hunts for the extra-terrestrial, Elliot, his brother, and his little sister Gertie form an emotional bond with their new friend, and try to help him find his way home.