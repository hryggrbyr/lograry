---
type: movie
country: United Kingdom, United States
title: "Welcome to the Rileys"
year: 2010
director: Jake Scott
actors: [James Gandolfini, Kristen Stewart, Melissa Leo]
genre: [Drama]
length: 110
shelf: watched
owned: false
rating: 4
watched: 2010-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMTQzOTkxMTY3MV5BMl5BanBnXkFtZTcwNjMyMzk5Mw@@._V1_SX300.jpg"
---

# Welcome to the Rileys (2010)

![](https://m.media-amazon.com/images/M/MV5BMTQzOTkxMTY3MV5BMl5BanBnXkFtZTcwNjMyMzk5Mw@@._V1_SX300.jpg)

On a business trip to New Orleans, a damaged man seeks salvation by caring for a wayward young woman.