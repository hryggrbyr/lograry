---
type: movie
country: US
title: "Ultraviolet"
year: 2006
director: Kurt Wimmer
actors: [Milla Jovovich, Cameron Bright, Nick Chinlund, Sebastien Andrieu, Ida Martin]
genre: [Science Fiction, Action, Thriller]
length: "1h 27m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/27OzQ2BBahQHYPiPEAXRXMbhnPQ.jpg"
---

# Ultraviolet (2006)

![](https://image.tmdb.org/t/p/w500/27OzQ2BBahQHYPiPEAXRXMbhnPQ.jpg)

In the late 21st century, a subculture of humans have emerged who have been modified genetically by a vampire-like disease, giving them enhanced speed, incredible stamina and acute intelligence. As they are set apart from "normal" and "healthy" humans, the world is pushed to the brink of worldwide civil war  aimed at the destruction of the "diseased" population. In the middle of this crossed-fire is - an infected woman - Ultraviolet, who finds herself protecting a nine-year-old boy who has been marked for death by the human government as he is believed to be a threat to humans.
