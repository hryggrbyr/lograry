---
type: movie
country: US
title: "Bram Stoker's Dracula"
year: 1992
director: Francis Ford Coppola
actors: [Gary Oldman, Winona Ryder, Anthony Hopkins, Keanu Reeves, Sadie Frost]
genre: [Romance, Horror]
length: "2h 8m"
shelf: watched
owned: false
rating: 
watched: 1992-11-13
poster: "https://image.tmdb.org/t/p/w500/n39glC4GkBeCbwdenES8ZBodim8.jpg"
---

# Bram Stoker's Dracula (1992)

![](https://image.tmdb.org/t/p/w500/n39glC4GkBeCbwdenES8ZBodim8.jpg)

In 19th century England, Count Dracula travels to London and meets Mina Harker, a young woman who appears as the reincarnation of his lost love.