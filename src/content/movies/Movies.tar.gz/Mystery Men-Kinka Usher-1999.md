---
type: movie
country: US
title: "Mystery Men"
year: 1999
director: Kinka Usher
actors: [Ben Stiller, Hank Azaria, William H. Macy, Greg Kinnear, Kel Mitchell]
genre: [Adventure, Fantasy, Action, Comedy, Science Fiction]
length: "2h 1m"
shelf: watched
owned: false
rating: 
watched: 1999-08-06
poster: "https://image.tmdb.org/t/p/w500/ciVSbFmDecOIwlxl9F6GhHVgCVJ.jpg"
---

# Mystery Men (1999)

![](https://image.tmdb.org/t/p/w500/ciVSbFmDecOIwlxl9F6GhHVgCVJ.jpg)

When Champion City's hero Captain Amazing is kidnapped by the recently paroled supervillain Casanova Frankenstein, a trio of average, everyday superheroes -- Mr. Furious, the Shoveler and the Blue Raja -- assemble a new super team to save him.