---
type: movie
country: US
title: "50 First Dates"
year: 2004
director: Peter Segal
actors: [Adam Sandler, Drew Barrymore, Rob Schneider, Sean Astin, Lusia Strus]
genre: [Comedy, Romance]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 2004-02-13
poster: "https://image.tmdb.org/t/p/w500/4T0cSswKtXk37r0QbqoLbTtlbO1.jpg"
---

# 50 First Dates (2004)

![](https://image.tmdb.org/t/p/w500/4T0cSswKtXk37r0QbqoLbTtlbO1.jpg)

Henry is a player skilled at seducing women. But when this veterinarian meets Lucy, a girl with a quirky problem when it comes to total recall, he realizes it's possible to fall in love all over again…and again, and again. That's because the delightful Lucy has no short-term memory, so Henry must woo her day after day until he finally sweeps her off her feet.