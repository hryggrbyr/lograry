---
type: movie
country: US
title: "Braveheart"
year: 1995
director: Mel Gibson
actors: [Mel Gibson, Catherine McCormack, Sophie Marceau, Patrick McGoohan, Angus Macfadyen]
genre: [Action, Drama, History, War]
length: "2h 57m"
shelf: watched
owned: false
rating: 
watched: 1995-05-24
poster: "https://image.tmdb.org/t/p/w500/or1gBugydmjToAEq7OZY0owwFk.jpg"
---

# Braveheart (1995)

![](https://image.tmdb.org/t/p/w500/or1gBugydmjToAEq7OZY0owwFk.jpg)

Enraged at the slaughter of Murron, his new bride and childhood love, Scottish warrior William Wallace slays a platoon of the local English lord's soldiers. This leads the village to revolt and, eventually, the entire country to rise up against English rule.