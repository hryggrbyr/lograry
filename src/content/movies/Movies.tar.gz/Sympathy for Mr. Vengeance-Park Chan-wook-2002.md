---
type: movie
country: KR
title: "Sympathy for Mr. Vengeance"
year: 2002
director: Park Chan-wook
actors: [Song Kang-ho, Shin Ha-kyun, Bae Doona, Im Ji-eun, Han Bo-bae]
genre: [Action, Drama, Thriller]
length: "2h 9m"
shelf: watched
owned: false
rating: 
watched: 2002-03-29
poster: "https://image.tmdb.org/t/p/w500/uj42ubGbgVL65T10SvPVr0p9mJc.jpg"
---

# Sympathy for Mr. Vengeance (2002)

![](https://image.tmdb.org/t/p/w500/uj42ubGbgVL65T10SvPVr0p9mJc.jpg)

A deaf man and his girlfriend resort to desperate measures in order to fund a kidney transplant for his sister. Things go horribly wrong, and the situation spirals rapidly into a cycle of violence and revenge.