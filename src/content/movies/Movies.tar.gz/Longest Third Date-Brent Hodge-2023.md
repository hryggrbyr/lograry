---
type: movie
country: US
title: "Longest Third Date"
year: 2023
director: Brent Hodge
actors: [Matt Robertson, Khani Le]
genre: [Documentary]
length: "1h 16m"
shelf: watched
owned: false
rating: 
watched: 2023-05-12
poster: "https://image.tmdb.org/t/p/w500/oyECVwOybdYKuyuAoZJCf9E6Ln0.jpg"
---

# Longest Third Date (2023)

![](https://image.tmdb.org/t/p/w500/oyECVwOybdYKuyuAoZJCf9E6Ln0.jpg)

When Khani and Matt met on a dating app, they had no idea COVID-19 would turn their spur-of-the-moment trip to Costa Rica into a months-long adventure.