---
type: movie
country: US
title: "The Basement"
year: 2018
director: Brian M. Conley, Nathan Ives
actors: [Cayleb Long, Mischa Barton, Jackson Davis, Bailey Anne Borders, Maria Volk]
genre: [Horror]
length: "1h 30m"
shelf: watched
owned: false
rating: 
watched: 2018-09-14
poster: "https://image.tmdb.org/t/p/w500/oSdwlfxbqRtlpTbsKipoCGBkCIs.jpg"
---

# The Basement (2018)

![](https://image.tmdb.org/t/p/w500/oSdwlfxbqRtlpTbsKipoCGBkCIs.jpg)

A seemingly innocent man is abducted by a notorious L.A. serial killer, who forces his victims to switch roles with him so that he can enact his own capture, torture and murder.