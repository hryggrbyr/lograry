---
type: movie
country: US
title: "The Devil's Advocate"
year: 1997
director: Taylor Hackford
actors: [Keanu Reeves, Al Pacino, Charlize Theron, Jeffrey Jones, Judith Ivey]
genre: [Drama, Mystery, Thriller, Horror]
length: "2h 24m"
shelf: watched
owned: false
rating: 
watched: 1997-10-17
poster: "https://image.tmdb.org/t/p/w500/5ZzBGpxy55OQzHxKVY11IpY6a0o.jpg"
---

# The Devil's Advocate (1997)

![](https://image.tmdb.org/t/p/w500/5ZzBGpxy55OQzHxKVY11IpY6a0o.jpg)

Aspiring Florida defense lawyer Kevin Lomax accepts a job at a New York law firm. With the stakes getting higher every case, Kevin quickly learns that his boss has something far more evil planned.