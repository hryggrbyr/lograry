---
type: movie
country: GB
title: "Kingsman: The Secret Service"
year: 2015
director: Matthew Vaughn
actors: [Taron Egerton, Colin Firth, Samuel L. Jackson, Mark Strong, Sophie Cookson]
genre: [Crime, Comedy, Action, Adventure]
length: "2h 9m"
shelf: watched
owned: false
rating: 
watched: 2014-12-13
poster: "https://image.tmdb.org/t/p/w500/r6q9wZK5a2K51KFj4LWVID6Ja1r.jpg"
---

# Kingsman: The Secret Service (2015)

![](https://image.tmdb.org/t/p/w500/r6q9wZK5a2K51KFj4LWVID6Ja1r.jpg)

The story of a super-secret spy organization that recruits an unrefined but promising street kid into the agency's ultra-competitive training program just as a global threat emerges from a twisted tech genius.