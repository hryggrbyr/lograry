---
type: movie
country: US
title: "Poison Ivy"
year: 1992
director: Katt Shea
actors: [Drew Barrymore, Sara Gilbert, Tom Skerritt, Cheryl Ladd, Jeanne Sakata]
genre: [Thriller, Drama]
length: "1h 32m"
shelf: watched
owned: false
rating: 
watched: 1992-05-08
poster: "https://image.tmdb.org/t/p/w500/igwGf0qNka1qH1HPijgbABfUfB4.jpg"
---

# Poison Ivy (1992)

![](https://image.tmdb.org/t/p/w500/igwGf0qNka1qH1HPijgbABfUfB4.jpg)

A seductive teen befriends an introverted high school student and schemes her way into the lives of her wealthy family.