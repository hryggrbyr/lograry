---
type: movie
country: US
title: "Tron"
year: 1982
director: Steven Lisberger
actors: [Jeff Bridges, Bruce Boxleitner, David Warner, Cindy Morgan, Barnard Hughes]
genre: [Science Fiction, Action, Adventure]
length: "1h 35m"
shelf: watched
owned: false
rating: 
watched: 1982-07-09
poster: "https://image.tmdb.org/t/p/w500/zwSFEczP7AzqugAHHIX3zHniT0t.jpg"
---

# Tron (1982)

![](https://image.tmdb.org/t/p/w500/zwSFEczP7AzqugAHHIX3zHniT0t.jpg)

When brilliant video game maker Flynn hacks the mainframe of his ex-employer, he is beamed inside an astonishing digital world...And becomes part of the very game he is designing. In his mission through cyberspace, Flynn matches wits with a maniacal Master Control Program and teams up with Tron, a security measure created to bring balance to the digital environment.