---
type: movie
country: US
title: "Home Alone 2: Lost in New York"
year: 1992
director: Chris Columbus
actors: [Macaulay Culkin, Joe Pesci, Daniel Stern, Catherine O'Hara, John Heard]
genre: [Comedy, Family, Adventure, Christmas]
length: "2h 0m"
shelf: watched
owned: false
rating: 
watched: 1992-11-19
poster: "https://image.tmdb.org/t/p/w500/uuitWHpJwxD1wruFl2nZHIb4UGN.jpg"
---

# Home Alone 2: Lost in New York (1992)

![](https://image.tmdb.org/t/p/w500/uuitWHpJwxD1wruFl2nZHIb4UGN.jpg)

Instead of flying to Florida with his folks, Kevin ends up alone in New York, where he gets a hotel room with his dad's credit card—despite problems from a clerk and meddling bellboy. But when Kevin runs into his old nemeses, the Wet Bandits, he's determined to foil their plans to rob a toy store on Christmas Eve.