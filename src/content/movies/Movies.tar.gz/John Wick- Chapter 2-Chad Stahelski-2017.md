---
type: movie
country: US
title: "John Wick: Chapter 2"
year: 2017
director: Chad Stahelski
actors: [Keanu Reeves, Common, Laurence Fishburne, Riccardo Scamarcio, Ruby Rose]
genre: [Action, Thriller, Crime]
length: "2h 2m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/hXWBc0ioZP3cN4zCu6SN3YHXZVO.jpg"
---

# John Wick: Chapter 2 (2017)

![](https://image.tmdb.org/t/p/w500/hXWBc0ioZP3cN4zCu6SN3YHXZVO.jpg)

John Wick is forced out of retirement by a former associate looking to seize control of a shadowy international assassins’ guild. Bound by a blood oath to aid him, Wick travels to Rome and does battle against some of the world’s most dangerous killers.