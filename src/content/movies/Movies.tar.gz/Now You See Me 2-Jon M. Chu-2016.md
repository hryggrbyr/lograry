---
type: movie
country: US
title: "Now You See Me 2"
year: 2016
director: Jon M. Chu
actors: [Jesse Eisenberg, Mark Ruffalo, Woody Harrelson, Morgan Freeman, Dave Franco]
genre: [Thriller, Crime]
length: "2h 9m"
shelf: watched
owned: false
rating: 
watched: 2016-06-10
poster: "https://image.tmdb.org/t/p/w500/A81kDB6a1K86YLlcOtZB27jriJh.jpg"
---

# Now You See Me 2 (2016)

![](https://image.tmdb.org/t/p/w500/A81kDB6a1K86YLlcOtZB27jriJh.jpg)

One year after outwitting the FBI and winning the public’s adulation with their mind-bending spectacles, the Four Horsemen resurface only to find themselves face to face with a new enemy who enlists them to pull off their most dangerous heist yet.