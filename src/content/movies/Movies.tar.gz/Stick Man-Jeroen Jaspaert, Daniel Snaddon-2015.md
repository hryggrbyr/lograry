---
type: movie
country: US, GB
title: "Stick Man"
year: 2015
director: Jeroen Jaspaert, Daniel Snaddon
actors: [Martin Freeman, Hugh Bonneville, Jennifer Saunders, Russell Tovey, Sally Hawkins]
genre: [Animation, Family, Christmas]
length: "27m"
shelf: watched
owned: false
rating: 
watched: 2024-08-11
poster: "https://image.tmdb.org/t/p/w500/hChFSATMxo9cDpDGl5iit5dx7yy.jpg"
---

# Stick Man (2015)

![](https://image.tmdb.org/t/p/w500/hChFSATMxo9cDpDGl5iit5dx7yy.jpg)

Stick Man lives in the family tree with his Stick Lady Love and their stick children three, and he's heading on an epic adventure across the seasons. Will he get back to his family in time for Christmas?