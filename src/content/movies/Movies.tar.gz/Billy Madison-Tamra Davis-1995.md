---
type: movie
country: US
title: "Billy Madison"
year: 1995
director: Tamra Davis
actors: [Adam Sandler, Bradley Whitford, Josh Mostel, Bridgette Wilson-Sampras, Darren McGavin]
genre: [Comedy]
length: "1h 30m"
shelf: watched
owned: false
rating: 
watched: 1995-02-10
poster: "https://image.tmdb.org/t/p/w500/1XV42Zu9taxluIKXMeV9OSpYCSq.jpg"
---

# Billy Madison (1995)

![](https://image.tmdb.org/t/p/w500/1XV42Zu9taxluIKXMeV9OSpYCSq.jpg)

Billy Madison is the 27 year-old son of Bryan Madison, a very rich man who has made his living in the hotel industry. Billy stands to inherit his father's empire, but only if he can make it through all 12 grades, 2 weeks per grade, to prove that he has what it takes to run the family business.