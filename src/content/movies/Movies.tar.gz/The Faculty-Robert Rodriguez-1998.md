---
type: movie
country: US, MX
title: "The Faculty"
year: 1998
director: Robert Rodriguez
actors: [Josh Hartnett, Elijah Wood, Jordana Brewster, Clea DuVall, Shawn Hatosy]
genre: [Horror, Science Fiction]
length: "1h 44m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/5XetJwmAiDC0EtH23NIXaqFn3Wl.jpg"
---

# The Faculty (1998)

![](https://image.tmdb.org/t/p/w500/5XetJwmAiDC0EtH23NIXaqFn3Wl.jpg)

When some very creepy things start happening around school, the kids at Herrington High make the chilling discovery that confirms their worst suspicions: their teachers really are from another planet!