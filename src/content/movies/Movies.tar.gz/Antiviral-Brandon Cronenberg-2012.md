---
type: movie
country: CA, FR
title: "Antiviral"
year: 2012
director: Brandon Cronenberg
actors: [Caleb Landry Jones, Sarah Gadon, Malcolm McDowell, Joe Pingue, Sheila McCarthy]
genre: [Science Fiction, Horror]
length: "1h 50m"
shelf: watched
owned: false
rating: 
watched: 2012-10-12
poster: "https://image.tmdb.org/t/p/w500/rIn0ruFDU8psnCGkPgA9fbKJJUy.jpg"
---

# Antiviral (2012)

![](https://image.tmdb.org/t/p/w500/rIn0ruFDU8psnCGkPgA9fbKJJUy.jpg)

Syd March is an employee at a clinic that sells injections of live viruses harvested from sick celebrities to obsessed fans. When he becomes infected with the disease that kills super sensation Hannah Geist, Syd becomes a target for collectors and rabid fans. He must unravel the mystery surrounding her death before he suffers the same fate.