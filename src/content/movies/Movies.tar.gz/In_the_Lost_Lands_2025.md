---
type: movie
country: DE, CH
title: "In the Lost Lands"
year: 2025
director: Paul W. S. Anderson
actors: [Milla Jovovich, Dave Bautista, Arly Jover, Amara Okereke, Fraser James]
genre: [Action, Fantasy, Adventure]
length: "1h 42m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/dDlfjR7gllmr8HTeN6rfrYhTdwX.jpg"
---

# In the Lost Lands (2025)

![](https://image.tmdb.org/t/p/w500/dDlfjR7gllmr8HTeN6rfrYhTdwX.jpg)

A queen sends the powerful and feared sorceress Gray Alys to the ghostly wilderness of the Lost Lands in search of a magical power, where she and her guide, the drifter Boyce, must outwit and outfight both man and demon.
