---
type: movie
country: US
title: "Wild at Heart"
year: 1990
director: David Lynch
actors: [Nicolas Cage, Laura Dern, Willem Dafoe, Diane Ladd, Harry Dean Stanton]
genre: [Crime, Thriller, Romance]
length: "2h 5m"
shelf: watched
owned: false
rating: 
watched: 1990-08-17
poster: "https://image.tmdb.org/t/p/w500/uLUFI5sJIfWrBUWB2Y1dEuyvvVy.jpg"
---

# Wild at Heart (1990)

![](https://image.tmdb.org/t/p/w500/uLUFI5sJIfWrBUWB2Y1dEuyvvVy.jpg)

Young lovers Sailor and Lula hit the road to start a new life together away from the wrath of Lula’s deranged, disapproving mother, who has hired a team of hitmen to cut the lovers’ surreal honeymoon short.