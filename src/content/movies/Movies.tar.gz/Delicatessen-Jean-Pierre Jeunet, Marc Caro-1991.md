---
type: movie
country: FR
title: "Delicatessen"
year: 1991
director: Jean-Pierre Jeunet, Marc Caro
actors: [Dominique Pinon, Marie-Laure Dougnac, Jean-Claude Dreyfus, Karin Viard, Ticky Holgado]
genre: [Comedy, Science Fiction, Fantasy]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 1991-04-17
poster: "https://image.tmdb.org/t/p/w500/gNtOgQHxE5B8e08zuNRAdDpmK5Z.jpg"
---

# Delicatessen (1991)

![](https://image.tmdb.org/t/p/w500/gNtOgQHxE5B8e08zuNRAdDpmK5Z.jpg)

In a post-apocalyptic world, the residents of an apartment above the butcher shop receive an occasional delicacy of meat, something that is in low supply. A young man new in town falls in love with the butcher's daughter, which causes conflicts in her family, who need the young man for other business-related purposes.