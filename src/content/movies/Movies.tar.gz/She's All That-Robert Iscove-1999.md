---
type: movie
country: US
title: "She's All That"
year: 1999
director: Robert Iscove
actors: [Freddie Prinze Jr., Rachael Leigh Cook, Paul Walker, Jodi Lyn O'Keefe, Kevin Pollak]
genre: [Comedy, Romance]
length: "1h 35m"
shelf: watched
owned: false
rating: 
watched: 1999-01-29
poster: "https://image.tmdb.org/t/p/w500/a0pepZNFCjggc7Na9gEwbTI1f46.jpg"
---

# She's All That (1999)

![](https://image.tmdb.org/t/p/w500/a0pepZNFCjggc7Na9gEwbTI1f46.jpg)

High school hotshot Zach Siler is the envy of his peers. But his popularity declines sharply when his cheerleader girlfriend, Taylor, leaves him for sleazy reality-television star Brock Hudson. Desperate to revive his fading reputation, Siler agrees to a seemingly impossible challenge. He has six weeks to gain the trust of nerdy outcast Laney Boggs -- and help her to become the school's next prom queen.