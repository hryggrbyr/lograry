---
type: movie
country: US
title: "Desert Blue"
year: 1999
director: Morgan J. Freeman
actors: [Kate Hudson, Brendan Sexton III, John Heard, Christina Ricci, Casey Affleck]
genre: [Comedy, Drama]
length: "1h 30m"
shelf: watched
owned: false
rating: 
watched: 1999-06-04
poster: "https://image.tmdb.org/t/p/w500/m81tA5hmjJ4Xzp3Yxs0dcnl8B1q.jpg"
---

# Desert Blue (1999)

![](https://image.tmdb.org/t/p/w500/m81tA5hmjJ4Xzp3Yxs0dcnl8B1q.jpg)

An academic obsessed with roadside attractions and his tv-star daughter stop at a small desert town to see the world's largest ice cream cone, where, because of an accident that spilled an unknown substance all over the highway, they are forced to spend a few days with the towns eccentric residents.