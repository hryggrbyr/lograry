---
type: movie
country: US
title: "Brave"
year: 2012
director: Brenda Chapman, Mark Andrews
actors: [Kelly Macdonald, Emma Thompson, Billy Connolly, Julie Walters, Robbie Coltrane]
genre: [Animation, Adventure, Comedy, Family, Action, Fantasy]
length: "1h 33m"
shelf: watched
owned: false
rating: 
watched: 2012-06-22
poster: "https://image.tmdb.org/t/p/w500/1XAuDtMWpL0sYSFK0R6EZate2Ux.jpg"
---

# Brave (2012)

![](https://image.tmdb.org/t/p/w500/1XAuDtMWpL0sYSFK0R6EZate2Ux.jpg)

In the mystical Scottish Highlands, Merida is the princess of a kingdom ruled by King Fergus and Queen Elinor. An unruly daughter and an accomplished archer, Merida one day defies a sacred custom of the land and inadvertently brings turmoil to the kingdom. In an attempt to set things right, Merida seeks out an eccentric old Wise Woman and is granted an ill-fated wish. Also figuring into Merida's quest — and serving as comic relief — are the kingdom's three lords: the enormous Lord MacGuffin, the surly Lord Macintosh, and the disagreeable Lord Dingwall.