---
type: movie
country: GB
title: "Trainspotting"
year: 1996
director: Danny Boyle
actors: [Ewan McGregor, Ewen Bremner, Jonny Lee Miller, Kevin McKidd, Robert Carlyle]
genre: [Drama, Crime]
length: "1h 34m"
shelf: watched
owned: false
rating: 
watched: 1996-02-23
poster: "https://image.tmdb.org/t/p/w500/1jUC02qsqS2NxBMFarbIhcQtazV.jpg"
---

# Trainspotting (1996)

![](https://image.tmdb.org/t/p/w500/1jUC02qsqS2NxBMFarbIhcQtazV.jpg)

Hilarious but harrowing, the film charts the disintegration of the friendship between Renton, Spud, Sick Boy, Tommy and Begbie as they proceed seemingly towards a psychotic, drug-fuelled self-destruction.