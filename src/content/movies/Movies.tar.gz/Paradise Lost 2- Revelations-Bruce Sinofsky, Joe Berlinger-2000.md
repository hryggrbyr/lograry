---
type: movie
country: US
title: "Paradise Lost 2: Revelations"
year: 2000
director: Bruce Sinofsky, Joe Berlinger
actors: [Damien Echols, Jason Baldwin, Jessie Misskelley Jr., John Mark Byers, Kathy Bakken]
genre: [Documentary, Crime]
length: "2h 10m"
shelf: watched
owned: false
rating: 
watched: 2000-03-13
poster: "https://image.tmdb.org/t/p/w500/18ixOKgqZGmfALD5080MdZN4dxi.jpg"
---

# Paradise Lost 2: Revelations (2000)

![](https://image.tmdb.org/t/p/w500/18ixOKgqZGmfALD5080MdZN4dxi.jpg)

Revisiting the 1994 Arkansas murder of three 8-year-old boys and the three teenagers convicted of the crime. A follow up to Paradise Lost, Revelations features new interviews with the convicted men, as well as with the original judge and police investigators.