---
type: movie
country: US
title: "Interview with the Vampire"
year: 1994
director: Neil Jordan
actors: [Tom Cruise, Brad Pitt, Antonio Banderas, Christian Slater, Stephen Rea]
genre: [Horror, Drama, Fantasy]
length: "2h 3m"
shelf: watched
owned: false
rating: 
watched: 1994-11-11
poster: "https://image.tmdb.org/t/p/w500/2162lAT2MP36MyJd2sttmj5du5T.jpg"
---

# Interview with the Vampire (1994)

![](https://image.tmdb.org/t/p/w500/2162lAT2MP36MyJd2sttmj5du5T.jpg)

A vampire relates his epic life story of love, betrayal, loneliness, and dark hunger to an over-curious reporter.