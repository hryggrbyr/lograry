---
type: movie
country: CA, US
title: "The Good Liar"
year: 2019
director: Bill Condon
actors: [Helen Mirren, Ian McKellen, Russell Tovey, Jim Carter, Mark Lewis Jones]
genre: [Crime]
length: "1h 49m"
shelf: watched
owned: false
rating: 
watched: 2019-11-15
poster: "https://image.tmdb.org/t/p/w500/6kmxXfg3aSWrzUlEPt2L0YD4jz9.jpg"
---

# The Good Liar (2019)

![](https://image.tmdb.org/t/p/w500/6kmxXfg3aSWrzUlEPt2L0YD4jz9.jpg)

Career con man Roy sets his sights on his latest mark: recently widowed Betty, worth millions. And he means to take it all. But as the two draw closer, what should have been another simple swindle takes on the ultimate stakes.