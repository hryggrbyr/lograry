---
type: movie
country: GB
title: "Dr. Strangelove or: How I Learned to Stop Worrying and Love the Bomb"
year: 1964
director: Stanley Kubrick
actors: [Peter Sellers, George C. Scott, Sterling Hayden, Keenan Wynn, Slim Pickens]
genre: [Comedy, War]
length: "1h 35m"
shelf: watched
owned: false
rating: 
watched: 1964-01-29
poster: "https://image.tmdb.org/t/p/w500/7SixLzxcqezkZEYU8pcHZgbkmjp.jpg"
---

# Dr. Strangelove or: How I Learned to Stop Worrying and Love the Bomb (1964)

![](https://image.tmdb.org/t/p/w500/7SixLzxcqezkZEYU8pcHZgbkmjp.jpg)

After the insane General Jack D. Ripper initiates a nuclear strike on the Soviet Union, a war room full of politicians, generals and a Russian diplomat all frantically try to stop it.