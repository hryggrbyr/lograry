---
type: movie
country: United States
title: Pirates of the Caribbean At World's End
year: 2007
director: Gore Verbinski
actors: [Johnny Depp, Orlando Bloom, Keira Knightley]
genre: [Action, Adventure, Fantasy]
length: 169
shelf: watched
owned: false
rating: 
watched: 2007-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMjIyNjkxNzEyMl5BMl5BanBnXkFtZTYwMjc3MDE3._V1_SX300.jpg"
---

# Pirates of the Caribbean At World's End (2007)

![](https://m.media-amazon.com/images/M/MV5BMjIyNjkxNzEyMl5BMl5BanBnXkFtZTYwMjc3MDE3._V1_SX300.jpg)

Will Turner, Elizabeth Swann, Hector Barbossa, and the crew of the Black Pearl try and rescue Jack from davy jones locker and prepare to fight Lord Cutler Beckett, who controls Davy Jones and the Flying Dutchman.