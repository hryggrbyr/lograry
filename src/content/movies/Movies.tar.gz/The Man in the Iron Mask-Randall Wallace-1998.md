---
type: movie
country: US
title: "The Man in the Iron Mask"
year: 1998
director: Randall Wallace
actors: [Leonardo DiCaprio, Gabriel Byrne, Jeremy Irons, John Malkovich, Gérard Depardieu]
genre: [Adventure, Action, Drama]
length: "2h 12m"
shelf: watched
owned: false
rating: 
watched: 1998-03-12
poster: "https://image.tmdb.org/t/p/w500/zHE9yRURvA7DyhYtQxkGTfE1Ywi.jpg"
---

# The Man in the Iron Mask (1998)

![](https://image.tmdb.org/t/p/w500/zHE9yRURvA7DyhYtQxkGTfE1Ywi.jpg)

Years have passed since the Three Musketeers, Aramis, Athos and Porthos, have fought together with their friend, D'Artagnan. But with the tyrannical King Louis using his power to wreak havoc in the kingdom while his twin brother, Philippe, remains imprisoned, the Musketeers reunite to abduct Louis and replace him with Philippe.