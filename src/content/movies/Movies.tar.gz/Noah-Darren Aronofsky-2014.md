---
type: movie
country: US
title: "Noah"
year: 2014
director: Darren Aronofsky
actors: [Russell Crowe, Jennifer Connelly, Ray Winstone, Anthony Hopkins, Emma Watson]
genre: [Drama, Adventure]
length: "2h 18m"
shelf: watched
owned: false
rating: 
watched: 2014-03-28
poster: "https://image.tmdb.org/t/p/w500/9ftKmR9dXmI4aSJJikXNWHNSDq3.jpg"
---

# Noah (2014)

![](https://image.tmdb.org/t/p/w500/9ftKmR9dXmI4aSJJikXNWHNSDq3.jpg)

A man who suffers visions of an apocalyptic deluge takes measures to protect his family from the coming flood.