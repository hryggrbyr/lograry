---
type: movie
country: US
title: "The Texas Chain Saw Massacre"
year: 1974
director: Tobe Hooper
actors: [Marilyn Burns, Allen Danziger, Paul A. Partain, William Vail, Teri McMinn]
genre: [Horror]
length: "1h 23m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/mpgkRPH1GNkMCgdPk2OMyHzAks7.jpg"
---

# The Texas Chain Saw Massacre (1974)

![](https://image.tmdb.org/t/p/w500/mpgkRPH1GNkMCgdPk2OMyHzAks7.jpg)

Five friends head out to rural Texas to visit the grave of a grandfather. On the way they stumble across what appears to be a deserted house, only to discover something sinister within. Something armed with a chainsaw.