---
type: movie
country: US
title: "Saw III"
year: 2006
director: Darren Lynn Bousman
actors: [Tobin Bell, Shawnee Smith, Angus Macfadyen, Bahar Soomekh, Donnie Wahlberg]
genre: [Horror, Thriller, Crime]
length: "1h 48m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/4iO9n24Rb10peXV0JH2EldIOrAp.jpg"
---

# Saw III (2006)

![](https://image.tmdb.org/t/p/w500/4iO9n24Rb10peXV0JH2EldIOrAp.jpg)

Jigsaw has disappeared. Along with his new apprentice Amanda, the puppet-master behind the cruel, intricate games that have terrified a community and baffled police has once again eluded capture and vanished. While city detective scrambles to locate him, Doctor Lynn Denlon and Jeff Reinhart are unaware that they are about to become the latest pawns on his vicious chessboard.