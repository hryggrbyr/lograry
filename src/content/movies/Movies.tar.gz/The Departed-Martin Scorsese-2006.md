---
type: movie
country: US
title: "The Departed"
year: 2006
director: Martin Scorsese
actors: [Leonardo DiCaprio, Matt Damon, Jack Nicholson, Mark Wahlberg, Martin Sheen]
genre: [Drama, Thriller, Crime]
length: "2h 31m"
shelf: watched
owned: false
rating: 
watched: 2006-10-05
poster: "https://image.tmdb.org/t/p/w500/nT97ifVT2J1yMQmeq20Qblg61T.jpg"
---

# The Departed (2006)

![](https://image.tmdb.org/t/p/w500/nT97ifVT2J1yMQmeq20Qblg61T.jpg)

To take down South Boston's Irish Mafia, the police send in one of their own to infiltrate the underworld, not realizing the syndicate has done likewise. While an undercover cop curries favor with the mob kingpin, a career criminal rises through the police ranks. But both sides soon discover there's a mole among them.