---
type: movie
country: US
title: "Meet Joe Black"
year: 1998
director: Martin Brest
actors: [Brad Pitt, Anthony Hopkins, Claire Forlani, Jake Weber, Marcia Gay Harden]
genre: [Fantasy, Drama, Romance]
length: "2h 58m"
shelf: watched
owned: false
rating: 
watched: 1998-11-12
poster: "https://image.tmdb.org/t/p/w500/fDPAjvfPMomkKF7cMRmL5Anak61.jpg"
---

# Meet Joe Black (1998)

![](https://image.tmdb.org/t/p/w500/fDPAjvfPMomkKF7cMRmL5Anak61.jpg)

Bill Parrish has it all - success, wealth and power. Days before his 65th birthday, he receives a visit from a mysterious stranger, Joe Black, who soon reveals himself as Death. In exchange for extra time, Bill agrees to serve as Joe's earthly guide. But will he regret his choice when Joe unexpectedly falls in love with Bill's beautiful daughter Susan?