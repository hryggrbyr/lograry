---
type: movie
country: US
title: "The Wizard of Oz"
year: 1939
director: Victor Fleming
actors: [Judy Garland, Ray Bolger, Jack Haley, Bert Lahr, Frank Morgan]
genre: [Adventure, Fantasy, Family]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 1939-08-25
poster: "https://image.tmdb.org/t/p/w500/pfAZFD7I2hxW9HCChTuAzsdE6UX.jpg"
---

# The Wizard of Oz (1939)

![](https://image.tmdb.org/t/p/w500/pfAZFD7I2hxW9HCChTuAzsdE6UX.jpg)

Young Dorothy finds herself in a magical world where she makes friends with a lion, a scarecrow and a tin man as they make their way along the yellow brick road to talk with the Wizard and ask for the things they miss most in their lives. The Wicked Witch of the West is the only thing that could stop them.