---
type: movie
country: US
title: "Cape Fear"
year: 1991
director: Martin Scorsese
actors: [Robert De Niro, Nick Nolte, Jessica Lange, Juliette Lewis, Joe Don Baker]
genre: [Drama, Crime, Thriller]
length: "2h 8m"
shelf: watched
owned: false
rating: 
watched: 1997-09-02
poster: "https://image.tmdb.org/t/p/w500/meJZAAuVcjic2ipvbOPz5UlE4P9.jpg"
---

# Cape Fear (1991)

![](https://image.tmdb.org/t/p/w500/meJZAAuVcjic2ipvbOPz5UlE4P9.jpg)

Sam Bowden is a small-town corporate attorney. Max Cady is a tattooed, cigar-smoking, Bible-quoting, psychotic rapist. What do they have in common? 14 years ago, Sam was a public defender assigned to Max Cady's rape trial, and he made a serious error: he hid a document from his illiterate client that could have gotten him acquitted. Now, the cagey Cady has been released, and he intends to teach Sam Bowden and his family a thing or two about loss.