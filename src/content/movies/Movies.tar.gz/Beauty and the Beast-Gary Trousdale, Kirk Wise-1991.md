---
type: movie
country: US
title: "Beauty and the Beast"
year: 1991
director: Gary Trousdale, Kirk Wise
actors: [Paige O'Hara, Robby Benson, Richard White, Jerry Orbach, David Ogden Stiers]
genre: [Romance, Family, Animation, Fantasy]
length: "1h 24m"
shelf: watched
owned: false
rating: 
watched: 1991-11-22
poster: "https://image.tmdb.org/t/p/w500/hUJ0UvQ5tgE2Z9WpfuduVSdiCiU.jpg"
---

# Beauty and the Beast (1991)

![](https://image.tmdb.org/t/p/w500/hUJ0UvQ5tgE2Z9WpfuduVSdiCiU.jpg)

Follow the adventures of Belle, a bright young woman who finds herself in the castle of a prince who's been turned into a mysterious beast. With the help of the castle's enchanted staff, Belle soon learns the most important lesson of all -- that true beauty comes from within.