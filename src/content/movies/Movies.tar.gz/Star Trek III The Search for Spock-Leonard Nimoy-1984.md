---
type: movie
country: United States
title: "Star Trek III The Search for Spock"
year: 1984
director: Leonard Nimoy
actors: [William Shatner, Leonard Nimoy, DeForest Kelley]
genre: [Action, Adventure, Sci-Fi]
length: 105
shelf: watched
owned: false
rating: 
watched: 1984-12-31
poster: "https://m.media-amazon.com/images/M/MV5BYzNkOTZjMTMtOWYzZS00Yjg2LTgyMzQtMmNjODdkYzM0ZjhmXkEyXkFqcGc@._V1_SX300.jpg"
---

# Star Trek III The Search for Spock (1984)

![](https://m.media-amazon.com/images/M/MV5BYzNkOTZjMTMtOWYzZS00Yjg2LTgyMzQtMmNjODdkYzM0ZjhmXkEyXkFqcGc@._V1_SX300.jpg)

Admiral Kirk and his bridge crew risk their careers stealing the decommissioned U.S.S. Enterprise to return to the restricted Genesis Planet to recover Spock's body.