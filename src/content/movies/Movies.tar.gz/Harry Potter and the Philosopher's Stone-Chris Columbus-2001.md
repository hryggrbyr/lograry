---
type: movie
country: GB
title: "Harry Potter and the Philosopher's Stone"
year: 2001
director: Chris Columbus
actors: [Daniel Radcliffe, Rupert Grint, Emma Watson, Richard Harris, Tom Felton]
genre: [Adventure, Fantasy]
length: "2h 32m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/wuMc08IPKEatf9rnMNXvIDxqP4W.jpg"
---

# Harry Potter and the Philosopher's Stone (2001)

![](https://image.tmdb.org/t/p/w500/wuMc08IPKEatf9rnMNXvIDxqP4W.jpg)

Harry Potter has lived under the stairs at his aunt and uncle's house his whole life. But on his 11th birthday, he learns he's a powerful wizard—with a place waiting for him at the Hogwarts School of Witchcraft and Wizardry. As he learns to harness his newfound powers with the help of the school's kindly headmaster, Harry uncovers the truth about his parents' deaths—and about the villain who's to blame.