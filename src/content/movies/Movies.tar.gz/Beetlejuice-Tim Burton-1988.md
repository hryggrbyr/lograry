---
type: movie
country: US
title: "Beetlejuice"
year: 1988
director: Tim Burton
actors: [Alec Baldwin, Geena Davis, Winona Ryder, Catherine O'Hara, Jeffrey Jones]
genre: [Fantasy, Comedy]
length: "1h 32m"
shelf: watched
owned: false
rating: 
watched: 1988-03-30
poster: "https://image.tmdb.org/t/p/w500/nnl6OWkyPpuMm595hmAxNW3rZFn.jpg"
---

# Beetlejuice (1988)

![](https://image.tmdb.org/t/p/w500/nnl6OWkyPpuMm595hmAxNW3rZFn.jpg)

A newly dead New England couple seeks help from a deranged demon exorcist to scare an affluent New York family out of their home.