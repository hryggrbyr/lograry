---
type: movie
country: US
title: "The Great Escape"
year: 1963
director: John Sturges
actors: [Steve McQueen, James Garner, Richard Attenborough, James Donald, Charles Bronson]
genre: [Adventure, Drama, War]
length: "2h 53m"
shelf: watched
owned: false
rating: 
watched: 1963-07-04
poster: "https://image.tmdb.org/t/p/w500/gBH4H8UMFxl139HaLz6lRuvsel8.jpg"
---

# The Great Escape (1963)

![](https://image.tmdb.org/t/p/w500/gBH4H8UMFxl139HaLz6lRuvsel8.jpg)

The Nazis, exasperated at the number of escapes from their prison camps by a relatively small number of Allied prisoners, relocate them to a high-security 'escape-proof' camp to sit out the remainder of the war. Undaunted, the prisoners plan one of the most ambitious escape attempts of World War II. Based on a true story.