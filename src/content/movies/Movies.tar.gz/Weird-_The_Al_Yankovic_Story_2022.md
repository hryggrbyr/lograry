---
type: movie
country: US
title: "Weird: The Al Yankovic Story"
year: 2022
director: Eric Appel
actors: [Daniel Radcliffe, Evan Rachel Wood, Rainn Wilson, Toby Huss, Jack Lancaster]
genre: [Music, Comedy, Crime]
length: "1h 48m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/qcj2z13G0KjaIgc01ifiUKu7W07.jpg"
---

# Weird: The Al Yankovic Story (2022)

![](https://image.tmdb.org/t/p/w500/qcj2z13G0KjaIgc01ifiUKu7W07.jpg)

Exploring every facet of ‘Weird Al’ Yankovic’s life, from his meteoric rise to fame with early hits like ‘Eat It’ and ‘Like a Surgeon’ to his torrid celebrity love affairs and famously depraved lifestyle, this biopic takes audiences on a truly unbelievable journey through Yankovic’s life and career, from gifted child prodigy to the greatest musical legend of all time.
