---
type: movie
country: US, GB
title: "An American Werewolf in London"
year: 1981
director: John Landis
actors: [David Naughton, Jenny Agutter, Griffin Dunne, John Woodvine, Don McKillop]
genre: [Comedy, Horror]
length: "1h 37m"
shelf: watched
owned: false
rating: 
watched: 1981-08-21
poster: "https://image.tmdb.org/t/p/w500/hVEqUASJmCQaolkKFEySCHZ8uKG.jpg"
---

# An American Werewolf in London (1981)

![](https://image.tmdb.org/t/p/w500/hVEqUASJmCQaolkKFEySCHZ8uKG.jpg)

American tourists David and Jack are savaged by an unidentified vicious animal whilst hiking on the Yorkshire Moors. Retiring to the home of a beautiful nurse to recuperate, David soon experiences disturbing changes to his mind and body.