---
type: movie
country: GB
title: "Life of Brian"
year: 1979
director: Terry Jones
actors: [Graham Chapman, John Cleese, Terry Gilliam, Eric Idle, Terry Jones]
genre: [Comedy]
length: "1h 34m"
shelf: watched
owned: false
rating: 
watched: 1979-11-08
poster: "https://image.tmdb.org/t/p/w500/lSSA64WF0M0BXnjwr2quMh6shCl.jpg"
---

# Life of Brian (1979)

![](https://image.tmdb.org/t/p/w500/lSSA64WF0M0BXnjwr2quMh6shCl.jpg)

Brian Cohen is an average young Jewish man, but through a series of ridiculous events, he gains a reputation as the Messiah. When he's not dodging his followers or being scolded by his shrill mother, the hapless Brian has to contend with the pompous Pontius Pilate and acronym-obsessed members of a separatist movement. Rife with Monty Python's signature absurdity, the tale finds Brian's life paralleling Biblical lore, albeit with many more laughs.