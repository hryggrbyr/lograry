---
type: movie
country: GB
title: "Zog and the Flying Doctors"
year: 2021
director: Sean Mullen
actors: [Lenny Henry, Patsy Ferran, Daniel Ings, Hugh Skinner, Alexandra Roach]
genre: [Animation, Family, TV Movie]
length: "25m"
shelf: watched
owned: false
rating: 
watched: 2024-07-15
poster: "https://image.tmdb.org/t/p/w500/aow2SrU1nKY1onSTjHhhLW8Ndd6.jpg"
---

# Zog and the Flying Doctors (2021)

![](https://image.tmdb.org/t/p/w500/aow2SrU1nKY1onSTjHhhLW8Ndd6.jpg)

Pearl and Gadabout are now a flying doctor trio, caring for creatures including a mermaid, a unicorn and a sneezy lion. However when bad weather forces them to land at the palace, Pearl is locked up by her uncle, the king.