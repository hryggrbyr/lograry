---
type: movie
country: Ireland, United Kingdom, Greece, France, Netherlands, United States, Belgium
title: "The Lobster"
year: 2015
director: Yorgos Lanthimos
actors: [Colin Farrell, Rachel Weisz, Jessica Barden]
genre: [Drama, Romance, Sci-Fi]
length: 119
shelf: watchlist
owned: true
rating: 
watched:
poster: "https://m.media-amazon.com/images/M/MV5BNDQ1NDE5NzQ1NF5BMl5BanBnXkFtZTgwNzA5OTM2NTE@._V1_SX300.jpg"
---

# The Lobster (2015)

![](https://m.media-amazon.com/images/M/MV5BNDQ1NDE5NzQ1NF5BMl5BanBnXkFtZTgwNzA5OTM2NTE@._V1_SX300.jpg)

In a dystopian near future, according to the laws of The City, single people are taken to The Hotel, where they are obliged to find a romantic partner in 45 days or they're transformed into beasts and sent off into The Woods.