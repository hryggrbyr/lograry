---
type: movie
country: US
title: "Thelma & Louise"
year: 1991
director: Ridley Scott
actors: [Susan Sarandon, Geena Davis, Harvey Keitel, Michael Madsen, Christopher McDonald]
genre: [Drama, Thriller, Crime, Adventure]
length: "2h 10m"
shelf: watched
owned: false
rating: 
watched: 1991-05-24
poster: "https://image.tmdb.org/t/p/w500/vbRAGLzbC75QfiKD1lKjmnQGuph.jpg"
---

# Thelma & Louise (1991)

![](https://image.tmdb.org/t/p/w500/vbRAGLzbC75QfiKD1lKjmnQGuph.jpg)

Taking a break from their dreary lives, close friends Thelma and Louise embark on a short weekend trip that ends in unforeseen incriminating circumstances. As fugitives, both women rediscover the strength of their bond and their newfound resilience.