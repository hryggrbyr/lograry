---
type: movie
country: US
title: "The Hills Have Eyes 2"
year: 2007
director: Martin Weisz
actors: [Michael McMillian, Jessica Stroup, Jacob Vargas, Flex Alexander, Michael Bailey Smith]
genre: [Horror, Thriller]
length: "1h 30m"
shelf: watched
owned: false
rating: 
watched: 2007-03-22
poster: "https://image.tmdb.org/t/p/w500/3SX2UGSmAjIZsVACpshPpKtjbDr.jpg"
---

# The Hills Have Eyes 2 (2007)

![](https://image.tmdb.org/t/p/w500/3SX2UGSmAjIZsVACpshPpKtjbDr.jpg)

A group of National Guard trainees on a routine mission find themselves up against cannibalistic mutants in the New Mexico desert.