---
type: movie
country: US
title: "The Poughkeepsie Tapes"
year: 2007
director: John Erick Dowdle
actors: [Stacy Chbosky, Ben Messmer, Lou George, Ivar Brogger, Michael Lawson]
genre: [Horror, Mystery, Crime, Thriller]
length: "1h 21m"
shelf: watched
owned: true
rating: 5
watched: 2023-09-05
poster: "https://image.tmdb.org/t/p/w500/8ppkhu3pO3fnXr05YeE7ryKloVd.jpg"
---

# The Poughkeepsie Tapes (2007)

![](https://image.tmdb.org/t/p/w500/8ppkhu3pO3fnXr05YeE7ryKloVd.jpg)

When hundreds of videotapes showing torture, murder and dismemberment are found in an abandoned house, they reveal a serial killer's decade-long reign of terror and become the most disturbing collection of evidence homicide detectives have ever seen.