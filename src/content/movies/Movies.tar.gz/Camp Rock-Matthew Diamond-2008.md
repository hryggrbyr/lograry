---
type: movie
country: CA, US
title: "Camp Rock"
year: 2008
director: Matthew Diamond
actors: [Demi Lovato, Joe Jonas, Meaghan Jette Martin, Maria Canals-Barrera, Alyson Stoner]
genre: [Music, Comedy, Drama, Romance, Family, TV Movie]
length: "1h 35m"
shelf: watched
owned: false
rating: 
watched: 2008-06-20
poster: "https://image.tmdb.org/t/p/w500/7IXMqZnwccogptThay3togKIFWw.jpg"
---

# Camp Rock (2008)

![](https://image.tmdb.org/t/p/w500/7IXMqZnwccogptThay3togKIFWw.jpg)

When Mitchie gets a chance to attend Camp Rock, her life takes an unpredictable twist, and she learns just how important it is to be true to yourself.