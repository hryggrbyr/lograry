---
type: movie
country: US
title: "The Munsters"
year: 2022
director: Rob Zombie
actors: [Jeff Daniel Phillips, Sheri Moon Zombie, Daniel Roebuck, Jorge Garcia, Richard Brake]
genre: [Comedy, Fantasy]
length: "1h 50m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/kJaEVFhDouD72GKANMkYqzQky9n.jpg"
---

# The Munsters (2022)

![](https://image.tmdb.org/t/p/w500/kJaEVFhDouD72GKANMkYqzQky9n.jpg)

Lily is a typical 150-year-old lovelorn vampire who's looking for the man of her nightmares -- until she lays her eyes on Herman, a 7-foot-tall green experiment with a heart of gold. It's love at first shock as these two ghouls fall fangs over feet for each other in a Transylvanian romance. Unfortunately, it's not all smooth sailing in the cemetery as Lily's father has other plans for his beloved daughter's future, and they don't involve her new bumbling beau.
