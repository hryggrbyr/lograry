---
type: movie
country: US
title: "The Merry Gentlemen"
year: 2024
director: Peter Sullivan
actors: [Britt Robertson, Chad Michael Murray, Marla Sokoloff, Marc Anthony Samuel, Maxwell Caulfield]
genre: [Romance, Comedy, Christmas]
length: "1h 28m"
shelf: watched
owned: false
rating: 
watched: 2024-11-24
poster: "https://image.tmdb.org/t/p/w500/4t80WORFWqDYf4BRwV2jrXNHJdN.jpg"
---

# The Merry Gentlemen (2024)

![](https://image.tmdb.org/t/p/w500/4t80WORFWqDYf4BRwV2jrXNHJdN.jpg)

To save her parents' small-town nightclub, a Broadway dancer stages an all-male, Christmas-themed revue — and meets a guy with all the right moves.