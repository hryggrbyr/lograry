---
type: movie
country: US
title: "Our Little Secret"
year: 2024
director: Stephen Herek
actors: [Lindsay Lohan, Ian Harding, Kristin Chenoweth, Jon Rudnitsky, Dan Bucatinsky]
genre: [Romance, Comedy, Drama, Christmas]
length: "1h 41m"
shelf: watched
owned: false
rating: 
watched: 2024-12-02
poster: "https://image.tmdb.org/t/p/w500/gkydRYX3VTqMIjJGDT7kXJ6SrfZ.jpg"
---

# Our Little Secret (2024)

![](https://image.tmdb.org/t/p/w500/gkydRYX3VTqMIjJGDT7kXJ6SrfZ.jpg)

After discovering their significant others are siblings, two resentful exes must spend Christmas under one roof — while hiding their romantic history.