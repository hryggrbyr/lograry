---
type: movie
country: US
title: "Soul Survivors"
year: 2001
director: Stephen Carpenter
actors: [Melissa Sagemiller, Wes Bentley, Casey Affleck, Eliza Dushku, Angela Featherstone]
genre: [Horror, Mystery, Thriller]
length: "1h 24m"
shelf: watched
owned: false
rating: 
watched: 2001-09-07
poster: "https://image.tmdb.org/t/p/w500/uWmHhtuEgX7oI0FuWR2oD08HRHD.jpg"
---

# Soul Survivors (2001)

![](https://image.tmdb.org/t/p/w500/uWmHhtuEgX7oI0FuWR2oD08HRHD.jpg)

A college freshman involved in a fatal car crash discovers she may not have survived after all when she becomes caught between the worlds of the living and the dead.