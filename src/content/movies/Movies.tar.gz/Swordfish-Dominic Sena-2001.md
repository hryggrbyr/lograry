---
type: movie
country: US
title: "Swordfish"
year: 2001
director: Dominic Sena
actors: [John Travolta, Hugh Jackman, Halle Berry, Don Cheadle, Vinnie Jones]
genre: [Action, Crime, Thriller]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 2001-06-07
poster: "https://image.tmdb.org/t/p/w500/mM6h4jMqC4q5IaFgBIGKQDLnRU.jpg"
---

# Swordfish (2001)

![](https://image.tmdb.org/t/p/w500/mM6h4jMqC4q5IaFgBIGKQDLnRU.jpg)

Rogue agent Gabriel Shear is determined to get his mitts on $9 billion stashed in a secret Drug Enforcement Administration account. He wants the cash to fight terrorism, but lacks the computer skills necessary to hack into the government mainframe. Enter Stanley Jobson, a n'er-do-well encryption expert who can log into anything.