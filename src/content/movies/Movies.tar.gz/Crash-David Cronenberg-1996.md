---
type: movie
country: CA
title: "Crash"
year: 1996
director: David Cronenberg
actors: [James Spader, Holly Hunter, Elias Koteas, Deborah Kara Unger, Rosanna Arquette]
genre: [Thriller, Drama]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 1996-10-04
poster: "https://image.tmdb.org/t/p/w500/gpai5oUFyFGLHOCsYTvVMqlbY7A.jpg"
---

# Crash (1996)

![](https://image.tmdb.org/t/p/w500/gpai5oUFyFGLHOCsYTvVMqlbY7A.jpg)

After getting into a serious car accident, a TV director discovers an underground sub-culture of scarred, omnisexual car-crash victims, and he begins to use car accidents and the raw sexual energy they produce to try to rejuvenate his sex life with his wife.