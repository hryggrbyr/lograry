---
type: movie
country: US
title: "Se7en"
year: 1995
director: David Fincher
actors: [Morgan Freeman, Brad Pitt, Gwyneth Paltrow, Kevin Spacey, John Cassini, Peter Crombie]
genre: [Crime, Mystery, Thriller]
length: "2h 7m"
shelf: watched
owned: false
rating: 4
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/191nKfP0ehp3uIvWqgPbFmI4lv9.jpg"
---

# Se7en (1995)

![](https://image.tmdb.org/t/p/w500/191nKfP0ehp3uIvWqgPbFmI4lv9.jpg)

Two homicide detectives are on a desperate hunt for a serial killer whose crimes are based on the "seven deadly sins" in this dark and haunting film that takes viewers from the tortured remains of one victim to the next. The seasoned Det. Somerset researches each sin in an effort to get inside the killer's mind, while his novice partner, Mills, scoffs at his efforts to unravel the case.