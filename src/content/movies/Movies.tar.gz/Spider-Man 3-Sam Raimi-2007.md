---
type: movie
country: US
title: "Spider-Man 3"
year: 2007
director: Sam Raimi
actors: [Tobey Maguire, Kirsten Dunst, James Franco, Thomas Haden Church, Topher Grace]
genre: [Action, Adventure, Science Fiction]
length: "2h 19m"
shelf: watched
owned: false
rating: 
watched: 2007-05-03
poster: "https://image.tmdb.org/t/p/w500/qFmwhVUoUSXjkKRmca5yGDEXBIj.jpg"
---

# Spider-Man 3 (2007)

![](https://image.tmdb.org/t/p/w500/qFmwhVUoUSXjkKRmca5yGDEXBIj.jpg)

The seemingly invincible Spider-Man goes up against an all-new crop of villains—including the shape-shifting Sandman. While Spider-Man’s superpowers are altered by an alien organism, his alter ego, Peter Parker, deals with nemesis Eddie Brock and also gets caught up in a love triangle.