---
type: movie
country: US, GB
title: "The Golden Compass"
year: 2007
director: Chris Weitz
actors: [Nicole Kidman, Daniel Craig, Dakota Blue Richards, Ben Walker, Freddie Highmore]
genre: [Adventure, Fantasy]
length: "1h 53m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/mIHV28g4Zhbc8yhnhOixa8m4p5O.jpg"
---

# The Golden Compass (2007)

![](https://image.tmdb.org/t/p/w500/mIHV28g4Zhbc8yhnhOixa8m4p5O.jpg)

After overhearing a shocking secret, precocious orphan Lyra Belacqua trades her carefree existence roaming the halls of Jordan College for an otherworldly adventure in the far North, unaware that it's part of her destiny.
