---
type: movie
country: NZ
title: "Heavenly Creatures"
year: 1994
director: Peter Jackson
actors: [Melanie Lynskey, Kate Winslet, Sarah Peirse, Diana Kent, Clive Merrison]
genre: [Drama, Fantasy]
length: "1h 49m"
shelf: watched
owned: false
rating: 
watched: 1994-10-15
poster: "https://image.tmdb.org/t/p/w500/uvb86wVCIqD3Rlbr0GTNgWDF7Zo.jpg"
---

# Heavenly Creatures (1994)

![](https://image.tmdb.org/t/p/w500/uvb86wVCIqD3Rlbr0GTNgWDF7Zo.jpg)

Precocious teenager Juliet moves to New Zealand with her family and soon befriends the quiet, brooding Pauline through their shared love of fantasy and literature. This friendship gradually develops into an intense and obsessive bond.