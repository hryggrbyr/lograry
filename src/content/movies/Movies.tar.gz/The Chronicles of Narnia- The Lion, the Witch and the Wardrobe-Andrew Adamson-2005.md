---
type: movie
country: US, GB
title: "The Chronicles of Narnia: The Lion, the Witch and the Wardrobe"
year: 2005
director: Andrew Adamson
actors: [William Moseley, Anna Popplewell, Skandar Keynes, Georgie Henley, Liam Neeson]
genre: [Adventure, Family, Fantasy]
length: "2h 23m"
shelf: watched
owned: false
rating: 
watched: 2005-12-09
poster: "https://image.tmdb.org/t/p/w500/iREd0rNCjYdf5Ar0vfaW32yrkm.jpg"
---

# The Chronicles of Narnia: The Lion, the Witch and the Wardrobe (2005)

![](https://image.tmdb.org/t/p/w500/iREd0rNCjYdf5Ar0vfaW32yrkm.jpg)

Siblings Lucy, Edmund, Susan and Peter step through a magical wardrobe and find the land of Narnia. There, they discover a charming, once peaceful kingdom that has been plunged into eternal winter by the evil White Witch, Jadis. Aided by the wise and magnificent lion, Aslan, the children lead Narnia into a spectacular, climactic battle to be free of the Witch's glacial powers forever.