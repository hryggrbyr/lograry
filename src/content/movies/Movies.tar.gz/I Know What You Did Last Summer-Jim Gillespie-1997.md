---
type: movie
country: US
title: "I Know What You Did Last Summer"
year: 1997
director: Jim Gillespie
actors: [Jennifer Love Hewitt, Freddie Prinze Jr., Sarah Michelle Gellar, Ryan Phillippe, Bridgette Wilson-Sampras]
genre: [Horror, Thriller, Mystery]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/aYcLakDaAJtu2HtVvOXNx8inNlK.jpg"
---

# I Know What You Did Last Summer (1997)

![](https://image.tmdb.org/t/p/w500/aYcLakDaAJtu2HtVvOXNx8inNlK.jpg)

After an accident on a winding road, four teens make the fatal mistake of dumping their victim's body into the sea. Exactly one year later, the deadly secret resurfaces as they're stalked by a hook-handed figure.