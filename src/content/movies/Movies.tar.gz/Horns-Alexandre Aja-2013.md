---
type: movie
country: US
title: "Horns"
year: 2013
director: Alexandre Aja
actors: [Daniel Radcliffe, Juno Temple, Max Minghella, Joe Anderson, Kelli Garner]
genre: [Drama, Fantasy, Thriller]
length: "2h 0m"
shelf: watched
owned: false
rating: 
watched: 2014-10-03
poster: "https://image.tmdb.org/t/p/w500/tjTy6W05mPXXw87IqpjeGNhIcM4.jpg"
---

# Horns (2013)

![](https://image.tmdb.org/t/p/w500/tjTy6W05mPXXw87IqpjeGNhIcM4.jpg)

In the aftermath of his girlfriend's mysterious death, a young man awakens to strange horns sprouting from his temples.