---
type: movie
country: US
title: "Young Guns"
year: 1988
director: Christopher Cain
actors: [Emilio Estevez, Kiefer Sutherland, Lou Diamond Phillips, Charlie Sheen, Dermot Mulroney]
genre: [Western, Action, Adventure]
length: "1h 47m"
shelf: watched
owned: false
rating: 
watched: 1988-08-12
poster: "https://image.tmdb.org/t/p/w500/3AgCq7xY1rHRAAn0iVcnNr2OWL.jpg"
---

# Young Guns (1988)

![](https://image.tmdb.org/t/p/w500/3AgCq7xY1rHRAAn0iVcnNr2OWL.jpg)

A group of young gunmen, led by Billy the Kid, become deputies to avenge the murder of the rancher who became their benefactor. But when Billy takes their authority too far, they become the hunted.