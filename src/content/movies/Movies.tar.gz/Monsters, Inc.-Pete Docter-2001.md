---
type: movie
country: US
title: "Monsters, Inc."
year: 2001
director: Pete Docter
actors: [John Goodman, Billy Crystal, Mary Gibbs, Steve Buscemi, James Coburn]
genre: [Animation, Comedy, Family]
length: "1h 32m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/wFSpyMsp7H0ttERbxY7Trlv8xry.jpg"
---

# Monsters, Inc. (2001)

![](https://image.tmdb.org/t/p/w500/wFSpyMsp7H0ttERbxY7Trlv8xry.jpg)

Lovable Sulley and his wisecracking sidekick Mike Wazowski are the top scare team at Monsters, Inc., the scream-processing factory in Monstropolis. When a little girl named Boo wanders into their world, it's the monsters who are scared silly, and it's up to Sulley and Mike to keep her out of sight and get her back home.