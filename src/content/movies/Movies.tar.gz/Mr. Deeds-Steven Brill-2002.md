---
type: movie
country: US
title: "Mr. Deeds"
year: 2002
director: Steven Brill
actors: [Adam Sandler, Winona Ryder, John Turturro, Allen Covert, Peter Gallagher]
genre: [Comedy, Romance]
length: "1h 36m"
shelf: watched
owned: false
rating: 
watched: 2002-06-28
poster: "https://image.tmdb.org/t/p/w500/7gGk3pkpRsNlJ4PrJgEfgY9PG43.jpg"
---

# Mr. Deeds (2002)

![](https://image.tmdb.org/t/p/w500/7gGk3pkpRsNlJ4PrJgEfgY9PG43.jpg)

When Longfellow Deeds, a small-town pizzeria owner and poet, inherits $40 billion from his deceased uncle, he quickly begins rolling in a different kind of dough. Moving to the big city, Deeds finds himself besieged by opportunists all gunning for their piece of the pie. Babe, a television tabloid reporter, poses as an innocent small-town girl to do an exposé on Deeds.