---
type: movie
country: US
title: "Back to the Future"
year: 1985
director: Robert Zemeckis
actors: [Michael J. Fox, Christopher Lloyd, Crispin Glover, Lea Thompson, Claudia Wells]
genre: [Adventure, Comedy, Science Fiction]
length: "1h 56m"
shelf: watched
owned: false
rating: 
watched: 1985-07-03
poster: "https://image.tmdb.org/t/p/w500/vN5B5WgYscRGcQpVhHl6p9DDTP0.jpg"
---

# Back to the Future (1985)

![](https://image.tmdb.org/t/p/w500/vN5B5WgYscRGcQpVhHl6p9DDTP0.jpg)

Eighties teenager Marty McFly is accidentally sent back in time to 1955, inadvertently disrupting his parents' first meeting and attracting his mother's romantic interest. Marty must repair the damage to history by rekindling his parents' romance and - with the help of his eccentric inventor friend Doc Brown - return to 1985.