---
type: movie
country: United States, Ireland
title: "The Land Before Time"
year: 1988
director: Don Bluth
actors: [Pat Hingle, Gabriel Damon, Helen Shaver]
genre: [Animation, Adventure, Drama]
length: 69
shelf: watched
owned: false
rating: 
watched: 1988-12-31
poster: "https://m.media-amazon.com/images/M/MV5BYThiYTJkZjAtZWE1OS00YjI3LWEyZjQtZWVmMmI3NjNkYTg4XkEyXkFqcGc@._V1_SX300.jpg"
---

# The Land Before Time (1988)

![](https://m.media-amazon.com/images/M/MV5BYThiYTJkZjAtZWE1OS00YjI3LWEyZjQtZWVmMmI3NjNkYTg4XkEyXkFqcGc@._V1_SX300.jpg)

An orphaned brontosaurus teams up with other young dinosaurs in order to reunite with their families in a valley.