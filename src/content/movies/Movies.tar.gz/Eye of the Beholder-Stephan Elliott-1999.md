---
type: movie
country: Canada, United Kingdom, Australia, United States
title: "Eye of the Beholder"
year: 1999
director: Stephan Elliott
actors: [Ewan McGregor, Ashley Judd, Patrick Bergin]
genre: [Drama, Mystery, Thriller]
length: 109
shelf: watched
owned: true
rating: 
watched: 1999-12-31
poster: "https://m.media-amazon.com/images/M/MV5BZjE1NTI3NGYtMjAwZC00N2EwLTliY2MtNDliOTg2OWVjNjY0XkEyXkFqcGc@._V1_SX300.jpg"
---

# Eye of the Beholder (1999)

![](https://m.media-amazon.com/images/M/MV5BZjE1NTI3NGYtMjAwZC00N2EwLTliY2MtNDliOTg2OWVjNjY0XkEyXkFqcGc@._V1_SX300.jpg)

A private eye shadows a female serial killer of men all over the U.S. without her knowing as he, strangely enough, occasionally acts as her guardian angel.