---
type: movie
country: US
title: "Gladiator"
year: 2000
director: Ridley Scott
actors: [Russell Crowe, Joaquin Phoenix, Connie Nielsen, Oliver Reed, Richard Harris]
genre: [Action, Drama, Adventure]
length: "2h 35m"
shelf: watched
owned: false
rating: 
watched: 2000-05-05
poster: "https://image.tmdb.org/t/p/w500/ty8TGRuvJLPUmAR1H1nRIsgwvim.jpg"
---

# Gladiator (2000)

![](https://image.tmdb.org/t/p/w500/ty8TGRuvJLPUmAR1H1nRIsgwvim.jpg)

After the death of Emperor Marcus Aurelius, his devious son takes power and demotes Maximus, one of Rome's most capable generals who Marcus preferred. Eventually, Maximus is forced to become a gladiator and battle to the death against other men for the amusement of paying audiences.