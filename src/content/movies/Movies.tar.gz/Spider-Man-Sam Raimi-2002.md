---
type: movie
country: US
title: "Spider-Man"
year: 2002
director: Sam Raimi
actors: [Tobey Maguire, Willem Dafoe, Kirsten Dunst, James Franco, Cliff Robertson]
genre: [Action, Science Fiction]
length: "2h 1m"
shelf: watched
owned: false
rating: 
watched: 2002-05-03
poster: "https://image.tmdb.org/t/p/w500/gh4cZbhZxyTbgxQPxD0dOudNPTn.jpg"
---

# Spider-Man (2002)

![](https://image.tmdb.org/t/p/w500/gh4cZbhZxyTbgxQPxD0dOudNPTn.jpg)

After being bitten by a genetically altered spider at Oscorp, nerdy but endearing high school student Peter Parker is endowed with amazing powers to become the superhero known as Spider-Man.