---
type: movie
country: United States
title: "Rampage"
year: 2018
director: Brad Peyton
actors: [Dwayne Johnson, Naomie Harris, Malin Akerman]
genre: [Action, Adventure, Sci-Fi]
length: 107
shelf: watchlist
owned: false
rating: 
watched:
poster: "https://m.media-amazon.com/images/M/MV5BNDA1NjA3ODU3OV5BMl5BanBnXkFtZTgwOTg3MTIwNTM@._V1_SX300.jpg"
---

# Rampage (2018)

![](https://m.media-amazon.com/images/M/MV5BNDA1NjA3ODU3OV5BMl5BanBnXkFtZTgwOTg3MTIwNTM@._V1_SX300.jpg)

When three different animals become infected with a dangerous pathogen, a primatologist and a geneticist team up to stop them from destroying Chicago.