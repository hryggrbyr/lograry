---
type: movie
country: US, DE
title: "Red Dragon"
year: 2002
director: Brett Ratner
actors: [Edward Norton, Anthony Hopkins, Ralph Fiennes, Emily Watson, Harvey Keitel]
genre: [Crime, Thriller, Horror]
length: "2h 4m"
shelf: watched
owned: false
rating: 
watched: 2002-10-04
poster: "https://image.tmdb.org/t/p/w500/ou9ZKA2cms02b7CdCdVqGkKu0O0.jpg"
---

# Red Dragon (2002)

![](https://image.tmdb.org/t/p/w500/ou9ZKA2cms02b7CdCdVqGkKu0O0.jpg)

Former FBI Agent Will Graham, who was once almost killed by the savage Hannibal 'The Cannibal' Lecter, now has no choice but to face him again, as it seems Lecter is the only one who can help Graham track down a new serial killer.