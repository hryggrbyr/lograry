---
type: movie
country: US
title: "Toy Story"
year: 1995
director: John Lasseter
actors: [Tom Hanks, Tim Allen, Don Rickles, Jim Varney, Wallace Shawn]
genre: [Animation, Adventure, Family, Comedy]
length: "1h 21m"
shelf: watched
owned: false
rating: 
watched: 1995-11-22
poster: "https://image.tmdb.org/t/p/w500/uXDfjJbdP4ijW5hWSBrPrlKpxab.jpg"
---

# Toy Story (1995)

![](https://image.tmdb.org/t/p/w500/uXDfjJbdP4ijW5hWSBrPrlKpxab.jpg)

Led by Woody, Andy's toys live happily in his room until Andy's birthday brings Buzz Lightyear onto the scene. Afraid of losing his place in Andy's heart, Woody plots against Buzz. But when circumstances separate Buzz and Woody from their owner, the duo eventually learns to put aside their differences.