---
type: movie
country: US
title: "The Wicker Man"
year: 2006
director: Neil LaBute
actors: [Nicolas Cage, Ellen Burstyn, Kate Beahan, Frances Conroy, Molly Parker]
genre: [Horror, Mystery, Thriller]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 2006-09-01
poster: "https://image.tmdb.org/t/p/w500/xsHrmfgDcEk5fGhSiieKvrDuofq.jpg"
---

# The Wicker Man (2006)

![](https://image.tmdb.org/t/p/w500/xsHrmfgDcEk5fGhSiieKvrDuofq.jpg)

A sheriff investigating the disappearance of a young girl from a small island discovers there's a larger mystery to solve among the island's secretive, neo-pagan community.