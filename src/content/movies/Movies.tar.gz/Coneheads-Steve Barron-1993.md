---
type: movie
country: US
title: "Coneheads"
year: 1993
director: Steve Barron
actors: [Dan Aykroyd, Jane Curtin, Michael McKean, Laraine Newman, Jason Alexander]
genre: [Comedy, Science Fiction]
length: "1h 27m"
shelf: watched
owned: false
rating: 
watched: 1993-07-23
poster: "https://image.tmdb.org/t/p/w500/vlpQnf0rl0FpMjWLS0TNd8Bog2F.jpg"
---

# Coneheads (1993)

![](https://image.tmdb.org/t/p/w500/vlpQnf0rl0FpMjWLS0TNd8Bog2F.jpg)

A pair of aliens arrive on Earth to prepare for invasion, but crash instead. With enormous cone-shaped heads, robotlike walks and an appetite for toilet paper, aliens Beldar and Prymatt don't exactly blend in with the population of Paramus, N.J. But for some reason, everyone believes them when they say they're from France.