---
type: movie
country: Ireland, Denmark, Belgium, France, Luxembourg
title: "Song of the Sea"
year: 2014
director: Tomm Moore
actors: [David Rawle, Brendan Gleeson, Lisa Hannigan]
genre: [Animation, Adventure, Drama]
length: 93
shelf: watched
owned: false
rating: 4
watched: 2025-10-21
poster: "https://m.media-amazon.com/images/M/MV5BMTQ2MDMwNjEwNV5BMl5BanBnXkFtZTgwOTkxMzI0MzE@._V1_SX300.jpg"
---

# Song of the Sea (2014)

![](https://m.media-amazon.com/images/M/MV5BMTQ2MDMwNjEwNV5BMl5BanBnXkFtZTgwOTkxMzI0MzE@._V1_SX300.jpg)

Ben, a young Irish boy, and his little sister Saoirse, a girl who can turn into a seal, go on an adventure to free the fairies and save the spirit world.