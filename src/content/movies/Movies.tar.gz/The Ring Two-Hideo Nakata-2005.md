---
type: movie
country: United States
title: The Ring Two
year: 2005
director: Hideo Nakata
actors: [Naomi Watts, David Dorfman, Sissy Spacek]
genre: [Horror, Mystery]
length: 110
shelf: watched
owned: true
rating: 
watched: 2005-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMTY2ODc2NTQ2OF5BMl5BanBnXkFtZTYwNzA4OTU3._V1_SX300.jpg"
---

# The Ring Two (2005)

![](https://m.media-amazon.com/images/M/MV5BMTY2ODc2NTQ2OF5BMl5BanBnXkFtZTYwNzA4OTU3._V1_SX300.jpg)

Six months after the incidents involving the lethal videotape, new clues prove that there is a new evil lurking in the darkness.