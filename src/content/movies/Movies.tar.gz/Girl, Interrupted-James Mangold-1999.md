---
type: movie
country: US
title: "Girl, Interrupted"
year: 1999
director: James Mangold
actors: [Winona Ryder, Angelina Jolie, Clea DuVall, Brittany Murphy, Elisabeth Moss]
genre: [Drama]
length: "2h 7m"
shelf: watched
owned: false
rating: 
watched: 1999-12-21
poster: "https://image.tmdb.org/t/p/w500/dOBdatHIVppvmRFw2z7bf9VKJr9.jpg"
---

# Girl, Interrupted (1999)

![](https://image.tmdb.org/t/p/w500/dOBdatHIVppvmRFw2z7bf9VKJr9.jpg)

Set in the changing world of the late 1960s, Susanna Kaysen's prescribed "short rest" from a psychiatrist she had met only once becomes a strange, unknown journey into Alice's Wonderland, where she struggles with the thin line between normal and crazy. Susanna soon realizes how hard it is to get out once she has been committed, and she ultimately has to choose between the world of people who belong inside or the difficult world of reality outside.