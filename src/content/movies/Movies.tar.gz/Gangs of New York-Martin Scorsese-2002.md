---
type: movie
country: US
title: "Gangs of New York"
year: 2002
director: Martin Scorsese
actors: [Leonardo DiCaprio, Daniel Day-Lewis, Cameron Diaz, Jim Broadbent, John C. Reilly]
genre: [Drama, History, Crime]
length: "2h 48m"
shelf: watched
owned: false
rating: 
watched: 2002-12-19
poster: "https://image.tmdb.org/t/p/w500/lemqKtcCuAano5aqrzxYiKC8kkn.jpg"
---

# Gangs of New York (2002)

![](https://image.tmdb.org/t/p/w500/lemqKtcCuAano5aqrzxYiKC8kkn.jpg)

In early 1860s New York, Irish immigrant Amsterdam Vallon is released from prison and returns to the Five Points, seeking revenge against his father's killer, William Cutting, a powerful anti-immigrant gang leader. He knows that revenge can only be attained by infiltrating Cutting's inner circle. Vallon's journey becomes a fight for personal survival and to find a place for the Irish people.