---
type: series
country: GB
title: "Douglas Is Cancelled"
year: 2024
director: Ben Palmer
actors: [Hugh Bonneville, Karen Gillan, Ben Miles, Alex Kingston, Nick Mohammed]
genre: [Drama, Comedy]
length: "1 season (4 episodes)"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/yjw2KjAFnqPzCNOYgh3yiLQOZl5.jpg"
---

# Douglas Is Cancelled (2024)

![](https://image.tmdb.org/t/p/w500/yjw2KjAFnqPzCNOYgh3yiLQOZl5.jpg)

The career of respected news presenter Douglas is threatened after he makes an ill-advised joke. With her 2 million social media followers, tech-savvy co-anchor Madeline could throw Douglas a lifeline by posting in his defense… but will she?
