---
type: movie
country: US
title: "Indecent Proposal"
year: 1993
director: Adrian Lyne
actors: [Robert Redford, Demi Moore, Woody Harrelson, Seymour Cassel, Oliver Platt]
genre: [Romance, Drama]
length: "1h 57m"
shelf: watched
owned: false
rating: 
watched: 1993-04-07
poster: "https://image.tmdb.org/t/p/w500/a39WoiTJEG5kNLIrr3kOMwg3LFg.jpg"
---

# Indecent Proposal (1993)

![](https://image.tmdb.org/t/p/w500/a39WoiTJEG5kNLIrr3kOMwg3LFg.jpg)

John Gage offers a down-on-his-luck yuppie husband $1 million for the opportunity to spend the night with the man's wife.