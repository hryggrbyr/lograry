---
type: movie
country: CA, US
title: "Angel Falls Christmas"
year: 2021
director: Jerry Ciccoritti
actors: [Chad Michael Murray, Jessica Lowndes, David Reale, Samora Smallwood, Jane Luk]
genre: [TV Movie, Comedy, Romance, Christmas]
length: "1h 25m"
shelf: watched
owned: false
rating: 
watched: 2021-12-12
poster: "https://image.tmdb.org/t/p/w500/7A4sPNcTnwtHW2lPaPrKHFVSMON.jpg"
---

# Angel Falls Christmas (2021)

![](https://image.tmdb.org/t/p/w500/7A4sPNcTnwtHW2lPaPrKHFVSMON.jpg)

A devoted doctor with little time for the Christmas spirit is in desperate need of an intervention from the unlikeliest of places.