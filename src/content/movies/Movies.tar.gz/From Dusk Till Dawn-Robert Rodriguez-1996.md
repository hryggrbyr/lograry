---
type: movie
country: US
title: "From Dusk Till Dawn"
year: 1996
director: Robert Rodriguez
actors: [George Clooney, Quentin Tarantino, Harvey Keitel, Juliette Lewis, Ernest Liu]
genre: [Horror, Action, Thriller, Crime]
length: "1h 48m"
shelf: watched
owned: false
rating: 
watched: 1996-01-19
poster: "https://image.tmdb.org/t/p/w500/uBoQytp3KTQFaVqTe6d0ECGaKh9.jpg"
---

# From Dusk Till Dawn (1996)

![](https://image.tmdb.org/t/p/w500/uBoQytp3KTQFaVqTe6d0ECGaKh9.jpg)

After kidnapping a father and his two kids, the Gecko brothers head south to a seedy Mexican bar to hide out in safety, unaware of its notorious vampire clientele.