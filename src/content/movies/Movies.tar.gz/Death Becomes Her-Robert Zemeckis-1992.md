---
type: movie
country: United States
title: "Death Becomes Her"
year: 1992
director: Robert Zemeckis
actors: [Meryl Streep, Bruce Willis, Goldie Hawn]
genre: [Comedy, Fantasy, Horror]
length: 104
shelf: watched
owned: false
rating: 
watched: 1992-12-31
poster: "https://m.media-amazon.com/images/M/MV5BNTczYmEyMmEtMmJlYi00YjI2LTg3MzUtMzEyODUwYWYzNjJhXkEyXkFqcGc@._V1_SX300.jpg"
---

# Death Becomes Her (1992)

![](https://m.media-amazon.com/images/M/MV5BNTczYmEyMmEtMmJlYi00YjI2LTg3MzUtMzEyODUwYWYzNjJhXkEyXkFqcGc@._V1_SX300.jpg)

When a fading actress learns of an immortality treatment, she sees it as a way to outdo her long-time rival.