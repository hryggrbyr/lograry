---
type: movie
country: GB
title: "Peter Pan's Neverland Nightmare"
year: 2025
director: Scott Chambers
actors: [Megan Placito, Martin Portlock, Kit Green, Peter DeSouza-Feighoney, Teresa Banham]
genre: [Horror, Thriller, Fantasy]
length: "1h 29m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/rhTG3gMlJa0nFlOS7WNKUJ2EDro.jpg"
---

# Peter Pan's Neverland Nightmare (2025)

![](https://image.tmdb.org/t/p/w500/rhTG3gMlJa0nFlOS7WNKUJ2EDro.jpg)

Wendy Darling strikes out in an attempt to rescue her brother Michael from the clutches of the evil Peter Pan who intends to send him to Neverland. Along the way she meets a twisted Tinkerbell, who is hooked on what she thinks is fairy dust.
