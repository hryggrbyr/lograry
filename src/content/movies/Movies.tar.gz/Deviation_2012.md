---
type: movie
country: US, GB
title: "Deviation"
year: 2012
director: J.K. Amalou
actors: [Danny Dyer, Anna Walton, James Doherty, David Fynn, Alan McKenna]
genre: [Thriller]
length: "1h 30m"
shelf: watchlist
owned: false
rating:
watched: 
poster: "https://image.tmdb.org/t/p/w500/piGTxfUy1S1yrS5ZjwXfo0Uolrl.jpg"
---

# Deviation (2012)

![](https://image.tmdb.org/t/p/w500/piGTxfUy1S1yrS5ZjwXfo0Uolrl.jpg)

Told over one horrifying night, Deviation will take you on a white-knuckle journey into the mind of Frank Norton, a dangerous schizophrenic murderer as he escapes from Broadmoor Hospital and embarks on a murderous rampage across London. But when Frankie takes a hostage, the deadly game of cat-and-mouse truly begins.
