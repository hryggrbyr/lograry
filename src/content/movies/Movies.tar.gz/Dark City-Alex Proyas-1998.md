---
type: movie
country: AU
title: "Dark City"
year: 1998
director: Alex Proyas
actors: [Rufus Sewell, William Hurt, Kiefer Sutherland, Jennifer Connelly, Richard O'Brien]
genre: [Mystery, Science Fiction]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 1998-02-27
poster: "https://image.tmdb.org/t/p/w500/tNPEGju4DpTdbhBphNmZoEi9Bd3.jpg"
---

# Dark City (1998)

![](https://image.tmdb.org/t/p/w500/tNPEGju4DpTdbhBphNmZoEi9Bd3.jpg)

A man struggles with memories of his past, including a wife he cannot remember, in a nightmarish world with no sun and run by beings with telekinetic powers who seek the souls of humans.