---
type: movie
country: GB
title: "In Bruges"
year: 2008
director: Martin McDonagh
actors: [Colin Farrell, Brendan Gleeson, Ralph Fiennes, Clémence Poésy, Thekla Reuten]
genre: [Comedy, Drama, Crime]
length: "1h 48m"
shelf: watched
owned: false
rating: 
watched: 2008-02-29
poster: "https://image.tmdb.org/t/p/w500/jMiBBqk72VRo1Y39x2ZbbenEU3a.jpg"
---

# In Bruges (2008)

![](https://image.tmdb.org/t/p/w500/jMiBBqk72VRo1Y39x2ZbbenEU3a.jpg)

Ray and Ken, two hit men, are in Bruges, Belgium, waiting for their next mission. While they are there they have time to think and discuss their previous assignment. When the mission is revealed to Ken, it is not what he expected.