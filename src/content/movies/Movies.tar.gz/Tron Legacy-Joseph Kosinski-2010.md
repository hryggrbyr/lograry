---
type: movie
country: United States, India, United Kingdom, Mexico, Japan, Canada
title: "Tron: Legacy"
year: 2010
director: Joseph Kosinski
actors: [Jeff Bridges, Garrett Hedlund, Olivia Wilde]
genre: [Action, Adventure, Sci-Fi]
length: 125
shelf: watched
owned: false
rating: 
watched: 2010-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMTk4NTk4MTk1OF5BMl5BanBnXkFtZTcwNTE2MDIwNA@@._V1_SX300.jpg"
---

# Tron Legacy (2010)

![](https://m.media-amazon.com/images/M/MV5BMTk4NTk4MTk1OF5BMl5BanBnXkFtZTcwNTE2MDIwNA@@._V1_SX300.jpg)

The son of a computer programmer goes looking for his father and ends up inside the digital world that his father designed. He meets his father's corrupted creation and a unique ally who was born inside the digital world.