---
type: movie
country: US
title: "Scrooged"
year: 1988
director: Richard Donner
actors: [Bill Murray, Karen Allen, John Forsythe, John Glover, Bobcat Goldthwait]
genre: [Fantasy, Comedy, Drama, Christmas]
length: "1h 41m"
shelf: watched
owned: false
rating: 
watched: 2024-12-24
poster: "https://image.tmdb.org/t/p/w500/uO0znfB2ZzTXA1IS7jkrjNbpkYK.jpg"
---

# Scrooged (1988)

![](https://image.tmdb.org/t/p/w500/uO0znfB2ZzTXA1IS7jkrjNbpkYK.jpg)

Frank Cross is a wildly successful television executive whose cold ambition and curmudgeonly nature has driven away the love of his life. But after firing a staff member on Christmas Eve, Frank is visited by a series of ghosts who give him a chance to re-evaluate his actions and right the wrongs of his past.