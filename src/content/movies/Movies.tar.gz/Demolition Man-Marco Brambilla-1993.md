---
type: movie
country: US
title: "Demolition Man"
year: 1993
director: Marco Brambilla
actors: [Sylvester Stallone, Wesley Snipes, Sandra Bullock, Nigel Hawthorne, Benjamin Bratt]
genre: [Crime, Action, Science Fiction]
length: "1h 55m"
shelf: watched
owned: false
rating: 
watched: 1993-10-08
poster: "https://image.tmdb.org/t/p/w500/dq6AmlVFo92PRuoLCcIyFdoRuxf.jpg"
---

# Demolition Man (1993)

![](https://image.tmdb.org/t/p/w500/dq6AmlVFo92PRuoLCcIyFdoRuxf.jpg)

In 1996, brash L.A. detective John Spartan and maniac killer Simon Phoenix are both sentenced to decades in a cryogenic prison as punishment for a rescue mission gone wrong. When Phoenix escapes 36 years later to wreak havoc on the future, Spartan is awakened to capture his nemesis the old-fashioned way.