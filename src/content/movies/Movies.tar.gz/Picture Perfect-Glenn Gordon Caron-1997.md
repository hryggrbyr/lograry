---
type: movie
country: US
title: "Picture Perfect"
year: 1997
director: Glenn Gordon Caron
actors: [Jennifer Aniston, Jay Mohr, Kevin Bacon, Olympia Dukakis, Illeana Douglas]
genre: [Romance, Comedy, Drama]
length: "1h 45m"
shelf: watched
owned: false
rating: 
watched: 1997-08-01
poster: "https://image.tmdb.org/t/p/w500/xYnvr4o7GEaA2uyt4Q1ASUI5Obv.jpg"
---

# Picture Perfect (1997)

![](https://image.tmdb.org/t/p/w500/xYnvr4o7GEaA2uyt4Q1ASUI5Obv.jpg)

A young advertising executive's life becomes increasingly complicated when, in order to impress her boss, she pretends to be engaged to a man she has just met.