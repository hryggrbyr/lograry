---
type: movie
country: US
title: "Wrong Turn"
year: 2003
director: Rob Schmidt
actors: [Eliza Dushku, Desmond Harrington, Emmanuelle Chriqui, Jeremy Sisto, Kevin Zegers]
genre: [Horror, Thriller]
length: "1h 24m"
shelf: watched
owned: false
rating: 
watched: 2003-05-30
poster: "https://image.tmdb.org/t/p/w500/7lyxwOg7SdGff79yKCQmJ3AKWSf.jpg"
---

# Wrong Turn (2003)

![](https://image.tmdb.org/t/p/w500/7lyxwOg7SdGff79yKCQmJ3AKWSf.jpg)

Chris crashes into a carload of other young people, and the group of stranded motorists is soon lost in the woods of West Virginia, where they're hunted by three cannibalistic mountain men who are grossly disfigured by generations of inbreeding.