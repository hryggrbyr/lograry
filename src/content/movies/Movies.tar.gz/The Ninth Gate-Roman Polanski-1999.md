---
type: movie
country: US
title: "The Ninth Gate"
year: 1999
director: Roman Polanski
actors: [Johnny Depp, Frank Langella, Lena Olin, Emmanuelle Seigner, Barbara Jefford]
genre: [Mystery, Thriller, Horror]
length: "2h 13m"
shelf: watched
owned: false
rating: 
watched: 1999-08-27
poster: "https://image.tmdb.org/t/p/w500/iFDtmA8Bg9zE4NcsjcmGfqFN01H.jpg"
---

# The Ninth Gate (1999)

![](https://image.tmdb.org/t/p/w500/iFDtmA8Bg9zE4NcsjcmGfqFN01H.jpg)

A rare book dealer finds himself at the heart of a string of paranormal events when he is hired to find the last two copies of a text, The Nine Gates of the Kingdom of Shadows, capable of summoning the Devil.