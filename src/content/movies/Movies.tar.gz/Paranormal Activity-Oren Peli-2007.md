---
type: movie
country: US
title: "Paranormal Activity"
year: 2007
director: Oren Peli
actors: [Katie Featherston, Micah Sloat, Mark Fredrichs, Amber Armstrong, Ashley Palmer]
genre: [Horror, Mystery]
length: "1h 26m"
shelf: watched
owned: false
rating: 
watched: 2007-09-14
poster: "https://image.tmdb.org/t/p/w500/tmclkEpjeo4Zu564gf3KrwIOuKw.jpg"
---

# Paranormal Activity (2007)

![](https://image.tmdb.org/t/p/w500/tmclkEpjeo4Zu564gf3KrwIOuKw.jpg)

After a young, middle-class couple moves into what seems like a typical suburban house, they become increasingly disturbed by a presence that may or may not be demonic but is certainly the most active in the middle of the night.