---
type: movie
country: US
title: "The Christmas Chronicles"
year: 2018
director: Clay Kaytis
actors: [Darby Camp, Judah Lewis, Kurt Russell, Martin Roach, Lamorne Morris]
genre: [Comedy, Adventure, Family, Fantasy, Christmas]
length: "1h 44m"
shelf: watched
owned: false
rating: 
watched: 2023-11-26
poster: "https://image.tmdb.org/t/p/w500/5Il2EMSF2KecrUKZPuen6BZmaCP.jpg"
---

# The Christmas Chronicles (2018)

![](https://image.tmdb.org/t/p/w500/5Il2EMSF2KecrUKZPuen6BZmaCP.jpg)

Siblings Kate and Teddy try to prove Santa Claus is real, but when they accidentally cause his sleigh to crash, they have to save Christmas.