---
type: movie
country: US
title: "Coraline"
year: 2009
director: Henry Selick
actors: [Dakota Fanning, Teri Hatcher, Jennifer Saunders, Dawn French, Keith David]
genre: [Animation, Family, Fantasy]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 2009-02-06
poster: "https://image.tmdb.org/t/p/w500/4jeFXQYytChdZYE9JYO7Un87IlW.jpg"
---

# Coraline (2009)

![](https://image.tmdb.org/t/p/w500/4jeFXQYytChdZYE9JYO7Un87IlW.jpg)

Wandering her rambling old house in her boring new town, 11-year-old Coraline discovers a hidden door to a strangely idealized version of her life. In order to stay in the fantasy, she must make a frighteningly real sacrifice.