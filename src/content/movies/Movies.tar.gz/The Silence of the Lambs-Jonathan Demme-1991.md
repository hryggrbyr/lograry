---
type: movie
country: US
title: "The Silence of the Lambs"
year: 1991
director: Jonathan Demme
actors: [Jodie Foster, Anthony Hopkins, Scott Glenn, Ted Levine, Anthony Heald]
genre: [Crime, Thriller, Drama]
length: "1h 59m"
shelf: watched
owned: false
rating: 
watched: 1991-02-14
poster: "https://image.tmdb.org/t/p/w500/uS9m8OBk1A8eM9I042bx8XXpqAq.jpg"
---

# The Silence of the Lambs (1991)

![](https://image.tmdb.org/t/p/w500/uS9m8OBk1A8eM9I042bx8XXpqAq.jpg)

Clarice Starling is a top student at the FBI's training academy.  Jack Crawford wants Clarice to interview Dr. Hannibal Lecter, a brilliant psychiatrist who is also a violent psychopath, serving life behind bars for various acts of murder and cannibalism.  Crawford believes that Lecter may have insight into a case and that Starling, as an attractive young woman, may be just the bait to draw him out.