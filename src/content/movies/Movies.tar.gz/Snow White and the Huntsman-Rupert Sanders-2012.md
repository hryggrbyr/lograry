---
type: movie
country: United Kingdom, Japan, United States
title: "Snow White and the Huntsman"
year: 2012
director: Rupert Sanders
actors: [Kristen Stewart, Chris Hemsworth, Charlize Theron]
genre: [Action, Adventure, Drama]
length: 127
shelf: watched
owned: false
rating: 
watched: 2012-12-31
poster: "https://m.media-amazon.com/images/M/MV5BY2JjYWUyZjUtMDg3OS00MGIyLTgyN2QtYjIyY2VlYzViYThlXkEyXkFqcGc@._V1_SX300.jpg"
---

# Snow White and the Huntsman (2012)

![](https://m.media-amazon.com/images/M/MV5BY2JjYWUyZjUtMDg3OS00MGIyLTgyN2QtYjIyY2VlYzViYThlXkEyXkFqcGc@._V1_SX300.jpg)

In a twist to the fairy tale, the Huntsman ordered to take Snow White into the woods to be killed winds up becoming her protector and mentor in a quest to vanquish the Evil Queen.