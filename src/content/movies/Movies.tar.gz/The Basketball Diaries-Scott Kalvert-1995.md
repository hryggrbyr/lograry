---
type: movie
country: US
title: "The Basketball Diaries"
year: 1995
director: Scott Kalvert
actors: [Leonardo DiCaprio, Mark Wahlberg, James Madio, Lorraine Bracco, Patrick McGaw]
genre: [Drama, Crime]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 1995-04-21
poster: "https://image.tmdb.org/t/p/w500/AhvO1GGDPIgN0hOqZEgaFCbswMK.jpg"
---

# The Basketball Diaries (1995)

![](https://image.tmdb.org/t/p/w500/AhvO1GGDPIgN0hOqZEgaFCbswMK.jpg)

A high school basketball player’s life turns upside down after free-falling into the harrowing world of drug addiction.