---
type: movie
country: US
title: "Gone in Sixty Seconds"
year: 2000
director: Dominic Sena
actors: [Nicolas Cage, Angelina Jolie, Giovanni Ribisi, Robert Duvall, Delroy Lindo]
genre: [Action, Crime, Thriller]
length: "1h 58m"
shelf: watched
owned: false
rating: 
watched: 2000-06-09
poster: "https://image.tmdb.org/t/p/w500/fToQDmkBtiXYGh9xfgAh3gpo6GZ.jpg"
---

# Gone in Sixty Seconds (2000)

![](https://image.tmdb.org/t/p/w500/fToQDmkBtiXYGh9xfgAh3gpo6GZ.jpg)

Upon learning that he has to come out of retirement to steal 50 cars in one night to save his brother Kip's life, former car thief Randall "Memphis" Raines enlists help from a few "boost happy" pals to accomplish a seemingly impossible feat. From countless car chases to relentless cops, the high-octane excitement builds as Randall swerves around more than a few roadblocks to keep Kip alive.