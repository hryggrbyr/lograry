---
type: movie
country: US
title: "Family Switch"
year: 2023
director: McG
actors: [Jennifer Garner, Ed Helms, Emma Myers, Brady Noon, Rita Moreno]
genre: [Comedy, Fantasy, Family, Christmas]
length: "1h 46m"
shelf: watched
owned: false
rating: 
watched: 2023-12-02
poster: "https://image.tmdb.org/t/p/w500/xUJJXVugggonJ0hpWtj9Qsxode1.jpg"
---

# Family Switch (2023)

![](https://image.tmdb.org/t/p/w500/xUJJXVugggonJ0hpWtj9Qsxode1.jpg)

When the Walker family members switch bodies with each other during a rare planetary alignment, their hilarious journey to find their way back to normal will bring them closer together than they ever thought possible.