---
type: movie
country: US
title: "The Dark Knight"
year: 2008
director: Christopher Nolan
actors: [Christian Bale, Heath Ledger, Aaron Eckhart, Michael Caine, Maggie Gyllenhaal]
genre: [Drama, Action, Crime, Thriller]
length: "2h 32m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg"
---

# The Dark Knight (2008)

![](https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg)

Batman raises the stakes in his war on crime. With the help of Lt. Jim Gordon and District Attorney Harvey Dent, Batman sets out to dismantle the remaining criminal organizations that plague the streets. The partnership proves to be effective, but they soon find themselves prey to a reign of chaos unleashed by a rising criminal mastermind known to the terrified citizens of Gotham as the Joker.