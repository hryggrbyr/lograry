---
type: movie
country: US
title: "When Harry Met Sally..."
year: 1989
director: Rob Reiner
actors: [Billy Crystal, Meg Ryan, Carrie Fisher, Bruno Kirby, Steven Ford]
genre: [Comedy, Romance, Drama]
length: "1h 36m"
shelf: watched
owned: false
rating: 
watched: 1989-07-21
poster: "https://image.tmdb.org/t/p/w500/rFOiFUhTMtDetqCGClC9PIgnC1P.jpg"
---

# When Harry Met Sally... (1989)

![](https://image.tmdb.org/t/p/w500/rFOiFUhTMtDetqCGClC9PIgnC1P.jpg)

Sex always gets in the way of friendships between men and women. At least, that's what Harry Burns believes. So when Harry meets Sally Albright and a deep friendship blossoms between them, Harry's determined not to let his attraction to Sally destroy it. But when a night of weakness ends in a morning of panic, can the pair avoid succumbing to Harry's fears by remaining friends and admitting they just might be the perfect match for each other?