---
type: series
country: GB, CA, FR
title: "Redwall"
year: 1999
director: Raymond Jafelice
actors: [Jake Goldsbie, Melissa McIntyre, Al Mukaddam, Alison Pill, Amos Crawley]
genre: [Adventure, Animation, fantasy, TalkingAnimals]
length: "3 seasons (39 episodes)"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/vLXvgV2bpqPuva4k0jCSJ4kidRZ.jpg"
---

# Redwall (1999)

![](https://image.tmdb.org/t/p/w500/vLXvgV2bpqPuva4k0jCSJ4kidRZ.jpg)

To save his besieged Abbey, a young mouse novice must learn of his destiny to be the successor to a great warrior.
