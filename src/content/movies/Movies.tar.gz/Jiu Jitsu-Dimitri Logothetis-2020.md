---
type: movie
country: United States
title: "Jiu Jitsu"
year: 2020
director: Dimitri Logothetis
actors: [Alain Moussi, Nicolas Cage, Raymond Pinharry]
genre: [Action, Sci-Fi, Thriller]
length: 102
shelf: watchlist
owned: false
rating: 
watched: 
poster: "https://m.media-amazon.com/images/M/MV5BNDY5MDk2YmEtMWYxYy00Nzc2LTgzZmItMGYxMjk0NTI1MTczXkEyXkFqcGc@._V1_SX300.jpg"
---

# Jiu Jitsu (2020)

![](https://m.media-amazon.com/images/M/MV5BNDY5MDk2YmEtMWYxYy00Nzc2LTgzZmItMGYxMjk0NTI1MTczXkEyXkFqcGc@._V1_SX300.jpg)

Every six years, an ancient order of jiu-jitsu fighters joins forces to battle a vicious race of alien invaders. But when a celebrated war hero goes down in defeat, the fate of the planet and mankind hangs in the balance.