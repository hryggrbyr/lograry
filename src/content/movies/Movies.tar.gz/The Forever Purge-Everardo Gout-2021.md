---
type: movie
country: China, United States
title: "The Forever Purge"
year: 2021
director: Everardo Gout
actors: [Ana de la Reguera, Tenoch Huerta, Josh Lucas]
genre: [Action, Crime, Drama]
length: 103
shelf: watched
owned: false
rating: 
watched: 2021-12-31
poster: "https://m.media-amazon.com/images/M/MV5BZWVmYmE5ZWQtY2E3NC00Mzk1LWEzMzYtNjkyM2E0MGY0MjcxXkEyXkFqcGc@._V1_SX300.jpg"
---

# The Forever Purge (2021)

![](https://m.media-amazon.com/images/M/MV5BZWVmYmE5ZWQtY2E3NC00Mzk1LWEzMzYtNjkyM2E0MGY0MjcxXkEyXkFqcGc@._V1_SX300.jpg)

All the rules are broken as a sect of lawless marauders decides that the annual Purge does not stop at daybreak and instead should never end.