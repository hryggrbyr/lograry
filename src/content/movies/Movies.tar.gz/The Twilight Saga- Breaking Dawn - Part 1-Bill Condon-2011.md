---
type: movie
country: US
title: "The Twilight Saga: Breaking Dawn - Part 1"
year: 2011
director: Bill Condon
actors: [Kristen Stewart, Robert Pattinson, Taylor Lautner, Billy Burke, Peter Facinelli]
genre: [Adventure, Fantasy, Romance]
length: "1h 57m"
shelf: watched
owned: false
rating: 
watched: 2011-11-17
poster: "https://image.tmdb.org/t/p/w500/qs8LsHKYlVRmJbFUiSUhhRAygwj.jpg"
---

# The Twilight Saga: Breaking Dawn - Part 1 (2011)

![](https://image.tmdb.org/t/p/w500/qs8LsHKYlVRmJbFUiSUhhRAygwj.jpg)

Bella Swan and Edward Cullen's honeymoon phase is abruptly disrupted by betrayals and unforeseen tragedies that endanger their world.