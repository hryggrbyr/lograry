---
type: movie
country: GB
title: "That Christmas"
year: 2024
director: Simon Otto
actors: [Brian Cox, Bill Nighy, Fiona Shaw, Jack Wisniewski, Jodie Whittaker]
genre: [Animation, Comedy, Family, Fantasy, Adventure, Christmas]
length: "1h 31m"
shelf: watched
owned: false
rating: 
watched: 2024-12-09
poster: "https://image.tmdb.org/t/p/w500/uR3uhztTAxGGK7Co0yyxVy4Gc7H.jpg"
---

# That Christmas (2024)

![](https://image.tmdb.org/t/p/w500/uR3uhztTAxGGK7Co0yyxVy4Gc7H.jpg)

It's an unforgettable Christmas for the townsfolk of Wellington-on-Sea when the worst snowstorm in history alters everyone's plans — including Santa's.