---
type: movie
country: Australia
title: Romper Stomper
year: 1992
director: Geoffrey Wright
actors: [Russell Crowe, Daniel Pollock, Jacqueline McKenzie]
genre: [Crime, Drama, Thriller]
length: 94
shelf: watched
owned: false
rating: 
watched: 1992-12-31
poster: "https://m.media-amazon.com/images/M/MV5BODUxYmUxZDUtZTA4Yi00NDY0LWI3NGUtODk1YjAwMzAxYTg4XkEyXkFqcGc@._V1_SX300.jpg"
---

# Romper Stomper (1992)

![](https://m.media-amazon.com/images/M/MV5BODUxYmUxZDUtZTA4Yi00NDY0LWI3NGUtODk1YjAwMzAxYTg4XkEyXkFqcGc@._V1_SX300.jpg)

A group of skinheads become alarmed at the way their neighbourhood is changing.