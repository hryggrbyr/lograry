---
type: movie
country: US
title: "The Bad Guys: A Very Bad Holiday"
year: 2023
director: Bret Haaland
actors: [Michael Godere, Ezekiel Ajeigbe, Raul Ceballos, Chris Diamantopoulos, Mallory Low]
genre: [Animation, Comedy, Family, Action, Christmas]
length: "26m"
shelf: watched
owned: false
rating: 
watched: 2024-12-02
poster: "https://image.tmdb.org/t/p/w500/er0Gth3Tr279hFq1xeKdYxhcleO.jpg"
---

# The Bad Guys: A Very Bad Holiday (2023)

![](https://image.tmdb.org/t/p/w500/er0Gth3Tr279hFq1xeKdYxhcleO.jpg)

To keep their annual Holiday Heist-tacular afloat, Mr. Wolf and his crew of animal outlaws will have to restore the whole city's Christmas spirit — fast!