---
type: movie
country: US
title: "No Vacancy"
year: 1999
director: Marius Weisberg
actors: [Christina Ricci, Lolita Davidovich, Olek Krupa, Timothy Olyphant, Joaquim de Almeida]
genre: [Comedy, Drama, Romance]
length: "1h 24m"
shelf: watched
owned: false
rating: 
watched: 1999-04-16
poster: "https://image.tmdb.org/t/p/w500/2WSdY6kRIpc5MgqyOtWhAsVmxtN.jpg"
---

# No Vacancy (1999)

![](https://image.tmdb.org/t/p/w500/2WSdY6kRIpc5MgqyOtWhAsVmxtN.jpg)

In a surreal motel in Los Angeles, the life of several sordid characters intertwine.