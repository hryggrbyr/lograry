---
type: movie
country: US
title: "The Blair Witch Project"
year: 1999
director: Daniel Myrick, Eduardo Sánchez
actors: [Rei Hance, Joshua Leonard, Michael C. Williams, Bob Griffin, Jim King]
genre: [Horror, Mystery]
length: "1h 21m"
shelf: watched
owned: false
rating: 
watched: 1999-07-14
poster: "https://image.tmdb.org/t/p/w500/9050VGrYjYrEjpOvDZVAngLbg1f.jpg"
---

# The Blair Witch Project (1999)

![](https://image.tmdb.org/t/p/w500/9050VGrYjYrEjpOvDZVAngLbg1f.jpg)

In October of 1994 three student filmmakers disappeared in the woods near Burkittsville, Maryland, while shooting a documentary. A year later their footage was found.