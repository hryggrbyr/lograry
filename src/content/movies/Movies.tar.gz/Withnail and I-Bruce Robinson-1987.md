---
type: movie
country: United Kingdom
title: "Withnail and I"
year: 1987
director: Bruce Robinson
actors: [Richard E. Grant, Paul McGann, Richard Griffiths]
genre: [Comedy, Drama]
length: 107
shelf: watched
owned: true
rating: 
watched: 1987-12-31
poster: "https://m.media-amazon.com/images/M/MV5BNmFlOGIyNTMtNjBhYy00NTRiLTg3YWEtMThhOWM5ODU4Y2M2XkEyXkFqcGc@._V1_SX300.jpg"
---

# Withnail and I (1987)

![](https://m.media-amazon.com/images/M/MV5BNmFlOGIyNTMtNjBhYy00NTRiLTg3YWEtMThhOWM5ODU4Y2M2XkEyXkFqcGc@._V1_SX300.jpg)

Two sloppy actors spend a weekend holiday at an uncle's country cottage.