---
type: movie
country: US
title: "Matilda"
year: 1996
director: Danny DeVito
actors: [Mara Wilson, Danny DeVito, Rhea Perlman, Embeth Davidtz, Pam Ferris]
genre: [Comedy, Family, Fantasy]
length: "1h 38m"
shelf: watched
owned: false
rating: 
watched: 1996-08-02
poster: "https://image.tmdb.org/t/p/w500/wYoDpWInsBEVSmWStnRH06ddoyk.jpg"
---

# Matilda (1996)

![](https://image.tmdb.org/t/p/w500/wYoDpWInsBEVSmWStnRH06ddoyk.jpg)

Matilda Wormwood is an exquisite and intelligent little girl. Unfortunately, her parents, Harry and Zinnia misunderstand her because they think she is so different. As time passes, she finally starts school and has a kind teacher, loyal friends, and a sadistic headmistress. As she gets fed up with the constant cruelty, she begins to realize that she has a gift of telekinetic powers. After some days of practice, she suddenly turns the tables to stand up to Harry and Zinnia and outwit the headmistress.