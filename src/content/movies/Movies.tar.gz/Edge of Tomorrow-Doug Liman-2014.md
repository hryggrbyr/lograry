---
type: movie
country: US
title: "Edge of Tomorrow"
year: 2014
director: Doug Liman
actors: [Tom Cruise, Emily Blunt, Brendan Gleeson, Bill Paxton, Jonas Armstrong]
genre: [Action, Science Fiction]
length: "1h 54m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/nBM9MMa2WCwvMG4IJ3eiGUdbPe6.jpg"
---

# Edge of Tomorrow (2014)

![](https://image.tmdb.org/t/p/w500/nBM9MMa2WCwvMG4IJ3eiGUdbPe6.jpg)

Major Bill Cage is an officer who has never seen a day of combat when he is unceremoniously demoted and dropped into combat. Cage is killed within minutes, managing to take an alpha alien down with him. He awakens back at the beginning of the same day and is forced to fight and die again... and again - as physical contact with the alien has thrown him into a time loop.