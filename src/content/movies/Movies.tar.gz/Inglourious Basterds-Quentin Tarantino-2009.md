---
type: movie
country: US
title: "Inglourious Basterds"
year: 2009
director: Quentin Tarantino
actors: [Brad Pitt, Mélanie Laurent, Christoph Waltz, Eli Roth, Michael Fassbender]
genre: [Drama, Thriller, War]
length: "2h 33m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/7sfbEnaARXDDhKm0CZ7D7uc2sbo.jpg"
---

# Inglourious Basterds (2009)

![](https://image.tmdb.org/t/p/w500/7sfbEnaARXDDhKm0CZ7D7uc2sbo.jpg)

In Nazi-occupied France during World War II, a group of Jewish-American soldiers known as "The Basterds" are chosen specifically to spread fear throughout the Third Reich by scalping and brutally killing Nazis. The Basterds, lead by Lt. Aldo Raine soon cross paths with a French-Jewish teenage girl who runs a movie theater in Paris which is targeted by the soldiers.