---
type: movie
country: US
title: "Paranormal Activity 3"
year: 2011
director: Ariel Schulman, Henry Joost
actors: [Katie Featherston, Sprague Grayden, Lauren Bittner, Christopher Nicholas Smith, Chloe Csengery]
genre: [Horror, Mystery]
length: "1h 23m"
shelf: watched
owned: false
rating: 
watched: 2011-10-21
poster: "https://image.tmdb.org/t/p/w500/9nYranPiWdNmbD5PRPPSL7VUFTS.jpg"
---

# Paranormal Activity 3 (2011)

![](https://image.tmdb.org/t/p/w500/9nYranPiWdNmbD5PRPPSL7VUFTS.jpg)

In 1988, young sisters Katie and Kristi befriend an invisible entity who resides in their home.