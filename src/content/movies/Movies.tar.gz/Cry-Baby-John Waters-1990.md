---
type: movie
country: US
title: "Cry-Baby"
year: 1990
director: John Waters
actors: [Johnny Depp, Amy Locane, Susan Tyrrell, Iggy Pop, Ricki Lake]
genre: [Comedy, Romance]
length: "1h 25m"
shelf: watched
owned: false
rating: 
watched: 1990-04-05
poster: "https://image.tmdb.org/t/p/w500/d2QusoWfW4azJtHtJkyLMGSv33n.jpg"
---

# Cry-Baby (1990)

![](https://image.tmdb.org/t/p/w500/d2QusoWfW4azJtHtJkyLMGSv33n.jpg)

A prim and proper schoolgirl goes against her society grandmother's wishes when she dates a motorcycle-riding juvenile delinquent.