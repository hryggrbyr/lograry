---
type: movie
country: US
title: "Casper"
year: 1995
director: Brad Silberling
actors: [Christina Ricci, Bill Pullman, Cathy Moriarty, Eric Idle, Malachi Pearson]
genre: [Fantasy, Comedy, Family]
length: "1h 40m"
shelf: watched
owned: false
rating: 
watched: 1995-05-26
poster: "https://image.tmdb.org/t/p/w500/2ah8fNJFZVU3vcXhU5xfAYi2eym.jpg"
---

# Casper (1995)

![](https://image.tmdb.org/t/p/w500/2ah8fNJFZVU3vcXhU5xfAYi2eym.jpg)

Casper is a kind young ghost who peacefully haunts a mansion in Maine. When specialist James Harvey arrives to communicate with Casper and his fellow spirits, he brings along his teenage daughter, Kat. Casper quickly falls in love with Kat, but their budding relationship is complicated not only by his transparent state, but also by his troublemaking apparition uncles and their mischievous antics.