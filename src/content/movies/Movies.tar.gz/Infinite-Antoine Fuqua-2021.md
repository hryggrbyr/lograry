---
type: movie
country: US
title: "Infinite"
year: 2021
director: Antoine Fuqua
actors: [Mark Wahlberg, Chiwetel Ejiofor, Sophie Cookson, Jason Mantzoukas, Rupert Friend]
genre: [Science Fiction, Action, Adventure]
length: "1h 46m"
shelf: watched
owned: false
rating: 
watched: 2021-06-10
poster: "https://image.tmdb.org/t/p/w500/niw2AKHz6XmwiRMLWaoyAOAti0G.jpg"
---

# Infinite (2021)

![](https://image.tmdb.org/t/p/w500/niw2AKHz6XmwiRMLWaoyAOAti0G.jpg)

Evan McCauley has skills he never learned and memories of places he has never visited. Self-medicated and on the brink of a mental breakdown, a secret group that call themselves “Infinites” come to his rescue, revealing that his memories are real.