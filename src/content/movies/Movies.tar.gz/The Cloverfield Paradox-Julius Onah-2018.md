---
type: movie
country: US
title: "The Cloverfield Paradox"
year: 2018
director: Julius Onah
actors: [Gugu Mbatha-Raw, Daniel Brühl, Chris O'Dowd, David Oyelowo, John Ortiz]
genre: [Horror, Thriller, Science Fiction]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 2018-02-04
poster: "https://image.tmdb.org/t/p/w500/vJi2ExTcWdJR3150VPKqqtdGxsT.jpg"
---

# The Cloverfield Paradox (2018)

![](https://image.tmdb.org/t/p/w500/vJi2ExTcWdJR3150VPKqqtdGxsT.jpg)

Orbiting above a planet on the brink of war, scientists test a device to solve an energy crisis and end up face-to-face with a dark alternate reality.