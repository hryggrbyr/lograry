---
type: movie
country: US
title: "Kids"
year: 1995
director: Larry Clark
actors: [Leo Fitzpatrick, Justin Pierce, Chloë Sevigny, Rosario Dawson, Yakira Peguero]
genre: [Drama, Crime]
length: "1h 31m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/8qV8hUVCUnFIQKewzlhaFWhdszK.jpg"
---

# Kids (1995)

![](https://image.tmdb.org/t/p/w500/8qV8hUVCUnFIQKewzlhaFWhdszK.jpg)

A day in the life of a group of teens as they travel around New York City skating, drinking, smoking and deflowering virgins.