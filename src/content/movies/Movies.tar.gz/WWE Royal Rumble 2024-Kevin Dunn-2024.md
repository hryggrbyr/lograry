---
type: movie
country: US
title: "WWE Royal Rumble 2024"
year: 2024
director: Kevin Dunn
actors: [Cody Rhodes, Pam Martinez, Joe Anoaʻi, Randy Orton, Shaun Ricker]
genre: [Action]
length: "3h 50m"
shelf: watched
owned: false
rating: 
watched: 2025-01-04
poster: "https://image.tmdb.org/t/p/w500/zycaV7b29KdFqr7XfxFrkgzU1gU.jpg"
---

# WWE Royal Rumble 2024 (2024)

![](https://image.tmdb.org/t/p/w500/zycaV7b29KdFqr7XfxFrkgzU1gU.jpg)

The 2024 Royal Rumble is the upcoming 37th annual Royal Rumble professional wrestling pay-per-view and livestreaming event produced by WWE. It will be held for wrestlers from the promotion's Raw and SmackDown brand divisions. The event will take place on Saturday, January 27, 2024, at Tropicana Field in St. Petersburg, Florida. It will be the second Royal Rumble to be held at the stadium after the 2021 event, though the first with ticketed fans in attendance.  Traditionally, the Royal Rumble match winner receives a world championship match at that year's WrestleMania. For the 2024 event, the winners of both the men's and women's matches receive a choice of which championship to challenge for at WrestleMania XL. The men can choose to challenge for either Raw's World Heavyweight Championship or SmackDown's Undisputed WWE Universal Championship, while the women have the choice between Raw's Women's World Championship and SmackDown's WWE Women's Championship.