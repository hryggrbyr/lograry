---
type: movie
country: United States
title: "San Andreas"
year: 2015
director: Brad Peyton
actors: [Dwayne Johnson, Carla Gugino, Alexandra Daddario]
genre: [Action, Adventure, Thriller]
length: 114
shelf: watchlist
owned: false
rating: 
watched:
poster: "https://m.media-amazon.com/images/M/MV5BYmQzNDEzMzMtM2U5OS00YTUzLWI2NDYtYjI2NjAyNWE5YzMzXkEyXkFqcGc@._V1_SX300.jpg"
---

# San Andreas (2015)

![](https://m.media-amazon.com/images/M/MV5BYmQzNDEzMzMtM2U5OS00YTUzLWI2NDYtYjI2NjAyNWE5YzMzXkEyXkFqcGc@._V1_SX300.jpg)

In the aftermath of a massive earthquake in California, a rescue-chopper pilot makes a dangerous journey with his ex-wife across the state in order to rescue his daughter.