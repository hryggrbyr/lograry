---
type: movie
country: US
title: "Raising Arizona"
year: 1987
director: Joel Coen
actors: [Nicolas Cage, Holly Hunter, Trey Wilson, John Goodman, William Forsythe]
genre: [Comedy, Crime]
length: "1h 34m"
shelf: watched
owned: false
rating: 
watched: 1987-03-01
poster: "https://image.tmdb.org/t/p/w500/tPX13Qpq1SjqPzzMIaFtL8G4lYA.jpg"
---

# Raising Arizona (1987)

![](https://image.tmdb.org/t/p/w500/tPX13Qpq1SjqPzzMIaFtL8G4lYA.jpg)

When a childless couple--an ex-con and an ex-cop--decide to help themselves to one of another family's quintuplets, their lives become more complicated than they anticipated.