---
type: movie
country: US
title: "Minority Report"
year: 2002
director: Steven Spielberg
actors: [Tom Cruise, Samantha Morton, Colin Farrell, Max von Sydow, Kathryn Morris]
genre: [Science Fiction, Action, Thriller]
length: "2h 25m"
shelf: watched
owned: false
rating: 
watched: 2002-06-21
poster: "https://image.tmdb.org/t/p/w500/ccqpHq5tk5W4ymbSbuoy4uYOxFI.jpg"
---

# Minority Report (2002)

![](https://image.tmdb.org/t/p/w500/ccqpHq5tk5W4ymbSbuoy4uYOxFI.jpg)

John Anderton is a top 'Precrime' cop in the late-21st century, when technology can predict crimes before they're committed. But Anderton becomes the quarry when another investigator targets him for a murder charge.