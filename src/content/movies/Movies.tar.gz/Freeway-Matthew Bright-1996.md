---
type: movie
country: United States, France
title: "Freeway"
year: 1996
director: Matthew Bright
actors: [Reese Witherspoon, Kiefer Sutherland, Bokeem Woodbine]
genre: [Crime, Drama, Thriller]
length: 104
shelf: watched
owned: true
rating: 
watched: 1996-12-31
poster: "https://m.media-amazon.com/images/M/MV5BOTliYjdlMTctMjgxZC00MDExLThhODktZjk3NGI4ZDE3YjEyXkEyXkFqcGc@._V1_SX300.jpg"
---

# Freeway (1996)

![](https://m.media-amazon.com/images/M/MV5BOTliYjdlMTctMjgxZC00MDExLThhODktZjk3NGI4ZDE3YjEyXkEyXkFqcGc@._V1_SX300.jpg)

A twisted take on "Little Red Riding Hood", with a teenage juvenile delinquent on the run from a social worker travelling to her grandmother's house and being hounded by a charming, but sadistic, serial killer and pedophile.