---
type: movie
country: US
title: "Inside Out"
year: 2015
director: Pete Docter
actors: [Amy Poehler, Phyllis Smith, Richard Kind, Bill Hader, Lewis Black]
genre: [Animation, Family, Adventure, Drama, Comedy]
length: "1h 35m"
shelf: watched
owned: false
rating: 
watched: 2015-06-19
poster: "https://image.tmdb.org/t/p/w500/2H1TmgdfNtsKlU9jKdeNyYL5y8T.jpg"
---

# Inside Out (2015)

![](https://image.tmdb.org/t/p/w500/2H1TmgdfNtsKlU9jKdeNyYL5y8T.jpg)

When 11-year-old Riley moves to a new city, her Emotions team up to help her through the transition. Joy, Fear, Anger, Disgust and Sadness work together, but when Joy and Sadness get lost, they must journey through unfamiliar places to get back home.