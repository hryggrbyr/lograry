---
type: movie
country: US
title: "Secretary"
year: 2002
director: Steven Shainberg
actors: [James Spader, Maggie Gyllenhaal, Jeremy Davies, Lesley Ann Warren, Stephen McHattie]
genre: [Romance, Drama, Comedy]
length: "1h 51m"
shelf: watched
owned: false
rating: 
watched: 2002-09-20
poster: "https://image.tmdb.org/t/p/w500/mdRXSE7ho185SZlXj0JSwuecEd3.jpg"
---

# Secretary (2002)

![](https://image.tmdb.org/t/p/w500/mdRXSE7ho185SZlXj0JSwuecEd3.jpg)

A young woman, recently released from a mental hospital, gets a job as a secretary to a demanding lawyer, where their employer-employee relationship turns into a sexual, sadomasochistic one.