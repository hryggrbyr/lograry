---
type: movie
country: US
title: "Titanic"
year: 1997
director: James Cameron
actors: [Leonardo DiCaprio, Kate Winslet, Billy Zane, Kathy Bates, Frances Fisher]
genre: [Drama, Romance]
length: "3h 14m"
shelf: watched
owned: false
rating: 
watched: 2023-07-11
poster: "https://image.tmdb.org/t/p/w500/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg"
---

# Titanic (1997)

![](https://image.tmdb.org/t/p/w500/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg)

101-year-old Rose DeWitt Bukater tells the story of her life aboard the Titanic, 84 years later. A young Rose boards the ship with her mother and fiancé. Meanwhile, Jack Dawson and Fabrizio De Rossi win third-class tickets aboard the ship. Rose tells the whole story from Titanic's departure through to its death—on its first and last voyage—on April 15, 1912.