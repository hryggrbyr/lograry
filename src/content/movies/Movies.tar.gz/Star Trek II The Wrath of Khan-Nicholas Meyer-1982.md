---
type: movie
country: United States
title: "Star Trek II The Wrath of Khan"
year: 1982
director: Nicholas Meyer
actors: [William Shatner, Leonard Nimoy, DeForest Kelley]
genre: [Action, Adventure, Sci-Fi]
length: 113
shelf: watched
owned: false
rating: 
watched: 1982-12-31
poster: "https://m.media-amazon.com/images/M/MV5BOTFkZDY5NWQtMjY4Yy00OThiLTk3YjQtMDdhYTllMTI4MTdiXkEyXkFqcGc@._V1_SX300.jpg"
---

# Star Trek II The Wrath of Khan (1982)

![](https://m.media-amazon.com/images/M/MV5BOTFkZDY5NWQtMjY4Yy00OThiLTk3YjQtMDdhYTllMTI4MTdiXkEyXkFqcGc@._V1_SX300.jpg)

With the assistance of the Enterprise crew, Admiral Kirk must stop an old nemesis, Khan Noonien Singh, from using the life-generating Genesis Device as the ultimate weapon.