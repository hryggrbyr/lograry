---
type: movie
country: GB
title: "Bridget Jones's Diary"
year: 2001
director: Sharon Maguire
actors: [Renée Zellweger, Colin Firth, Hugh Grant, Jim Broadbent, Gemma Jones]
genre: [Comedy, Romance, Drama]
length: "1h 37m"
shelf: watched
owned: false
rating: 
watched: 2001-04-13
poster: "https://image.tmdb.org/t/p/w500/dkauRl9TosBFikftrC3OVcKWDoz.jpg"
---

# Bridget Jones's Diary (2001)

![](https://image.tmdb.org/t/p/w500/dkauRl9TosBFikftrC3OVcKWDoz.jpg)

Bridget Jones is an average woman struggling against her age, her weight, her job, her lack of a man, and her various imperfections. As a New Year's resolution, Bridget decides to take control of her life, starting by keeping a diary in which she will always tell the complete truth. The fireworks begin when her charming though disreputable boss takes an interest in the quirky Miss Jones. Thrown into the mix are Bridget's band of slightly eccentric friends and a rather disagreeable acquaintance into whom Bridget cannot seem to stop running or help finding quietly attractive.