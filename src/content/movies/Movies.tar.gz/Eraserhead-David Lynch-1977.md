---
type: movie
country: US
title: "Eraserhead"
year: 1977
director: David Lynch
actors: [Jack Nance, Charlotte Stewart, Allen Joseph, Jeanne Bates, Judith Roberts]
genre: [Horror, Fantasy]
length: "1h 29m"
shelf: watched
owned: false
rating: 
watched: 1977-03-19
poster: "https://image.tmdb.org/t/p/w500/mxveW3mGVc0DzLdOmtkZsgd7c3B.jpg"
---

# Eraserhead (1977)

![](https://image.tmdb.org/t/p/w500/mxveW3mGVc0DzLdOmtkZsgd7c3B.jpg)

First-time father Henry Spencer tries to survive his industrial environment, his angry girlfriend, and the unbearable screams of his newly born mutant child.