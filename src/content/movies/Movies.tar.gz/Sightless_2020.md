---
type: movie
country: US
title: "Sightless"
year: 2020
director: Cooper Karl
actors: [Madelaine Petsch, Alexander Koch, December Ensminger, Lee Jones, Deniz Akdeniz]
genre: [Thriller, Horror]
length: "1h 29m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/byScu2YTPLsEfDAiXm3pW6w8FBA.jpg"
---

# Sightless (2020)

![](https://image.tmdb.org/t/p/w500/byScu2YTPLsEfDAiXm3pW6w8FBA.jpg)

After an attack renders her blind, Ellen withdraws from the world to recover. But soon she plunges into paranoia, unable to convince anyone that her assailant has returned to terrorize her by hiding in plain sight.
