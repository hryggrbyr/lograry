---
type: movie
country: US
title: "Gosford Park"
year: 2001
director: Robert Altman
actors: [Maggie Smith, Michael Gambon, Kristin Scott Thomas, Camilla Rutherford, Charles Dance]
genre: [Drama, Mystery, Thriller]
length: "2h 17m"
shelf: watched
owned: false
rating: 
watched: 2001-12-26
poster: "https://image.tmdb.org/t/p/w500/7r8DeZuaaHCiOEbkqZC6MFmwJ69.jpg"
---

# Gosford Park (2001)

![](https://image.tmdb.org/t/p/w500/7r8DeZuaaHCiOEbkqZC6MFmwJ69.jpg)

In 1930s England, a group of pretentious rich and famous gather together for a weekend of relaxation at a hunting resort. But when a murder occurs, each one of these interesting characters becomes a suspect.