---
type: movie
country: US
title: "Bill & Ted's Excellent Adventure"
year: 1989
director: Stephen Herek
actors: [Keanu Reeves, Alex Winter, George Carlin, Terry Camilleri, Dan Shor]
genre: [Adventure, Comedy, Science Fiction]
length: "1h 30m"
shelf: watched
owned: true
rating: 
watched: 1989-02-17
poster: "https://image.tmdb.org/t/p/w500/tV25lGWGWGEqUe3U0xjQTBgilSx.jpg"
---

# Bill & Ted's Excellent Adventure (1989)

![](https://image.tmdb.org/t/p/w500/tV25lGWGWGEqUe3U0xjQTBgilSx.jpg)

Bill and Ted are high school buddies starting a band. They are also about to fail their history class—which means Ted would be sent to military school—but receive help from Rufus, a traveller from a future where their band is the foundation for a perfect society. With the use of Rufus' time machine, Bill and Ted travel to various points in history, returning with important figures to help them complete their final history presentation.