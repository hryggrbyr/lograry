---
type: movie
country: GB
title: "Spice World"
year: 1997
director: Bob Spiers
actors: [Victoria Beckham, Mel B, Emma Bunton, Melanie C, Geri Halliwell-Horner]
genre: [Adventure, Fantasy, Drama, Comedy, Music]
length: "1h 33m"
shelf: watched
owned: false
rating: 
watched: 1997-12-24
poster: "https://image.tmdb.org/t/p/w500/vKiAnV1QAGIJP38vatwCZp4dCrH.jpg"
---

# Spice World (1997)

![](https://image.tmdb.org/t/p/w500/vKiAnV1QAGIJP38vatwCZp4dCrH.jpg)

World famous pop group the Spice Girls zip around London in their luxurious double decker tour bus having various adventures and performing for their fans.