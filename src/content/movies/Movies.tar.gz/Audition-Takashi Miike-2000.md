---
type: movie
country: JP
title: "Audition"
year: 2000
director: Takashi Miike
actors: [Ryo Ishibashi, Eihi Shiina, Jun Kunimura, Tetsu Sawaki, Renji Ishibashi]
genre: [Horror, Drama]
length: "1h 55m"
shelf: watched
owned: false
rating: 
watched: 2000-03-03
poster: "https://image.tmdb.org/t/p/w500/zwGaUMm0wAqi0wkO7LJDlwoA5LP.jpg"
---

# Audition (2000)

![](https://image.tmdb.org/t/p/w500/zwGaUMm0wAqi0wkO7LJDlwoA5LP.jpg)

Seven years after the death of his wife, widower Shigeharu seeks advice on how to find a new wife from a colleague. Taking advantage of their position as a film company, they stage an audition. Interviewing a series of women, Shigeharu is enchanted by the quiet Asami. But soon things take a twisted turn as Asami isn’t what she seems to be.