---
type: movie
country: US
title: "The Usual Suspects"
year: 1995
director: Bryan Singer
actors: [Stephen Baldwin, Gabriel Byrne, Benicio del Toro, Kevin Pollak, Kevin Spacey]
genre: [Drama, Crime, Thriller]
length: "1h 46m"
shelf: watched
owned: true
rating: 
watched: 1995-08-16
poster: "https://image.tmdb.org/t/p/w500/99X2SgyFunJFXGAYnDv3sb9pnUD.jpg"
---

# The Usual Suspects (1995)

![](https://image.tmdb.org/t/p/w500/99X2SgyFunJFXGAYnDv3sb9pnUD.jpg)

Held in an L.A. interrogation room, Verbal Kint attempts to convince the feds that a mythic crime lord, Keyser Soze, not only exists, but was also responsible for drawing him and his four partners into a multi-million dollar heist that ended with an explosion in San Pedro harbor – leaving few survivors. Verbal lures his interrogators with an incredible story of the crime lord's almost supernatural prowess.