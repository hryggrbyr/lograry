---
type: movie
country: GB
title: "Hellraiser"
year: 1987
director: Clive Barker
actors: [Clare Higgins, Ashley Laurence, Sean Chapman, Oliver Smith, Andrew Robinson]
genre: [Horror, Thriller, Fantasy]
length: "1h 34m"
shelf: watched
owned: false
rating: 
watched: 1987-09-18
poster: "https://image.tmdb.org/t/p/w500/3Z0oPHyLnk3Vx6ZMC1MiVwIrKhO.jpg"
---

# Hellraiser (1987)

![](https://image.tmdb.org/t/p/w500/3Z0oPHyLnk3Vx6ZMC1MiVwIrKhO.jpg)

Hedonist Frank Cotton finds a mysterious puzzle box that summons the Cenobites, who open the doors to a dominion where pain and pleasure are indivisible.