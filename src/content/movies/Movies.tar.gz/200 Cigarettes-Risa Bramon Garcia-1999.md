---
type: movie
country: US
title: "200 Cigarettes"
year: 1999
director: Risa Bramon Garcia
actors: [Ben Affleck, Casey Affleck, Dave Chappelle, Guillermo Díaz, Angela Featherstone]
genre: [Comedy, Drama, Romance]
length: "1h 41m"
shelf: watched
owned: false
rating: 
watched: 1999-02-26
poster: "https://image.tmdb.org/t/p/w500/ssbx2Mk5ZCJWpXALuP2AdG0GFIT.jpg"
---

# 200 Cigarettes (1999)

![](https://image.tmdb.org/t/p/w500/ssbx2Mk5ZCJWpXALuP2AdG0GFIT.jpg)

In 1981 New York City, a collection of twentysomethings try to cope with relationships, loneliness, desire and their individual neuroses on New Years Eve.