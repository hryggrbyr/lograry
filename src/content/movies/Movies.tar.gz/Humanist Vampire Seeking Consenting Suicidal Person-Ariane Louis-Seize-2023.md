---
type: movie
country: Canada
title: "Humanist Vampire Seeking Consenting Suicidal Person"
year: 2023
director: Ariane Louis-Seize
actors: [Sara Montpetit, Félix-Antoine Bénard, Steve Laplante]
genre: [Comedy, Drama, Fantasy]
length: 90
shelf: watchlist
owned: false
rating: 
watched: 
poster: "https://m.media-amazon.com/images/M/MV5BODBhNTFiYzAtYWUzMy00YjZjLWEzMDItNzQyNDUyZjdiMjZhXkEyXkFqcGc@._V1_SX300.jpg"
---

# Humanist Vampire Seeking Consenting Suicidal Person (2023)

![](https://m.media-amazon.com/images/M/MV5BODBhNTFiYzAtYWUzMy00YjZjLWEzMDItNzQyNDUyZjdiMjZhXkEyXkFqcGc@._V1_SX300.jpg)

A young woman vampire is unable to kill to meet her need for blood, but may have found a solution in a young man with suicidal tendencies.