---
type: movie
country: US
title: "True Romance"
year: 1993
director: Tony Scott
actors: [Christian Slater, Patricia Arquette, Dennis Hopper, Val Kilmer, Gary Oldman]
genre: [Action, Crime, Romance]
length: "1h 59m"
shelf: watched
owned: false
rating: 
watched: 1993-09-09
poster: "https://image.tmdb.org/t/p/w500/39lXk6ud6KiJgGbbWI2PUKS7y2.jpg"
---

# True Romance (1993)

![](https://image.tmdb.org/t/p/w500/39lXk6ud6KiJgGbbWI2PUKS7y2.jpg)

Clarence marries hooker Alabama, steals cocaine from her pimp, and tries to sell it in Hollywood, while the owners of the coke try to reclaim it.