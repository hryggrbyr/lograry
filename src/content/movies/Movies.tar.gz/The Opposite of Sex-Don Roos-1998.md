---
type: movie
country: US
title: "The Opposite of Sex"
year: 1998
director: Don Roos
actors: [Christina Ricci, Martin Donovan, Lisa Kudrow, Lyle Lovett, Johnny Galecki]
genre: [Comedy, Drama]
length: "1h 45m"
shelf: watched
owned: false
rating: 
watched: 1998-01-22
poster: "https://image.tmdb.org/t/p/w500/xpILzxKHywYngftBC8AmvsqUfBj.jpg"
---

# The Opposite of Sex (1998)

![](https://image.tmdb.org/t/p/w500/xpILzxKHywYngftBC8AmvsqUfBj.jpg)

A 16-year-old girl visits her gay half-brother and ends up seducing his boyfriend, thus wreaking havoc on all of their lives.