---
type: movie
country: US
title: "Red State"
year: 2011
director: Kevin Smith
actors: [Michael Parks, John Goodman, Melissa Leo, Michael Angarano, Kyle Gallner]
genre: [Horror, Action, Thriller]
length: "1h 28m"
shelf: watched
owned: false
rating: 
watched: 2011-09-23
poster: "https://image.tmdb.org/t/p/w500/mbukOgivZWGNAxEQVt4hLUVME2P.jpg"
---

# Red State (2011)

![](https://image.tmdb.org/t/p/w500/mbukOgivZWGNAxEQVt4hLUVME2P.jpg)

Set in Middle America, a group of teens receive an online invitation for sex, though they soon encounter Christian fundamentalists with a much more sinister agenda.