---
type: movie
country: US
title: "The Incredibles"
year: 2004
director: Brad Bird
actors: [Craig T. Nelson, Holly Hunter, Sarah Vowell, Spencer Fox, Jason Lee]
genre: [Action, Adventure, Animation, Family]
length: "1h 55m"
shelf: watched
owned: false
rating: 
watched: 2004-11-05
poster: "https://image.tmdb.org/t/p/w500/2LqaLgk4Z226KkgPJuiOQ58wvrm.jpg"
---

# The Incredibles (2004)

![](https://image.tmdb.org/t/p/w500/2LqaLgk4Z226KkgPJuiOQ58wvrm.jpg)

Bob Parr has given up his superhero days to log in time as an insurance adjuster and raise his three children with his formerly heroic wife in suburbia. But when he receives a mysterious assignment, it's time to get back into costume.