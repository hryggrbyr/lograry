---
type: movie
country: GB
title: "The Hole"
year: 2001
director: Nick Hamm
actors: [Thora Birch, Desmond Harrington, Keira Knightley, Laurence Fox, Embeth Davidtz]
genre: [Crime, Drama, Horror, Thriller]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 2001-04-20
poster: "https://image.tmdb.org/t/p/w500/n5aMoI6AZLJzUoNbjMj0P60EYMJ.jpg"
---

# The Hole (2001)

![](https://image.tmdb.org/t/p/w500/n5aMoI6AZLJzUoNbjMj0P60EYMJ.jpg)

Four teenagers at a British private school secretly uncover and explore the depths of a sealed underground hole created decades ago as a possible bomb shelter.