---
type: movie
country: Japan, United States
title: "The First Purge"
year: 2018
director: Gerard McMurray
actors: [Y'lan Noel, Lex Scott Davis, Joivan Wade]
genre: [Action, Horror, Sci-Fi]
length: 97
shelf: watched
owned: false
rating: 
watched: 2018-12-31
poster: "https://m.media-amazon.com/images/M/MV5BZjZmMDY4MzItYzVhOC00YmQ5LWFjMDgtYzk5ZDY1ZTFmN2ZjXkEyXkFqcGc@._V1_SX300.jpg"
---

# The First Purge (2018)

![](https://m.media-amazon.com/images/M/MV5BZjZmMDY4MzItYzVhOC00YmQ5LWFjMDgtYzk5ZDY1ZTFmN2ZjXkEyXkFqcGc@._V1_SX300.jpg)

America's third political party, the New Founding Fathers of America, comes to power and conducts an experiment: no laws for 12 hours on Staten Island. No one has to stay on the island, but $5, 000 is given to anyone who does.