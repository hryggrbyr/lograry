---
type: movie
country: US
title: "Pretty Woman"
year: 1990
director: Garry Marshall
actors: [Richard Gere, Julia Roberts, Ralph Bellamy, Jason Alexander, Laura San Giacomo]
genre: [Romance, Comedy]
length: "2h 0m"
shelf: watched
owned: false
rating: 
watched: 2023-11-18
poster: "https://image.tmdb.org/t/p/w500/hVHUfT801LQATGd26VPzhorIYza.jpg"
---

# Pretty Woman (1990)

![](https://image.tmdb.org/t/p/w500/hVHUfT801LQATGd26VPzhorIYza.jpg)

While on a business trip in Los Angeles, Edward Lewis, a millionaire entrepreneur who makes a living buying and breaking up companies, picks up a prostitute, Vivian, while asking for directions; after, Edward hires Vivian to stay with him for the weekend to accompany him to a few social events, and the two get closer only to discover there are significant hurdles to overcome as they try to bridge the gap between their very different worlds.