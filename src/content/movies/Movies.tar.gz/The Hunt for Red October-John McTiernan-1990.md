---
type: movie
country: US
title: "The Hunt for Red October"
year: 1990
director: John McTiernan
actors: [Sean Connery, Alec Baldwin, Scott Glenn, Sam Neill, James Earl Jones]
genre: [Action, Adventure, Thriller]
length: "2h 15m"
shelf: watched
owned: false
rating: 
watched: 1990-03-02
poster: "https://image.tmdb.org/t/p/w500/yVl7zidse4KiWtGMqHFtZCx4X3N.jpg"
---

# The Hunt for Red October (1990)

![](https://image.tmdb.org/t/p/w500/yVl7zidse4KiWtGMqHFtZCx4X3N.jpg)

A new technologically-superior Soviet nuclear sub, the Red October, is heading for the U.S. coast under the command of Captain Marko Ramius. The American government thinks Ramius is planning to attack. Lone CIA analyst Jack Ryan has a different idea: he thinks Ramius is planning to defect, but he has only a few hours to find him and prove it - because the entire Russian naval and air commands are trying to find Ramius, too. The hunt is on!