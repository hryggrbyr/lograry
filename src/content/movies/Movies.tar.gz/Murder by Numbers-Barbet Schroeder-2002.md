---
type: movie
country: US
title: "Murder by Numbers"
year: 2002
director: Barbet Schroeder
actors: [Sandra Bullock, Ben Chaplin, Ryan Gosling, Michael Pitt, Agnes Bruckner]
genre: [Crime, Drama, Thriller]
length: "2h 0m"
shelf: watched
owned: false
rating: 
watched: 2002-04-19
poster: "https://image.tmdb.org/t/p/w500/pBM5byKWtcHg8NvyTA7NVyIIqEj.jpg"
---

# Murder by Numbers (2002)

![](https://image.tmdb.org/t/p/w500/pBM5byKWtcHg8NvyTA7NVyIIqEj.jpg)

Tenacious homicide detective Cassie Mayweather and her still-green partner are working a murder case, attempting to profile two malevolently brilliant young men: cold, calculating killers whose dark secrets might explain their crimes.