---
type: movie
country: US
title: "Halloween"
year: 1978
director: John Carpenter
actors: [Donald Pleasence, Jamie Lee Curtis, Nancy Kyes, P. J. Soles, Charles Cyphers]
genre: [Horror, Thriller]
length: "1h 31m"
shelf: watched
owned: false
rating: 
watched: 1978-10-25
poster: "https://image.tmdb.org/t/p/w500/wijlZ3HaYMvlDTPqJoTCWKFkCPU.jpg"
---

# Halloween (1978)

![](https://image.tmdb.org/t/p/w500/wijlZ3HaYMvlDTPqJoTCWKFkCPU.jpg)

Fifteen years after murdering his sister on Halloween Night 1963, Michael Myers escapes from a mental hospital and returns to the small town of Haddonfield, Illinois to kill again.