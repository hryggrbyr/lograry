---
type: movie
country: US
title: "Rock of Ages"
year: 2012
director: Adam Shankman
actors: [Julianne Hough, Diego Boneta, Alec Baldwin, Tom Cruise, Russell Brand]
genre: [Comedy, Drama, Romance, Music]
length: "2h 3m"
shelf: watched
owned: false
rating: 
watched: 2015-06-15
poster: "https://image.tmdb.org/t/p/w500/oVeE2QTUb14jPU2lYEGPE3s8T9j.jpg"
---

# Rock of Ages (2012)

![](https://image.tmdb.org/t/p/w500/oVeE2QTUb14jPU2lYEGPE3s8T9j.jpg)

A small town girl and a city boy meet on the Sunset Strip, while pursuing their Hollywood dreams.