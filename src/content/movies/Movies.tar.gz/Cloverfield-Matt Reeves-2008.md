---
type: movie
country: US
title: "Cloverfield"
year: 2008
director: Matt Reeves
actors: [Lizzy Caplan, Jessica Lucas, T.J. Miller, Michael Stahl-David, Mike Vogel]
genre: [Action, Thriller, Science Fiction]
length: "1h 24m"
shelf: watched
owned: false
rating: 
watched: 2008-01-15
poster: "https://image.tmdb.org/t/p/w500/qIegUGJqyMMCRjkKV1s7A9MqdJ8.jpg"
---

# Cloverfield (2008)

![](https://image.tmdb.org/t/p/w500/qIegUGJqyMMCRjkKV1s7A9MqdJ8.jpg)

Five young New Yorkers throw their friend a going-away party the night that a monster the size of a skyscraper descends upon the city. Told from the point of view of their video camera, the film is a document of their attempt to survive the most surreal, horrifying event of their lives.