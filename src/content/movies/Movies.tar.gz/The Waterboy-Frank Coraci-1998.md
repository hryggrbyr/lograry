---
type: movie
country: US
title: "The Waterboy"
year: 1998
director: Frank Coraci
actors: [Adam Sandler, Kathy Bates, Henry Winkler, Fairuza Balk, Jerry Reed]
genre: [Comedy]
length: "1h 30m"
shelf: watched
owned: false
rating: 
watched: 1998-11-06
poster: "https://image.tmdb.org/t/p/w500/miT42qWYC4D0n2mXNzJ9VfhheWW.jpg"
---

# The Waterboy (1998)

![](https://image.tmdb.org/t/p/w500/miT42qWYC4D0n2mXNzJ9VfhheWW.jpg)

Bobby Boucher is a water boy for a struggling college football team. The coach discovers Boucher's hidden rage makes him a tackling machine whose bone-crushing power might vault his team into the playoffs.