---
type: movie
country: GB
title: "Members Club"
year: 2024
director: Marc Coleman
actors: [Dean Kilbey, Perry Benson, Mark Monero, David Alexander, Barbara Smith]
genre: [Horror, Comedy]
length: "1h 30m"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/fBf46CXw9teXcJx340eTPQL33Fd.jpg"
---

# Members Club (2024)

![](https://image.tmdb.org/t/p/w500/fBf46CXw9teXcJx340eTPQL33Fd.jpg)

Wet Dreams, a middle aged male stripper group, take one last gig at a rural working mens club only to discover they are to become sacrifices in a plot to raise a murderous 16th century witch from the dead.
