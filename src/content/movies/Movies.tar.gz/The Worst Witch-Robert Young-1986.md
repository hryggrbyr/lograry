---
type: movie
country: GB, US
title: "The Worst Witch"
year: 1986
director: Robert Young
actors: [Diana Rigg, Charlotte Rae, Tim Curry, Fairuza Balk, Sabina Franklyn]
genre: [TV Movie, Family, Comedy, Fantasy, Music]
length: "1h 10m"
shelf: watched
owned: false
rating: 
watched: 1986-11-01
poster: "https://image.tmdb.org/t/p/w500/ph6U11FTmfxFlkl32riyAyytqgZ.jpg"
---

# The Worst Witch (1986)

![](https://image.tmdb.org/t/p/w500/ph6U11FTmfxFlkl32riyAyytqgZ.jpg)

Mildred is one of the young girls at a prestigious witch academy. She can't seem to do anything right and is picked on by classmates and teachers. The headmistress of the school, Miss Cackle, has an evil twin sister who plans to destroy the school. Can Mildred foil the plan before the Grand Wizard comes to the Academy for a Halloween celebration you'll never forget?!!