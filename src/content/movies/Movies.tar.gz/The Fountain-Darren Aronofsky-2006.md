---
type: movie
country: US
title: "The Fountain"
year: 2006
director: Darren Aronofsky
actors: [Hugh Jackman, Rachel Weisz, Ellen Burstyn, Mark Margolis, Stephen McHattie]
genre: [Drama, Adventure, Science Fiction, Romance]
length: "1h 36m"
shelf: watched
owned: false
rating: 
watched: 2006-11-22
poster: "https://image.tmdb.org/t/p/w500/4XTf8GuCVLWolubANaKkpk62YPq.jpg"
---

# The Fountain (2006)

![](https://image.tmdb.org/t/p/w500/4XTf8GuCVLWolubANaKkpk62YPq.jpg)

Spanning over one thousand years, and three parallel stories, The Fountain is a story of love, death, spirituality, and the fragility of our existence in this world.