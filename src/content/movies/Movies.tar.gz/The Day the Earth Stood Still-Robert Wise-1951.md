---
type: movie
country: US
title: "The Day the Earth Stood Still"
year: 1951
director: Robert Wise
actors: [Michael Rennie, Patricia Neal, Billy Gray, Sam Jaffe, Hugh Marlowe]
genre: [Science Fiction, Thriller, Drama]
length: "1h 32m"
shelf: watched
owned: false
rating: 
watched: 1951-09-28
poster: "https://image.tmdb.org/t/p/w500/eslDNzf0LF1m9GsgUXlmyfTcC6Y.jpg"
---

# The Day the Earth Stood Still (1951)

![](https://image.tmdb.org/t/p/w500/eslDNzf0LF1m9GsgUXlmyfTcC6Y.jpg)

An alien and a robot land on Earth after World War II and tell mankind to be peaceful or face destruction.