---
type: movie
country: United States
title: "The Naked Gun From the Files of Police Squad!"
year: 1988
director: David Zucker
actors: [Leslie Nielsen, Priscilla Presley, O.J. Simpson]
genre: [Comedy, Crime]
length: 85
shelf: watched
owned: false
rating: 
watched: 1988-12-31
poster: "https://m.media-amazon.com/images/M/MV5BZTI5N2I1MjAtNTc0Yy00ZDIyLThkZTctMGQ5NTBhNjIwMWQ0XkEyXkFqcGc@._V1_SX300.jpg"
---

# The Naked Gun From the Files of Police Squad! (1988)

![](https://m.media-amazon.com/images/M/MV5BZTI5N2I1MjAtNTc0Yy00ZDIyLThkZTctMGQ5NTBhNjIwMWQ0XkEyXkFqcGc@._V1_SX300.jpg)

Incompetent police Detective Frank Drebin must foil an attempt to assassinate Queen Elizabeth II.