---
type: movie
country: NZ, US
title: "West of Memphis"
year: 2012
director: Amy J. Berg
actors: [Damien Echols, Jessie Misskelley Jr., Jason Baldwin, Pam Hobbs, Steve Jones]
genre: [Documentary]
length: "2h 30m"
shelf: watched
owned: false
rating: 
watched: 2013-12-25
poster: "https://image.tmdb.org/t/p/w500/468k7zjR95COOXcMLxE5GbXjerQ.jpg"
---

# West of Memphis (2012)

![](https://image.tmdb.org/t/p/w500/468k7zjR95COOXcMLxE5GbXjerQ.jpg)

The documentary tells the hitherto unknown story behind an extraordinary and desperate fight to bring the truth to light. Told and made by those who lived it, the filmmakers' unprecedented access to the inner workings of the defense allows the film to show the investigation, research, and appeals process in a way that has never been seen before; revealing shocking and disturbing new information about a case that still haunts the American South.