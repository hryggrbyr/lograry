---
type: movie
country: US
title: "Carrie"
year: 1976
director: Brian De Palma
actors: [Sissy Spacek, Piper Laurie, Amy Irving, William Katt, John Travolta]
genre: [Horror, Thriller]
length: "1h 38m"
shelf: watched
owned: false
rating: 
watched: 1976-11-03
poster: "https://image.tmdb.org/t/p/w500/bJJ3xK4pMnfao0wfzySfC47dp8G.jpg"
---

# Carrie (1976)

![](https://image.tmdb.org/t/p/w500/bJJ3xK4pMnfao0wfzySfC47dp8G.jpg)

Withdrawn and sensitive teen Carrie White faces taunting from classmates at school and abuse from her fanatically pious mother. When strange occurrences start happening around Carrie, she begins to suspect that she has supernatural powers.