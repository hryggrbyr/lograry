---
type: movie
country: US
title: "Buffalo '66"
year: 1998
director: Vincent Gallo
actors: [Vincent Gallo, Christina Ricci, Ben Gazzara, Anjelica Huston, Rosanna Arquette]
genre: [Drama, Romance, Comedy]
length: "1h 50m"
shelf: watched
owned: false
rating: 
watched: 1998-06-26
poster: "https://image.tmdb.org/t/p/w500/fxzXFzbSGNA52NHQCMqQiwzMIQw.jpg"
---

# Buffalo '66 (1998)

![](https://image.tmdb.org/t/p/w500/fxzXFzbSGNA52NHQCMqQiwzMIQw.jpg)

Billy is released after five years in prison. In the next moment, he kidnaps teenage student Layla and visits his parents with her, pretending she is his girlfriend and they will soon marry.