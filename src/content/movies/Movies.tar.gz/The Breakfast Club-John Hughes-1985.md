---
type: movie
country: US
title: "The Breakfast Club"
year: 1985
director: John Hughes
actors: [Emilio Estevez, Judd Nelson, Molly Ringwald, Anthony Michael Hall, Ally Sheedy]
genre: [Comedy, Drama]
length: "1h 38m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/wM9ErA8UVdcce5P4oefQinN8VVV.jpg"
---

# The Breakfast Club (1985)

![](https://image.tmdb.org/t/p/w500/wM9ErA8UVdcce5P4oefQinN8VVV.jpg)

Five high school students from different walks of life endure a Saturday detention under a power-hungry principal. The disparate group includes rebel John, princess Claire, outcast Allison, brainy Brian and Andrew, the jock. Each has a chance to tell his or her story, making the others see them a little differently -- and when the day ends, they question whether school will ever be the same.