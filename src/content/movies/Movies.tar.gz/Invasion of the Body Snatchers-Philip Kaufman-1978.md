---
type: movie
country: US
title: "Invasion of the Body Snatchers"
year: 1978
director: Philip Kaufman
actors: [Donald Sutherland, Brooke Adams, Leonard Nimoy, Jeff Goldblum, Veronica Cartwright]
genre: [Science Fiction, Horror]
length: "1h 56m"
shelf: watched
owned: false
rating: 
watched: 1978-12-20
poster: "https://image.tmdb.org/t/p/w500/skS02wdeH2C0nrbCQP3qKwJdZtZ.jpg"
---

# Invasion of the Body Snatchers (1978)

![](https://image.tmdb.org/t/p/w500/skS02wdeH2C0nrbCQP3qKwJdZtZ.jpg)

The residents of San Francisco are becoming drone-like shadows of their former selves, and as the phenomenon spreads, two Department of Health workers uncover the horrifying truth.