---
type: movie
country: US
title: "Knock Knock"
year: 2015
director: Eli Roth
actors: [Keanu Reeves, Lorenza Izzo, Ana de Armas, Aaron Burns, Colleen Camp]
genre: [Crime, Horror, Thriller]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 2015-10-09
poster: "https://image.tmdb.org/t/p/w500/cUC4rUb1Cs2KMaZ6RD4uYUEEwls.jpg"
---

# Knock Knock (2015)

![](https://image.tmdb.org/t/p/w500/cUC4rUb1Cs2KMaZ6RD4uYUEEwls.jpg)

When a devoted husband and father is left home alone for the weekend, two stranded young women unexpectedly knock on his door for help. What starts out as a kind gesture results in a dangerous seduction and a deadly game of cat and mouse.