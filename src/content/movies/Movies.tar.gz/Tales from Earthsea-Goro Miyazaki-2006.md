---
type: movie
country: JP
title: "Tales from Earthsea"
year: 2006
director: Goro Miyazaki
actors: [Junichi Okada, Aoi Teshima, Bunta Sugawara, Yuko Tanaka, Teruyuki Kagawa]
genre: [Animation, Fantasy, Adventure]
length: "1h 55m"
shelf: watched
owned: false
rating: 
watched: 2006-07-29
poster: "https://image.tmdb.org/t/p/w500/y0VnJt4eRPMjA1hpJ8f1EFoVaSf.jpg"
---

# Tales from Earthsea (2006)

![](https://image.tmdb.org/t/p/w500/y0VnJt4eRPMjA1hpJ8f1EFoVaSf.jpg)

Something bizarre has come over the land. The kingdom is deteriorating. People are beginning to act strange... What's even more strange is that people are beginning to see dragons, which shouldn't enter the world of humans. Due to all these bizarre events, Ged, a wandering wizard, is investigating the cause. During his journey, he meets Prince Arren, a young distraught teenage boy. While Arren may look like a shy young teen, he has a severe dark side, which grants him strength, hatred, ruthlessness and has no mercy, especially when it comes to protecting Teru. For the witch Kumo this is a perfect opportunity. She can use the boy's "fears" against the very one who would help him, Ged.