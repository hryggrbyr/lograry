---
type: movie
country: US
title: "Captain Phillips"
year: 2013
director: Paul Greengrass
actors: [Tom Hanks, Barkhad Abdi, Barkhad Abdirahman, Faysal  Ahmed, Mahat M. Ali]
genre: [Action, Drama, Thriller]
length: "2h 14m"
shelf: watched
owned: false
rating: 
watched: 2013-10-11
poster: "https://image.tmdb.org/t/p/w500/2x8ida0rHokUv80Ah4eBNb2eXas.jpg"
---

# Captain Phillips (2013)

![](https://image.tmdb.org/t/p/w500/2x8ida0rHokUv80Ah4eBNb2eXas.jpg)

The true story of Captain Richard Phillips and the 2009 hijacking by Somali pirates of the US-flagged MV Maersk Alabama, the first American cargo ship to be hijacked in two hundred years.