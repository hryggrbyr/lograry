---
type: movie
country: JP
title: "My Neighbors the Yamadas"
year: 1999
director: Isao Takahata
actors: [Hayato Isohata, Masako Araki, Naomi Uno, Toru Masuoka, Yukiji Asaoka]
genre: [Animation, Comedy, Family]
length: "1h 44m"
shelf: watched
owned: false
rating: 
watched: 1999-07-17
poster: "https://image.tmdb.org/t/p/w500/nj0ijnOozQtu52r0ncut769G1FX.jpg"
---

# My Neighbors the Yamadas (1999)

![](https://image.tmdb.org/t/p/w500/nj0ijnOozQtu52r0ncut769G1FX.jpg)

The Yamadas are a typical middle class Japanese family in urban Tokyo and this film shows us a variety of episodes of their lives. With tales that range from the humorous to the heartbreaking, we see this family cope with life's little conflicts, problems, and joys in their own way.