---
type: movie
country: US
title: "Gone Girl"
year: 2014
director: David Fincher
actors: [Ben Affleck, Rosamund Pike, Neil Patrick Harris, Tyler Perry, Carrie Coon]
genre: [Mystery, Thriller, Drama]
length: "2h 29m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/ts996lKsxvjkO2yiYG0ht4qAicO.jpg"
---

# Gone Girl (2014)

![](https://image.tmdb.org/t/p/w500/ts996lKsxvjkO2yiYG0ht4qAicO.jpg)

With his wife's disappearance having become the focus of an intense media circus, a man sees the spotlight turned on him when it's suspected that he may not be innocent.