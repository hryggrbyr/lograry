---
type: movie
country: US
title: "Big Hero 6"
year: 2014
director: Don Hall, Chris Williams
actors: [Scott Adsit, Ryan Potter, Daniel Henney, T.J. Miller, Jamie Chung]
genre: [Adventure, Family, Animation, Action, Comedy]
length: "1h 42m"
shelf: watched
owned: false
rating: 
watched: 2014-11-07
poster: "https://image.tmdb.org/t/p/w500/2mxS4wUimwlLmI1xp6QW6NSU361.jpg"
---

# Big Hero 6 (2014)

![](https://image.tmdb.org/t/p/w500/2mxS4wUimwlLmI1xp6QW6NSU361.jpg)

A special bond develops between plus-sized inflatable robot Baymax, and prodigy Hiro Hamada, who team up with a group of friends to form a band of high-tech heroes.