---
type: movie
country: US
title: "Cabaret"
year: 1972
director: Bob Fosse
actors: [Liza Minnelli, Michael York, Helmut Griem, Joel Grey, Fritz Wepper]
genre: [Music, Drama, Romance]
length: "2h 4m"
shelf: watched
owned: false
rating: 
watched: 1972-02-13
poster: "https://image.tmdb.org/t/p/w500/fMhOeJ2TvuY46iYGmsowhgRXfnr.jpg"
---

# Cabaret (1972)

![](https://image.tmdb.org/t/p/w500/fMhOeJ2TvuY46iYGmsowhgRXfnr.jpg)

Inside the Kit Kat Club of 1931 Berlin, starry-eyed singer Sally Bowles and an impish emcee sound the clarion call to decadent fun, while outside a certain political party grows into a brutal force.