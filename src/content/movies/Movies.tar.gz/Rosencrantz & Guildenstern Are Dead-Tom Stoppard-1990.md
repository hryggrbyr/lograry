---
type: movie
country: United Kingdom, United States
title: "Rosencrantz & Guildenstern Are Dead"
year: 1990
director: Tom Stoppard
actors: [Gary Oldman, Tim Roth, Richard Dreyfuss, Iain Glen]
genre: [Comedy, Drama]
length: 117
shelf: watched
owned: true
rating: 4
watched: 2025-10-29
poster: "https://m.media-amazon.com/images/M/MV5BNjc0MTU0MDY1OV5BMl5BanBnXkFtZTcwMDI2OTY2NA@@._V1_SX300.jpg"
---

# Rosencrantz & Guildenstern Are Dead (1990)

![](https://m.media-amazon.com/images/M/MV5BNjc0MTU0MDY1OV5BMl5BanBnXkFtZTcwMDI2OTY2NA@@._V1_SX300.jpg)

Two minor characters from the play 'Hamlet' stumble around unaware of their scripted lives and unable to deviate from them.