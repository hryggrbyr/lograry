---
type: movie
country: KR
title: "Lady Vengeance"
year: 2005
director: Park Chan-wook
actors: [Lee Young-ae, Choi Min-sik, Kwon Yea-young, Kim Si-hoo, Nam Il-woo]
genre: [Drama, Thriller]
length: "1h 55m"
shelf: watched
owned: false
rating: 
watched: 2005-07-29
poster: "https://image.tmdb.org/t/p/w500/7F7Ozn0QpqkVvuv1kC2XpbuFvn9.jpg"
---

# Lady Vengeance (2005)

![](https://image.tmdb.org/t/p/w500/7F7Ozn0QpqkVvuv1kC2XpbuFvn9.jpg)

Released after being wrongfully convicted and imprisoned for 13 years, a woman begins executing her elaborate plan of retribution.