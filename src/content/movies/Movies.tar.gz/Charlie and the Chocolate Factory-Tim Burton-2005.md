---
type: movie
country: US
title: "Charlie and the Chocolate Factory"
year: 2005
director: Tim Burton
actors: [Johnny Depp, Freddie Highmore, David Kelly, Helena Bonham Carter, Noah Taylor]
genre: [Adventure, Comedy, Family, Fantasy]
length: "1h 55m"
shelf: watched
owned: false
rating: 
watched: 2005-07-15
poster: "https://image.tmdb.org/t/p/w500/iKP6wg3c6COUe8gYutoGG7qcPnO.jpg"
---

# Charlie and the Chocolate Factory (2005)

![](https://image.tmdb.org/t/p/w500/iKP6wg3c6COUe8gYutoGG7qcPnO.jpg)

A young boy wins a tour through the most magnificent chocolate factory in the world, led by the world's most unusual candy maker.