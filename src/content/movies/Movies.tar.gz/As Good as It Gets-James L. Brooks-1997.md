---
type: movie
country: US
title: "As Good as It Gets"
year: 1997
director: James L. Brooks
actors: [Jack Nicholson, Helen Hunt, Greg Kinnear, Cuba Gooding Jr., Shirley Knight]
genre: [Drama, Comedy, Romance]
length: "2h 19m"
shelf: watched
owned: false
rating: 
watched: 1997-12-19
poster: "https://image.tmdb.org/t/p/w500/xXxuJPNUDZ0vjsAXca0O5p3leVB.jpg"
---

# As Good as It Gets (1997)

![](https://image.tmdb.org/t/p/w500/xXxuJPNUDZ0vjsAXca0O5p3leVB.jpg)

Melvin Udall, a cranky, bigoted, obsessive-compulsive writer of romantic fiction, is rude to everyone he meets, including his gay neighbor, Simon. After Simon is brutally attacked and hospitalized, Melvin finds his life turned upside down when he has to look after Simon's dog. In addition, Carol, the only waitress at the local diner who will tolerate him, leaves work to care for her chronically ill son, making it impossible for Melvin to eat breakfast.