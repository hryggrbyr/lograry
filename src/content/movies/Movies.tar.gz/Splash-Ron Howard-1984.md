---
type: movie
country: US
title: "Splash"
year: 1984
director: Ron Howard
actors: [Tom Hanks, Daryl Hannah, Eugene Levy, John Candy, Dody Goodman]
genre: [Comedy, Romance, Fantasy]
length: "1h 51m"
shelf: watched
owned: false
rating: 
watched: 1984-03-09
poster: "https://image.tmdb.org/t/p/w500/7FutTsMWBwVhjk1Ujf1wtndUVZh.jpg"
---

# Splash (1984)

![](https://image.tmdb.org/t/p/w500/7FutTsMWBwVhjk1Ujf1wtndUVZh.jpg)

A successful businessman falls in love with the girl of his dreams. There's one big complication though; he's fallen hook, line and sinker for a mermaid.