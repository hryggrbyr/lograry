---
type: movie
country: US
title: "The Woodsman"
year: 2004
director: Nicole Kassell
actors: [Kevin Bacon, David Alan Grier, Kyra Sedgwick, Eve, Benjamin Bratt]
genre: [Drama, Crime]
length: "1h 27m"
shelf: watched
owned: false
rating: 
watched: 2004-12-24
poster: "https://image.tmdb.org/t/p/w500/4fDgLcc35A0IpxhMyJMP33bSDXj.jpg"
---

# The Woodsman (2004)

![](https://image.tmdb.org/t/p/w500/4fDgLcc35A0IpxhMyJMP33bSDXj.jpg)

After twelve years in prison, Walter returns home. His family has abandoned him, save for his brother-in-law. Few know he's a sex offender and pedophile. Walter finds an apartment and is regularly visited by his parole officer. He gets a job at a lumber mill and starts seeing a coworker. Then his new world begins to unravel; as his past becomes known, he strikes up a high-risk friendship with a young girl and realizes that a man loitering near a schoolyard is a child molester prowling for his next victim.