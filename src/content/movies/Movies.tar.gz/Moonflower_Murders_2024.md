---
type: series
country: GB
title: "Moonflower Murders"
year: 2024
director: Rebecca Gatward
actors: [Lesley Manville, Tim McMullan, Alexandros Logothetis, Daniel Mays, Conleth Hill]
genre: [Mystery, Crime]
length: "1 season (6 episodes)"
shelf: watchlist
owned: false
rating:
watched:
poster: "https://image.tmdb.org/t/p/w500/9Nvf4U5dba5Un1RlYemhD2sxZBN.jpg"
---

# Moonflower Murders (2024)

![](https://image.tmdb.org/t/p/w500/9Nvf4U5dba5Un1RlYemhD2sxZBN.jpg)

Susan has left publishing and is living in Crete with her long-time boyfriend, Andreas. But her idyll is disturbed by the shadow of a murder committed at a British country hotel eight years ago. Alan Conway visited the hotel and wrote a novel based on what happened there. Cecily MacNeil, the young woman who helps run the hotel, read the book and believed the wrong man had been arrested. Now she has disappeared. Can Susan uncover the secret hidden in the book and find Cecily before it is too late?
