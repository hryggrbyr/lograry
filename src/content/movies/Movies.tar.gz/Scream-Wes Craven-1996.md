---
type: movie
country: US
title: "Scream"
year: 1996
director: Wes Craven
actors: [David Arquette, Neve Campbell, Courteney Cox, Matthew Lillard, Rose McGowan]
genre: [Crime, Horror, Mystery]
length: "1h 52m"
shelf: watched
owned: false
rating: 
watched: 1996-12-20
poster: "https://image.tmdb.org/t/p/w500/lr9ZIrmuwVmZhpZuTCW8D9g0ZJe.jpg"
---

# Scream (1996)

![](https://image.tmdb.org/t/p/w500/lr9ZIrmuwVmZhpZuTCW8D9g0ZJe.jpg)

A year after the murder of her mother, a teenage girl is terrorized by a masked killer who targets her and her friends by using scary movies as part of a deadly game.