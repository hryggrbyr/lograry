---
type: movie
country: US
title: "Chicago"
year: 2002
director: Rob Marshall
actors: [Renée Zellweger, Catherine Zeta-Jones, Richard Gere, Queen Latifah, Ekaterina Chtchelkanova]
genre: [Comedy, Crime, Drama]
length: "1h 53m"
shelf: watched
owned: false
rating: 
watched: 2023-08-23
poster: "https://image.tmdb.org/t/p/w500/3ED8cWCXY9zkx77Sd0N5qMbsdDP.jpg"
---

# Chicago (2002)

![](https://image.tmdb.org/t/p/w500/3ED8cWCXY9zkx77Sd0N5qMbsdDP.jpg)

Murderesses Velma Kelly and Roxie Hart find themselves on death row together and fight for the fame that will keep them from the gallows in 1920s Chicago.