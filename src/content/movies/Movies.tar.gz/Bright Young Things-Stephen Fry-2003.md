---
type: movie
country: GB
title: "Bright Young Things"
year: 2003
director: Stephen Fry
actors: [Stephen Campbell Moore, Emily Mortimer, Harriet Walter, Michael Sheen, James McAvoy]
genre: [Comedy]
length: "1h 46m"
shelf: watched
owned: false
rating: 
watched: 2003-10-03
poster: "https://image.tmdb.org/t/p/w500/m7ik01FJKBSEoy0L0PKz7eEf9kI.jpg"
---

# Bright Young Things (2003)

![](https://image.tmdb.org/t/p/w500/m7ik01FJKBSEoy0L0PKz7eEf9kI.jpg)

During the 1930s in England, a group of young socialites dominate the national gossip with extravagant and outlandish antics. Among the group is the aspiring novelist Adam Fenwick-Symes, who is attempting to raise enough money to marry fellow member Nina Blount. However, after customs officials confiscate his first manuscript, Fenwick-Symes must recover from the financial setback and figure out new ways to earn money for a wedding.