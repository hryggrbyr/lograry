---
type: movie
country: United States
title: Star Wars Episode IV - A New Hope
year: 1977
director: George Lucas
actors: [Mark Hamill, Harrison Ford, Carrie Fisher]
genre: [Action, Adventure, Fantasy]
length: 121
shelf: watched
owned: false
rating: 
watched: 1989-12-31
poster: "https://m.media-amazon.com/images/M/MV5BOGUwMDk0Y2MtNjBlNi00NmRiLTk2MWYtMGMyMDlhYmI4ZDBjXkEyXkFqcGc@._V1_SX300.jpg"
---

# Star Wars Episode IV - A New Hope (1977)

![](https://m.media-amazon.com/images/M/MV5BOGUwMDk0Y2MtNjBlNi00NmRiLTk2MWYtMGMyMDlhYmI4ZDBjXkEyXkFqcGc@._V1_SX300.jpg)

Luke Skywalker joins forces with a Jedi Knight, a cocky pilot, a Wookiee and two droids to save the galaxy from the Empire's world-destroying battle station, while also attempting to rescue Princess Leia from the mysterious Darth ...