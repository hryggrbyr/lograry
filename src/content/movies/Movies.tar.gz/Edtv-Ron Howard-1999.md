---
type: movie
country: United States
title: "Edtv"
year: 1999
director: Ron Howard
actors: [Matthew McConaughey, Jenna Elfman, Geoffrey Blake]
genre: [Comedy, Drama]
length: 122
shelf: watchlist
owned: false
rating: 
watched:
poster: "https://m.media-amazon.com/images/M/MV5BN2UzMzljOGEtZjYzZS00ZmNmLTg4NzctYWI2NDI4NjEwOGEwXkEyXkFqcGc@._V1_SX300.jpg"
---

# Edtv (1999)

![](https://m.media-amazon.com/images/M/MV5BN2UzMzljOGEtZjYzZS00ZmNmLTg4NzctYWI2NDI4NjEwOGEwXkEyXkFqcGc@._V1_SX300.jpg)

A video store clerk agrees to have his life filmed by a camera crew for a television show.