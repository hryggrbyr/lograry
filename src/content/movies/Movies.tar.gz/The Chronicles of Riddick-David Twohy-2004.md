---
type: movie
country: US
title: "The Chronicles of Riddick"
year: 2004
director: David Twohy
actors: [Vin Diesel, Thandiwe Newton, Karl Urban, Alexa Davalos, Colm Feore]
genre: [Action, Science Fiction]
length: "1h 59m"
shelf: watched
owned: false
rating: 
watched: 2004-06-11
poster: "https://image.tmdb.org/t/p/w500/iSaB7jBgsU6sXqKneZpdeRw5MSV.jpg"
---

# The Chronicles of Riddick (2004)

![](https://image.tmdb.org/t/p/w500/iSaB7jBgsU6sXqKneZpdeRw5MSV.jpg)

After years of outrunning ruthless bounty hunters, escaped convict Riddick suddenly finds himself caught between opposing forces in a fight for the future of the human race. Now, waging incredible battles on fantastic and deadly worlds, this lone, reluctant hero will emerge as humanity's champion - and the last hope for a universe on the edge of annihilation.