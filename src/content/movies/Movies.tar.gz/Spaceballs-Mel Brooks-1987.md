---
type: movie
country: US
title: "Spaceballs"
year: 1987
director: Mel Brooks
actors: [Mel Brooks, John Candy, Rick Moranis, Bill Pullman, Daphne Zuniga]
genre: [Comedy, Science Fiction]
length: "1h 36m"
shelf: watched
owned: false
rating: 
watched: 1987-06-24
poster: "https://image.tmdb.org/t/p/w500/o624HTt93iIJIc1Sg5hNkDTnk5l.jpg"
---

# Spaceballs (1987)

![](https://image.tmdb.org/t/p/w500/o624HTt93iIJIc1Sg5hNkDTnk5l.jpg)

When the nefarious Dark Helmet hatches a plan to snatch Princess Vespa and steal her planet's air, space-bum-for-hire Lone Starr and his clueless sidekick fly to the rescue. Along the way, they meet Yogurt, who puts Lone Starr wise to the power of "The Schwartz." Can he master it in time to save the day?