---
type: movie
country: JP
title: "Zom 100: Bucket List of the Dead"
year: 2023
director: Yusuke Ishida
actors: [Eiji Akaso, Mai Shiraishi, Shuntaro Yanagi, Kazuki Kitamura, Yui Ichikawa]
genre: [Comedy, Horror]
length: "2h 9m"
shelf: watched
owned: false
rating: 
watched: 2024-04-30
poster: "https://image.tmdb.org/t/p/w500/hV5S6D56BPZ27FSaVEojkvViS3N.jpg"
---

# Zom 100: Bucket List of the Dead (2023)

![](https://image.tmdb.org/t/p/w500/hV5S6D56BPZ27FSaVEojkvViS3N.jpg)

Bullied by his boss, worked around the clock, he's nothing more than a corporate drone. All it takes is a zombie outbreak for him to finally feel alive!