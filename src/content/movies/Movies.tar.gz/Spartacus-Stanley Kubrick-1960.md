---
type: movie
country: US
title: "Spartacus"
year: 1960
director: Stanley Kubrick
actors: [Kirk Douglas, Laurence Olivier, Jean Simmons, Charles Laughton, Peter Ustinov]
genre: [History, War, Drama, Adventure]
length: "3h 17m"
shelf: watched
owned: false
rating: 
watched: 1960-10-13
poster: "https://image.tmdb.org/t/p/w500/r0Fgg1GyZgzokaiw2HFQv3oPaL2.jpg"
---

# Spartacus (1960)

![](https://image.tmdb.org/t/p/w500/r0Fgg1GyZgzokaiw2HFQv3oPaL2.jpg)

The rebellious Thracian Spartacus, born and raised a slave, is sold to Gladiator trainer Batiatus. After weeks of being trained to kill for the arena, Spartacus turns on his owners and leads the other slaves in rebellion. As the rebels move from town to town, their numbers swell as escaped slaves join their ranks. Under the leadership of Spartacus, they make their way to southern Italy, where they will cross the sea and return to their homes.