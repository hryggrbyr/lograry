---
type: movie
country: GB
title: "Harry Potter and the Chamber of Secrets"
year: 2002
director: Chris Columbus
actors: [Daniel Radcliffe, Rupert Grint, Emma Watson, Kenneth Branagh, Toby Jones]
genre: [Adventure, Fantasy]
length: "2h 41m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/sdEOH0992YZ0QSxgXNIGLq1ToUi.jpg"
---

# Harry Potter and the Chamber of Secrets (2002)

![](https://image.tmdb.org/t/p/w500/sdEOH0992YZ0QSxgXNIGLq1ToUi.jpg)

Cars fly, trees fight back, and a mysterious house-elf comes to warn Harry Potter at the start of his second year at Hogwarts. Adventure and danger await when bloody writing on a wall announces: The Chamber Of Secrets Has Been Opened. To save Hogwarts will require all of Harry, Ron and Hermione’s magical abilities and courage.