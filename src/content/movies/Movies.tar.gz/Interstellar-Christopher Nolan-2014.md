---
type: movie
country: US
title: "Interstellar"
year: 2014
director: Christopher Nolan
actors: [Matthew McConaughey, Anne Hathaway, Michael Caine, Jessica Chastain, Casey Affleck]
genre: [Adventure, Drama, Science Fiction]
length: "2h 49m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg"
---

# Interstellar (2014)

![](https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg)

The adventures of a group of explorers who make use of a newly discovered wormhole to surpass the limitations on human space travel and conquer the vast distances involved in an interstellar voyage.