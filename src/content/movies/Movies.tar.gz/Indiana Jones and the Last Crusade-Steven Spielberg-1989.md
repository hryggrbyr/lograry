---
type: movie
country: US
title: "Indiana Jones and the Last Crusade"
year: 1989
director: Steven Spielberg
actors: [Harrison Ford, Sean Connery, Denholm Elliott, Alison Doody, John Rhys-Davies]
genre: [Adventure, Action]
length: "2h 7m"
shelf: watched
owned: false
rating: 
watched: 1989-05-24
poster: "https://image.tmdb.org/t/p/w500/sizg1AU8f8JDZX4QIgE4pjUMBvx.jpg"
---

# Indiana Jones and the Last Crusade (1989)

![](https://image.tmdb.org/t/p/w500/sizg1AU8f8JDZX4QIgE4pjUMBvx.jpg)

In 1938, an art collector appeals to eminent archaeologist Dr. Indiana Jones to embark on a search for the Holy Grail. Indy learns that a medieval historian has vanished while searching for it, and the missing man is his own father, Dr. Henry Jones Sr.. He sets out to rescue his father by following clues in the old man's notebook, which his father had mailed to him before he went missing. Indy arrives in Venice, where he enlists the help of a beautiful academic, Dr. Elsa Schneider, along with Marcus Brody and Sallah. Together they must stop the Nazis from recovering the power of eternal life and taking over the world!