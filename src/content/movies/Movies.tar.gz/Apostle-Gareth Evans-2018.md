---
type: movie
country: US, GB
title: "Apostle"
year: 2018
director: Gareth Evans
actors: [Dan Stevens, Michael Sheen, Lucy Boynton, Mark Lewis Jones, Bill Milner]
genre: [Horror, Mystery]
length: "2h 10m"
shelf: watched
owned: false
rating: 
watched: 2018-10-12
poster: "https://image.tmdb.org/t/p/w500/rd269f2Yftxxam3EOJPYVwrvjIJ.jpg"
---

# Apostle (2018)

![](https://image.tmdb.org/t/p/w500/rd269f2Yftxxam3EOJPYVwrvjIJ.jpg)

In 1905, a man travels to a remote island in search of his missing sister who has been kidnapped by a mysterious religious cult.