---
type: movie
country: US
title: "This Is the End"
year: 2013
director: Seth Rogen, Evan Goldberg
actors: [James Franco, Jonah Hill, Seth Rogen, Jay Baruchel, Danny McBride]
genre: [Action, Comedy]
length: "1h 46m"
shelf: watched
owned: false
rating: 
watched: 2013-06-12
poster: "https://image.tmdb.org/t/p/w500/tNIW0NhX1hKvUsy6PQ80DOKUhkD.jpg"
---

# This Is the End (2013)

![](https://image.tmdb.org/t/p/w500/tNIW0NhX1hKvUsy6PQ80DOKUhkD.jpg)

While attending a party at James Franco's house, Seth Rogen, Jay Baruchel and many other celebrities are faced with the apocalypse.