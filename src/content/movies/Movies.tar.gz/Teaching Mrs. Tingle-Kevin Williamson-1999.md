---
type: movie
country: US
title: "Teaching Mrs. Tingle"
year: 1999
director: Kevin Williamson
actors: [Helen Mirren, Katie Holmes, Barry Watson, Marisa Coughlan, Michael McKean]
genre: [Comedy, Thriller]
length: "1h 36m"
shelf: watched
owned: false
rating: 
watched: 1999-08-11
poster: "https://image.tmdb.org/t/p/w500/cGv0tkWZZSmoaPYiOsDcGmMhKq7.jpg"
---

# Teaching Mrs. Tingle (1999)

![](https://image.tmdb.org/t/p/w500/cGv0tkWZZSmoaPYiOsDcGmMhKq7.jpg)

A bright high-school senior has her impending status as valedictorian jeopardized when her bitter history teacher, Mrs. Tingle, gives her a poor grade on a project.  When an attempt to get ahead in Mrs. Tingle's class goes awry, mayhem ensues and friendships, loyalties and trust are tested by the teacher's intricate mind-games.