---
type: movie
country: US
title: "Jaws 2"
year: 1978
director: Jeannot Szwarc
actors: [Roy Scheider, Lorraine Gary, Murray Hamilton, Joseph Mascolo, Jeffrey Kramer]
genre: [Horror, Thriller]
length: "1h 57m"
shelf: watched
owned: false
rating: 
watched: 1990-06-16
poster: "https://image.tmdb.org/t/p/w500/cN3ijEwsn4kBaRuHfcJpAQJbeWe.jpg"
---

# Jaws 2 (1978)

![](https://image.tmdb.org/t/p/w500/cN3ijEwsn4kBaRuHfcJpAQJbeWe.jpg)

Police chief Brody must protect the citizens of Amity after a second monstrous shark begins terrorizing the waters.