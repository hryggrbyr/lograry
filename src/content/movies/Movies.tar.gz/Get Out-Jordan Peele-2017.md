---
type: movie
country: US
title: "Get Out"
year: 2017
director: Jordan Peele
actors: [Daniel Kaluuya, Allison Williams, Catherine Keener, Bradley Whitford, Caleb Landry Jones]
genre: [Mystery, Thriller, Horror]
length: "1h 44m"
shelf: watched
owned: false
rating: 
watched: 2023-01-29
poster: "https://image.tmdb.org/t/p/w500/tFXcEccSQMf3lfhfXKSU9iRBpa3.jpg"
---

# Get Out (2017)

![](https://image.tmdb.org/t/p/w500/tFXcEccSQMf3lfhfXKSU9iRBpa3.jpg)

Chris and his girlfriend Rose go upstate to visit her parents for the weekend. At first, Chris reads the family's overly accommodating behavior as nervous attempts to deal with their daughter's interracial relationship, but as the weekend progresses, a series of increasingly disturbing discoveries lead him to a truth that he never could have imagined.