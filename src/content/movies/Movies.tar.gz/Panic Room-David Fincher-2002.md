---
type: movie
country: US
title: "Panic Room"
year: 2002
director: David Fincher
actors: [Jodie Foster, Kristen Stewart, Forest Whitaker, Dwight Yoakam, Jared Leto]
genre: [Crime, Drama, Thriller]
length: "1h 51m"
shelf: watched
owned: false
rating: 
watched: 2002-03-29
poster: "https://image.tmdb.org/t/p/w500/hANYbvfwxmkC9E4yY6YyJxYxlSJ.jpg"
---

# Panic Room (2002)

![](https://image.tmdb.org/t/p/w500/hANYbvfwxmkC9E4yY6YyJxYxlSJ.jpg)

Trapped in their New York brownstone's panic room, a hidden chamber built as a sanctuary in the event of break-ins, newly divorced Meg Altman and her young daughter Sarah play a deadly game of cat-and-mouse with three intruders - Burnham, Raoul and Junior - during a brutal home invasion. But the room itself is the focal point because what the intruders really want is inside it.