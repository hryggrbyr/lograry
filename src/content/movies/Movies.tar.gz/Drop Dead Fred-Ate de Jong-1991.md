---
type: movie
country: United Kingdom, United States
title: Drop Dead Fred
year: 1991
director: Ate de Jong
actors: [Phoebe Cates, Rik Mayall, Marsha Mason]
genre: [Comedy, Drama, Fantasy]
length: 103
shelf: watched
owned: false
rating: 
watched: 1991-12-31
poster: "https://m.media-amazon.com/images/M/MV5BOGZmZGE5YzQtOTFlOS00NmZiLWI3YTYtMjNiZmU4ZTM5MDY5XkEyXkFqcGc@._V1_SX300.jpg"
---

# Drop Dead Fred (1991)

![](https://m.media-amazon.com/images/M/MV5BOGZmZGE5YzQtOTFlOS00NmZiLWI3YTYtMjNiZmU4ZTM5MDY5XkEyXkFqcGc@._V1_SX300.jpg)

A young woman finds her already unstable life rocked by the presence of a rambunctious imaginary friend from childhood.