---
type: movie
country: US, GB
title: "Muppet Treasure Island"
year: 1996
director: Brian Henson
actors: [Tim Curry, Billy Connolly, Jennifer Saunders, Kevin Bishop, Dave Goelz]
genre: [Family, Comedy, Adventure, Music]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 1996-02-16
poster: "https://image.tmdb.org/t/p/w500/8UL6EcZGO1ssD60azzOtUPjnOZI.jpg"
---

# Muppet Treasure Island (1996)

![](https://image.tmdb.org/t/p/w500/8UL6EcZGO1ssD60azzOtUPjnOZI.jpg)

After telling the story of Flint's last journey to young Jim Hawkins, Billy Bones has a heart attack and dies just as Jim and his friends are attacked by pirates. The gang escapes into the town where they hire out a boat and crew to find the hidden treasure, which was revealed by Bones before he died. On their voyage across the seas, they soon find out that not everyone on board can be trusted.