---
type: movie
country: United States
title: "Jolt"
year: 2021
director: Tanya Wexler
actors: [Kate Beckinsale, Jai Courtney, Stanley Tucci]
genre: [Action, Comedy, Crime]
length: 91
shelf: watchlist
owned: false
rating: 
watched: 
poster: "https://m.media-amazon.com/images/M/MV5BZDJmMjBiYTItOGUwMC00M2U2LWI3NTMtMDkzYTgzZGUzODAyXkEyXkFqcGc@._V1_SX300.jpg"
---

# Jolt (2021)

![](https://m.media-amazon.com/images/M/MV5BZDJmMjBiYTItOGUwMC00M2U2LWI3NTMtMDkzYTgzZGUzODAyXkEyXkFqcGc@._V1_SX300.jpg)

A bouncer with a slightly murderous anger-management problem that she controls with the help of an electrode-lined vest she uses to shock herself back to normalcy whenever she gets homicidal.