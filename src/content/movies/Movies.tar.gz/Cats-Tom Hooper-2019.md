---
type: movie
country: US
title: "Cats"
year: 2019
director: Tom Hooper
actors: [Francesca Hayward, Judi Dench, Idris Elba, Jason Derulo, Jennifer Hudson]
genre: [Fantasy, Comedy, Drama]
length: "1h 50m"
shelf: watched
owned: false
rating: 
watched: 2019-12-20
poster: "https://image.tmdb.org/t/p/w500/aCNch5FmzT2WaUcY44925owIZXY.jpg"
---

# Cats (2019)

![](https://image.tmdb.org/t/p/w500/aCNch5FmzT2WaUcY44925owIZXY.jpg)

A tribe of cats called the Jellicles must decide yearly which one will ascend to the Heaviside Layer and come back to a new Jellicle life.