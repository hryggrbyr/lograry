---
type: movie
country: United States, Canada
title: "Underworld Evolution"
year: 2006
director: Len Wiseman
actors: [Kate Beckinsale, Scott Speedman, Bill Nighy]
genre: [Action, Fantasy, Thriller]
length: 106
shelf: watched
owned: false
rating: 
watched: 2006-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMjEzNDY1OTQwOV5BMl5BanBnXkFtZTcwNjcxMTIzMw@@._V1_SX300.jpg"
---

# Underworld Evolution (2006)

![](https://m.media-amazon.com/images/M/MV5BMjEzNDY1OTQwOV5BMl5BanBnXkFtZTcwNjcxMTIzMw@@._V1_SX300.jpg)

Picking up directly from the previous movie, vampire warrior Selene and the half werewolf Michael hunt for clues to reveal the history of their races and the war between them.