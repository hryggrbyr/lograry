---
type: movie
country: US
title: "First Blood"
year: 1982
director: Ted Kotcheff
actors: [Sylvester Stallone, Richard Crenna, Brian Dennehy, Bill McKinney, Jack Starrett]
genre: [Action, Adventure, Thriller, War]
length: "1h 33m"
shelf: watched
owned: false
rating: 
watched: 1982-10-22
poster: "https://image.tmdb.org/t/p/w500/a9sa6ERZCpplbPEO7OMWE763CLD.jpg"
---

# First Blood (1982)

![](https://image.tmdb.org/t/p/w500/a9sa6ERZCpplbPEO7OMWE763CLD.jpg)

When former Green Beret John Rambo is harassed by local law enforcement and arrested for vagrancy, he is forced to flee into the mountains and wage an escalating one-man war against his pursuers.