---
type: movie
country: United States
title: "The Purge Election Year"
year: 2016
director: James DeMonaco
actors: [Frank Grillo, Elizabeth Mitchell, Mykelti Williamson]
genre: [Action, Horror, Sci-Fi]
length: 108
shelf: watched
owned: false
rating: 
watched: 2016-12-31
poster: "https://m.media-amazon.com/images/M/MV5BMjI3MDI0MTA1N15BMl5BanBnXkFtZTgwOTk4NjU5ODE@._V1_SX300.jpg"
---

# The Purge Election Year (2016)

![](https://m.media-amazon.com/images/M/MV5BMjI3MDI0MTA1N15BMl5BanBnXkFtZTgwOTk4NjU5ODE@._V1_SX300.jpg)

Senator Charlie Roan and her head of security must survive an annual night of terror where all crime is legal.