---
type: movie
country: US
title: "Fast Times at Ridgemont High"
year: 1982
director: Amy Heckerling
actors: [Judge Reinhold, Sean Penn, Jennifer Jason Leigh, Phoebe Cates, Brian Backer]
genre: [Comedy]
length: "1h 30m"
shelf: watched
owned: false
rating: 
watched: 1982-08-13
poster: "https://image.tmdb.org/t/p/w500/s1DA8H7qwoOcAEhow2rCzuQtpuO.jpg"
---

# Fast Times at Ridgemont High (1982)

![](https://image.tmdb.org/t/p/w500/s1DA8H7qwoOcAEhow2rCzuQtpuO.jpg)

Based on the real-life adventures chronicled by Cameron Crowe, Fast Times follows a group of high school students growing up in Southern California. Stacy Hamilton and Mark Ratner are looking for love, and are helped along by their older classmates, Linda Barrett and Mike Damone. Jeff Spicoli, a perpetually stoned surfer faces-off with the resolute teacher, Mr. Hand. Hilarity and heartbreak ensue.