---
type: movie
country: US
title: "The Princess Bride"
year: 1987
director: Rob Reiner
actors: [Cary Elwes, Robin Wright, Mandy Patinkin, Chris Sarandon, Christopher Guest]
genre: [Adventure, Family, Fantasy, Comedy, Romance]
length: "1h 39m"
shelf: watched
owned: false
rating: 
watched: 1987-09-25
poster: "https://image.tmdb.org/t/p/w500/dvjqlp2sAhUeFjUOfQDgqwpphHj.jpg"
---

# The Princess Bride (1987)

![](https://image.tmdb.org/t/p/w500/dvjqlp2sAhUeFjUOfQDgqwpphHj.jpg)

In this enchantingly cracked fairy tale, the beautiful Princess Buttercup and the dashing Westley must overcome staggering odds to find happiness amid six-fingered swordsmen, murderous princes, Sicilians and rodents of unusual size. But even death can't stop these true lovebirds from triumphing.